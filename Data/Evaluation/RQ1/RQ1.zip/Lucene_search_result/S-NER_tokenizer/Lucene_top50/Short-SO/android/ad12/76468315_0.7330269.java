import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.util.resource.ResourceCollection;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;

public class WebServer {

    public static void main(String[] args) {
        Server server = createServer();
        try {
            server.start();
            System.out.println(&quot;Server started&quot;);
            server.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Server createServer() {
        Server server = new Server(9090);
        ServletContextHandler context = new ServletContextHandler(server, &quot;/&quot;);
        Resource resources = createStaticResources();
        context.setBaseResource(resources);
        ServletHolder servlet = createServlet();
        context.addServlet(servlet, &quot;/*&quot;);
        return server;
    }

    private static ResourceConfig createResourceConfig() {
        ResourceConfig config = new ResourceConfig();
        config.packages(&quot;Controllers&quot;);
        config.register(MultiPartFeature.class);
        return config;
    }

    private static ServletHolder createServlet() {
        ResourceConfig config = createResourceConfig();
        ServletContainer container = new ServletContainer(config);
        ServletHolder servlet = new ServletHolder(container);
        return servlet;
    }

    private static Resource createStaticResources() {
        String[] locations = new String[] {
            &quot;src/main/resources/&quot;
        };
        Resource resources = new ResourceCollection(locations);
        return resources;
    }
}
package Controllers;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Path(&quot;/&quot;)
public class Main {
    
    @GET
    @Path(&quot;/&quot;)
    @Produces(MediaType.TEXT_PLAIN)
    public String helloWorld() {
        return &quot;Hello World!&quot;;
    }

    @GET
    @Path(&quot;/page1&quot;)
    @Produces(MediaType.TEXT_PLAIN)
    public String page1() {
        return &quot;Page 1&quot;;
    }
}
