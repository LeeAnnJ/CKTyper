public class Connection extends Thread{
public final static int PORT = 1337;
private ServerSocket svrSocket = null;
private Socket con  =  null;
public Connection(){

    try{
        svrSocket = new ServerSocket(PORT);
        System.out.println("Conected to: " + PORT);

    }catch(IOException ex)
    {
       System.err.println(ex);
       System.out.println("Unable to attach to port");
   }

}

public void run(){

while(true)
{

        try{
            con = svrSocket.accept();//on this part the program stops
            System.out.println("Client request accepted");
            PrintWriter out = new PrintWriter(con.getOutputStream());
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            out.println("GET /&lt;index.html&gt; HTTP/1.1");

            out.println("***CLOSE***");
            System.out.println(in.readLine());
           /*
            String s;

            while((s = in.readLine()) != null)
            {
                System.out.println(s);
            }*/
            out.flush();
            out.close();
            in.close();
            con.close();

            System.out.println("all closed");
    }
        catch(IOException ex)
    {
        ex.printStackTrace();

    }



}
}

}
GET /&lt;index.html&gt; HTTP/1.1
***CLOSE***
&lt;html&gt;
 &lt;head&gt;
  &lt;title&gt;       &lt;/title&gt;

 &lt;/head&gt;
 &lt;body bgcolor = "#ffffcc" text = "#000000"&gt;
  &lt;h1&gt;Hello&lt;/h1&gt;
  &lt;p&gt;This is a simple web page&lt;/p&gt;
 &lt;/body&gt;
&lt;/html&gt;
