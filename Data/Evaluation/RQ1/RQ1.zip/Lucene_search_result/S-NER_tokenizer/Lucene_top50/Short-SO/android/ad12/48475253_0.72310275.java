URL resource = getClass().getClassLoader().getResource("static/config");
File configFolder = new File(resource.getFile());
    for (File file : configFolder.listFiles()) {
        //working with files
    }
    /src
  /main
    /java
      /...
    /resources
      /static
        /config
           1.json
           2.json
           ...
      ...
 LOG.info(Optional.ofNullable(
            getClass().getClassLoader().getResource("static/config"))
            .map(URL::toString)
            .orElse("null"));
