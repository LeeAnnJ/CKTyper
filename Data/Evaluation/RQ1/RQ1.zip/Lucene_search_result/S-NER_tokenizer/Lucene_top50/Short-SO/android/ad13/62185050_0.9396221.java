binding.buttonAdd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(binding.editText.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter number before performing operation", Toast.LENGTH_LONG).show();
                return;
            }
            computeCalculation();
            CURRENT_ACTION = ADDITION;

            //if editText was empty then valueOne would still be NaN
            //and infoTextView will show NaN+ with this line of code

            binding.infoTextView.setText(decimalFormat.format(valueOne) + "+");
            binding.editText.setText(null);
        }
    });
public class MainActivity extends AppCompatActivity {

private ActivityMainBinding binding;
private static final char ADDITION = '+';
private static final char SUBTRACTION = '-';
private static final char MULTIPLICATION = '*';
private static final char DIVISION = '/';

private char CURRENT_ACTION;

private double valueOne = Double.NaN;
private double valueTwo;

private DecimalFormat decimalFormat;


@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    binding = ActivityMainBinding.inflate(getLayoutInflater());
    View view = binding.getRoot();
    setContentView(view);


    decimalFormat = new DecimalFormat("#.##########");

    binding.buttonDot.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + ".");
        }
    });

    binding.buttonZero.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "0");
        }
    });

    binding.buttonOne.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "1");
        }
    });

    binding.buttonTwo.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "2");
        }
    });

    binding.buttonThree.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "3");
        }
    });

    binding.buttonFour.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "4");
        }
    });

    binding.buttonFive.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "5");
        }
    });

    binding.buttonSix.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "6");
        }
    });

    binding.buttonSeven.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "7");
        }
    });

    binding.buttonEight.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "8");
        }
    });

    binding.buttonNine.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            binding.editText.setText(binding.editText.getText() + "9");
        }
    });


    binding.buttonAdd.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(binding.editText.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter number before performing operation", Toast.LENGTH_LONG).show();
                return;
            }
            computeCalculation();
            CURRENT_ACTION = ADDITION;
            binding.infoTextView.setText(decimalFormat.format(valueOne) + "+");
            binding.editText.setText(null);
        }
    });

    binding.buttonSubtract.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(binding.editText.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter number before performing operation", Toast.LENGTH_LONG).show();
                return;
            }
            computeCalculation();
            CURRENT_ACTION = SUBTRACTION;
            binding.infoTextView.setText(decimalFormat.format(valueOne) + "-");
            binding.editText.setText(null);
        }
    });

    binding.buttonMultiply.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(binding.editText.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter number before performing operation", Toast.LENGTH_LONG).show();
                return;
            }
            computeCalculation();
            CURRENT_ACTION = MULTIPLICATION;
            binding.infoTextView.setText(decimalFormat.format(valueOne) + "*");
            binding.editText.setText(null);
        }
    });

    binding.buttonDivide.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(binding.editText.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter number before performing operation", Toast.LENGTH_LONG).show();
                return;
            }
            computeCalculation();
            CURRENT_ACTION = DIVISION;
            binding.infoTextView.setText(decimalFormat.format(valueOne) + "/");
            binding.editText.setText(null);
        }
    });

    binding.buttonEquals.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if(binding.editText.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Enter number before performing operation", Toast.LENGTH_LONG).show();
                return;
            }
            computeCalculation();
            binding.infoTextView.setText(binding.infoTextView.getText().toString() +
                    decimalFormat.format(valueTwo) + " = " + decimalFormat.format(valueOne));
            valueOne = Double.NaN;
            CURRENT_ACTION = '0';
        }
    });

    binding.buttonClear.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (binding.editText.getText().length() &gt; 0) {
                CharSequence currentText = binding.editText.getText();
                binding.editText.setText(currentText.subSequence(0, currentText.length() - 1));
            } else {
                valueOne = Double.NaN;
                valueTwo = Double.NaN;
                binding.editText.setText("");
                binding.infoTextView.setText("");
            }
        }
    });
}

private void computeCalculation() {
    if (!Double.isNaN(valueOne)) {
        valueTwo = Double.parseDouble(binding.editText.getText().toString());
        binding.editText.setText(null);

        if (CURRENT_ACTION == ADDITION)
            valueOne = this.valueOne + valueTwo;
        else if (CURRENT_ACTION == SUBTRACTION)
            valueOne = this.valueOne - valueTwo;
        else if (CURRENT_ACTION == MULTIPLICATION)
            valueOne = this.valueOne * valueTwo;
        else if (CURRENT_ACTION == DIVISION)
            valueOne = this.valueOne / valueTwo;
    } else {
        try {
            valueOne = Double.parseDouble(binding.editText.getText().toString());
        } catch (Exception e) {
        }
    }

}
}
