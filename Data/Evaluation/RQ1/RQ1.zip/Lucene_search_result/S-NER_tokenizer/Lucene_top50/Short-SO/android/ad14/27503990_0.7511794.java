final class imm{
 private final int value;

        public imm(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
}
final class imm2{

    imm value;  // is this legal ???

    public imm2(imm value) {
        this.value = value;
    }

    public imm getValue() {
        return value;
    }
   // set value removed is there any problems here i mean is my code correct now?

}
