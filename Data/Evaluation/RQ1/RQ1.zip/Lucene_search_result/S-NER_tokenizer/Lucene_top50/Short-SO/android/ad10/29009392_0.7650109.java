 public class MainActivity5 extends Activity implements OnItemSelectedListener{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity5);


        Context ctx=getApplicationContext();

          map=( (MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();

          map.setOnMapClickListener(new OnMapClickListener() {

            @Override
            public void onMapClick(LatLng arg0) {
                // TODO Auto-generated method stub

                Marker newmarker = map.addMarker(new MarkerOptions()
                    .position(arg0)
                    .title("Title")
                    .snippet("Description")
                    .icon(BitmapDescriptorFactory.fromBitmap(MainActivity5.createDrawableFromView((Activity)getApplicationContext(), marker))));

            }
        });

       }

     // Convert a view to bitmap
      public static Bitmap createDrawableFromView(Activity context, View view) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        view.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        view.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        return bitmap;
    }

     }
     &lt;?xml version="1.0" encoding="utf-8"?&gt;
&lt;manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.mapp1"
    android:versionCode="1"
    android:versionName="1.0" &gt;
    &lt;uses-sdk
        android:minSdkVersion="16"
        android:targetSdkVersion="17" /&gt;
     &lt;application
         android:allowBackup="true"
        android:icon="@drawable/ic_launcher3"
        android:label="@string/app_name"
        android:theme="@style/AppTheme" 
      &gt;
        &lt;activity
            android:name=".MainActivity5"
            android:label="@string/app_name" &gt;
            &lt;intent-filter&gt;
                &lt;action android:name="android.intent.action.MAIN" /&gt;
                &lt;category android:name="android.intent.category.LAUNCHER" /&gt;
            &lt;/intent-filter&gt;
        &lt;/activity&gt;
      &lt;/application&gt;
