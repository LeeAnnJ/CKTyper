  public class MyService extends Service {

        //for timer:
        int counter = 0;

        static final int UPDATE_INTERVAL = 1000;
        private Timer timer = new Timer();

        @Override
        public IBinder onBind(Intent arg0) {
            return null;
        }


        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {
            doSomethingRepeatedly();
            return START_STICKY;
        }


        private void doSomethingRepeatedly() {
            timer.scheduleAtFixedRate( new TimerTask() {
                public void run() {

                 //code for changing the content

                }
            }, 0, UPDATE_INTERVAL);
        }

        @Override
        public void onDestroy() {
            super.onDestroy();

            //za timer
            if (timer != null){
                timer.cancel();

            }
        }
    }
 public void startService(View view) {
        startService(new Intent(getBaseContext(), MyService.class));
 }

  public void stopService(View view) {
        stopService(new Intent(getBaseContext(), MyService.class));
    }
