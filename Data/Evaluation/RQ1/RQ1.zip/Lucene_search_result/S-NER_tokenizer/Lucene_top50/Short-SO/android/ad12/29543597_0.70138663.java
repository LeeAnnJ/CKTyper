&lt;listener&gt;
    &lt;listener-class&gt;com._1834Software.Config&lt;/listener-class&gt;
&lt;/listener&gt;
public class Config implements ServletContextListener {
    private static final String ATTRIBUTE_NAME = "config";
    private Properties config = new Properties();

    @Override
    public void contextInitialized(ServletContextEvent event) {
        try {

            config.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("config.properties"));

        } catch (IOException err) {
            err.printStackTrace();
        }

        event.getServletContext().setAttribute(ATTRIBUTE_NAME, this);

    }

    @Override
    public void contextDestroyed(ServletContextEvent event) { /**/ }

    public static Config getInstance(ServletContext context) {
        return (Config) context.getAttribute(ATTRIBUTE_NAME);
    }

    public String getProperty(String key) {
        return config.getProperty(key);
    }

}
Config config = Config.getInstance(getServletContext());
String property = config.getProperty("HEROKU_DATABASE_URL");
Error:(32, 40) java: cannot find symbol
symbol:   method getServletContext()
location: class com._1834Software.database.DatabaseHandler
public class DatabaseHandler {
    public Connection connection = null;

    Config config = Config.getInstance(getServletContext());
    String property = config.getProperty("somekey");


    /* Database Parameters */
    private String DRIVER = "org.postgresql.Driver";
    private String host = "XXXXX";
    private String userName = "XXXXX";
    private String password = "XXXXX";

    public void connect() throws SQLException {
        try {

            Class.forName(DRIVER);

        } catch (ClassNotFoundException err) {

            err.printStackTrace();   

        }

        try {

            connection = DriverManager.getConnection(host, userName, password);

        } catch (SQLException err) {
            err.printStackTrace();
        }
    }

    public void disconnect() throws SQLException { connection.close(); }
}
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("sample")
public class JerseyConfig extends Application {

public static final String PROPERTIES_FILE = "config.properties";
public static Properties properties = new Properties();

private Properties readProperties() {
    InputStream inputStream = getClass().getClassLoader().getResourceAsStream(PROPERTIES_FILE);
    if (inputStream != null) {
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            // TODO Add your custom fail-over code here
            e.printStackTrace();
        }
    }
    return properties;
}

@Override
public Set&lt;Class&lt;?&gt;&gt; getClasses() {     
    // Read the properties file
    readProperties();

    // Set up your Jersey resources
    Set&lt;Class&lt;?&gt;&gt; rootResources = new HashSet&lt;Class&lt;?&gt;&gt;();
    rootResources.add(JerseySample.class);
    return rootResources;
}

}
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/")
public class JerseySample {

    @GET
    @Path("hello")
    @Produces(MediaType.TEXT_PLAIN)
    public String get() {
        return "Property value is: " + JerseyConfig.properties.getProperty("sample.property");
    }

}
private static String token;
static {
    token = getProperties().getProperty("token");
}

public static Properties getProperties() {
    Properties _properties = new Properties();

    try (InputStream inputStream = new FileInputStream("src/main/resources/app.properties")) {
        _properties.load(inputStream);
    } catch (Exception e) {
        e.printStackTrace();
    }
    return _properties;
}
