    private ArrayList&lt;String&gt; images;
    private LayoutInflater inflater;

    public ImagePagerAdapter(ArrayList&lt;String&gt; images,Context context) {
        this.images = images;
        inflater = LayoutInflater.from(context);
      }
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        if(images.size()==0)
            return 1;

        return images.size();

    }

    @Override
    public Object instantiateItem(ViewGroup view, int position) {

        View imageLayout = inflater.inflate(R.layout.property_image_item,
                view, false);
        assert imageLayout != null;
        final ImageView imageView = (ImageView) imageLayout
                .findViewById(R.id.image);

        final ProgressBar spinner = (ProgressBar) imageLayout
                .findViewById(R.id.loading);
        String imageUrl=images.get(position);




         Picasso.with(getActivity())
            .load(imageUrl)

            .into(imageView);

        ((ViewPager) view).addView(imageLayout, 0);
        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public void restoreState(Parcelable state, ClassLoader loader) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }
}
