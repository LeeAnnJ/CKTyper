myView.requestFocus();
getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
&lt;activity  
        android:name="com.example.framework.MainActivity"
        android:label="@string/app_name" 
        android:windowSoftInputMode="stateVisible"       //Add this line    
         &gt;
        &lt;intent-filter&gt;
            &lt;action android:name="android.intent.action.MAIN" /&gt;

            &lt;category android:name="android.intent.category.LAUNCHER" /&gt;
        &lt;/intent-filter&gt;
    &lt;/activity&gt;
EditText editText = (EditText)findViewById(R.id.edit_text_id);
InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_id, container);
    EditText editText = (EditText)view.findViewById(R.id.edit_text_id);

    // show soft keyboard
    editText.requestFocus();
    getDialog().getWindow().setSoftInputMode(LayoutParams.SOFT_INPUT_STATE_VISIBLE);

    return view;
}
@Override
public void onResume() {
   super.onResume();
   final View v = getDialog().findViewById(R.id.edit_text_id);
   v.post(new Runnable() {
      @Override
      public void run() {
        v.requestFocus();
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
      }
   });
 }
AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());  
// blah blah blah do builder stuff here like setTitle, setView, etc

Dialog d = builder.create();
d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
return d;
public class FocussableEditText extends EditText {

    public FocussableEditText(Context context) {
        super(context);
    }

    public FocussableEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FocussableEditText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    public void onWindowFocusChanged(boolean hasWindowFocus) {
        super.onWindowFocusChanged(hasWindowFocus);
        if (hasWindowFocus) {
            InputMethodManager imm = (InputMethodManager)getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(this, InputMethodManager.SHOW_FORCED);
        }
    }
}
**&lt;activity
            android:name=".mmmmm.zzzzzzz.yyyyyy.xxxxxx"
            android:windowSoftInputMode="stateVisible"
            android:label="@string/title_activity_print_recharge"&gt;&lt;/activity&gt;**
public final class Utilities {

  // Shows the soft keyboard. V on which view (typically EditText) to focus the keyboard input
  public static void showSoftKeyboard(Activity activity, EditText editText) 
  {
      InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
      imm.showSoftInput(editText, InputMethodManager.SHOW_FORCED);
  }
}

/**
 * Called when user clicks/touches the search button
 * @param v The clicked/touched view (EditText)
 */
protected void onSearchButtonClick(View v)
{
    EditText seekTopic = (EditText) findViewById(R.id.SeekTopicBox);
    setActivityContent(seekTopic.getText().toString());
}
&lt;androidx.appcompat.widget.AppCompatEditText
                    android:id=&quot;@+id/mobile_number_edit_text&quot;
                    android:layout_width=&quot;match_parent&quot;
                    android:layout_height=&quot;wrap_content&quot;
                    android:background=&quot;@null&quot;
                    android:hint=&quot;@string/give_mobile_number&quot;
                    android:inputType=&quot;number&quot;
                    android:maxLength=&quot;11&quot;
                    android:maxLines=&quot;1&quot;
                    android:textColor=&quot;@color/body&quot;
                    android:textSize=&quot;@dimen/_13ssp&quot;
                    app:fontFamily=&quot;@font/hkgrotesk_regular&quot;
                    &gt;

                    &lt;requestFocus /&gt;

&lt;/androidx.appcompat.widget.AppCompatEditText&gt;
fun Activity.showKeyboard() {
    val imm = this.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager

    var view = this.currentFocus
    if (view == null) view = View(this)

    imm.showSoftInput(view, 0)
}
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        activity?.showKeyboard()

        ... ... ... Your other code ... ... ...
}
