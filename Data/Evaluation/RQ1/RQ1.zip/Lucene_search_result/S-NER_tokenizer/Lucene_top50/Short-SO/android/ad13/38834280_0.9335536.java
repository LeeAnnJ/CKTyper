public class CardapioRU extends Fragment {

private ViewPager mPager;
private PagerAdapter mPagerAdapter;

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.view_pager_ru, container, false);

    mPager = (ViewPager) rootView.findViewById(R.id.pager);
    mPagerAdapter = new PagerAdapterRU(inflater);
    mPager.setAdapter(mPagerAdapter);
    return rootView;
}

}
public class PagerAdapterRU extends PagerAdapter {

private View domingo = null;
private View segunda = null;

@SuppressLint("InflateParams")
public PagerAdapterRU(LayoutInflater inflater) {
    domingo = inflater.inflate(R.layout.ru_domingo, null);
    segunda = inflater.inflate(R.layout.ru_segunda, null);
}

public View getViewAtPosition(int position) {
    View view = null;
    if (position == 0) {
        view = domingo;
    }
    if (position == 1) {
        view = segunda;
    }
    ;
    return view;
};

@Override
public Object instantiateItem(View collection, int position) {
    View view = getViewAtPosition(position);
    ((ViewPager) collection).addView(view, 0);
    return view;
}

@Override
public int getCount() {
    return 2;
}
