 static void saveTable(UUID h1, Object x,Hashtable ht)
 {
     if(ht.get(h1) == null)
     {
         ht.put(h1, x);
     }
     else
     {
         Object ref=h1;
         Object ref2=new Object();
         while(ref!=null)
         { 
             if(ref!=null)
             {
                 ref2=ref;
             }
             ref=ht.get(ref);
         }
         ht.put(ref2,x);
     }
 }

 static ArrayList loadTable(UUID h1,Hashtable ht)
 {
     Object x=ht.get(h1);
     Object ref=h1;
     ArrayList al=new ArrayList();
     if(ht.get(h1)!=null)
     {
         while(ref!=null)
         {
             if(ref!=h1)al.add(ref);
             ref=ht.get(ref);
         }

     }
    return al;
 }
public static void main(String[] args)
{
    Hashtable ht=new Hashtable();
    UUID h1=UUID.randomUUID();
    UUID h2=UUID.randomUUID();

    saveTable(h1, "this is",ht);
    saveTable(h1, "inefficient",ht);

    saveTable(h2, "but",ht);
    saveTable(h2, "saves",ht);
    saveTable(h2, "the day",ht);
    saveTable(h2, "at least",ht);

    Object[] al=loadTable(h1,ht).toArray();
    Object[] al2=loadTable(h2,ht).toArray();

    for(int i=0;i&lt;al.length;i++)
    {System.out.println(al[i]);}

    for(int i=0;i&lt;al2.length;i++)
    {System.out.println(al2[i]);}
}
this is
inefficient
but
saves
the day
at least
