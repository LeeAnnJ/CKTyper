public static void hideKeyboard(Activity activity) {
    InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
    //Find the currently focused view, so we can grab the correct window token from it.
    View view = activity.getCurrentFocus();
    //If no view currently has focus, create a new one, just so we can grab a window token from it
    if (view == null) {
        view = new View(activity);
    }
    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
}
    // Create object of  DesiredCapabilities class and specify android platform
    DesiredCapabilities capabilities = DesiredCapabilities.android();


    // set the capability to execute test in android app
    capabilities.setCapability(MobileCapabilityType.PLATFORM, Platform.ANDROID);
    capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Emulator_1");
    capabilities.setCapability(MobileCapabilityType.VERSION, "8.0");
    capabilities.setCapability("appPackage", "com.spreeza.shop.stag.debug");
    capabilities.setCapability("appActivity", "com.spreeza.shop.ui.features.splash.EntryPointActivity");

    driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

// click on the login button
driver.findElement(By.id(identifierName)).click();

// close the keyboard
hideKeyboard();
