&lt;RelativeLayout 
    xmlns:android=&quot;http://schemas.android.com/apk/res/android&quot;
    xmlns:app=&quot;http://schemas.android.com/apk/res-auto&quot;
    xmlns:tools=&quot;http://schemas.android.com/tools&quot;
    android:id=&quot;@+id/parentRelative&quot;
    android:layout_width=&quot;match_parent&quot;
    android:layout_height=&quot;match_parent&quot;
    android:background=&quot;@android:color/transparent&quot;
    android:layout_margin=&quot;30dp&quot;
    tools:context=&quot;.TransparentActivity&quot;&gt;

    &lt;RelativeLayout
        android:id=&quot;@+id/secondParentRelative&quot;
        android:layout_width=&quot;match_parent&quot;
        android:layout_height=&quot;match_parent&quot;
        android:layout_centerInParent=&quot;true&quot;&gt;
        
        ...

    &lt;/RelativeLayout&gt;

&lt;/RelativeLayout&gt;
@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    RelativeLayout relativeLayout = findViewById(R.id.parentRelative);
    relativeLayout.setBackground(new BitmapDrawable(getResources(),
                            blur(TransparentActivity.this, captureScreenShot(relativeLayout))));
}

public static Bitmap captureScreenShot(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_4444);
        Canvas canvas = new Canvas(bitmap);
        Drawable backgroundDrawable = view.getBackground();
        if (backgroundDrawable != null) {
            backgroundDrawable.draw(canvas);
        } else {
            canvas.drawColor(Color.parseColor(&quot;#80000000&quot;));
        }
        view.draw(canvas);
        return bitmap;
}

public static Bitmap blur(Context context, Bitmap image) {
    float BITMAP_SCALE = 0.4f;
    float BLUR_RADIUS = 23f;

    int width = Math.round(image.getWidth() * BITMAP_SCALE);
    int height = Math.round(image.getHeight() * BITMAP_SCALE);
    Bitmap inputBitmap = Bitmap.createScaledBitmap(image, width, height, false);
    Bitmap outputBitmap = Bitmap.createBitmap(inputBitmap);
    RenderScript rs = RenderScript.create(context);
    ScriptIntrinsicBlur theIntrinsic = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
    Allocation tmpIn = Allocation.createFromBitmap(rs, inputBitmap);
    Allocation tmpOut = Allocation.createFromBitmap(rs, outputBitmap);
    theIntrinsic.setRadius(BLUR_RADIUS);
    theIntrinsic.setInput(tmpIn);
    theIntrinsic.forEach(tmpOut);
    tmpOut.copyTo(outputBitmap);

    return outputBitmap;
}
