&lt;EditText
            android:id="@+id/editText"
            android:layout_width="match_parent"
            android:hint="Type Here"
            android:focusable="false"
            android:layout_height="wrap_content" /&gt;
int count = 0;
EditText editText;
// If you are doing in Fragment
editText = (EditText) rootView.findViewById(R.id.editText);
// If you are doing in Activity
editText = (EditText) findViewById(R.id.editText);
editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkTheNumberOfTap();
            }
        });

private void checkTheNumberOfTap() {
      count++;
      Log.e("Count ", " is " + count);
      if(count==2) {
          // Method to show the Keyboard
          editText.setFocusable(true);
          // If you are in Fragment
          InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
          // If you are in Activity
          InputMethodManager imm =(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
          imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
        }
    }
