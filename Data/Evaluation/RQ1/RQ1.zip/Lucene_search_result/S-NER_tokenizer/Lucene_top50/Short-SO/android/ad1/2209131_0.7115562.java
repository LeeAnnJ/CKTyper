@Override

public boolean onKeyLongPress(int keyCode, KeyEvent event)

{

            if (keyCode == KeyEvent.KEYCODE_MENU)
        {
             showSoftInput.getInputMethodList();
             showSoftInput.toggleSoftInput(showSoftInput.SHOW_FORCED, 0);

            return true;
        }
        return super.onKeyLongPress(keyCode, event);
    }
View.OnLongClickListener mLongClickListener = new View.OnLongClickListener()
    {

        @Override
        public boolean onLongClick(View v)
        {

            Configuration config = RouteMapActivity.this.getResources()
                    .getConfiguration();
            if (config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES)
            {
                InputMethodManager imm = (InputMethodManager) RouteMapActivity.this
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(mapView, InputMethodManager.SHOW_IMPLICIT); // .SHOW_FORCED);
            }
            return false;
        }

    };
&lt;activity
    android:windowSoftInputMode="stateVisible" ... &gt;
    ...
&lt;/activity&gt;
