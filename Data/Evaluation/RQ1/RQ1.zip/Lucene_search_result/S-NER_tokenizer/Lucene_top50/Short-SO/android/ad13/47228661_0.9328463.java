public class Frag1 extends android.app.Fragment {
    private static TextView txt;
    private static View view;
    private int counter;

    public Frag1() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = null;
        view = inflater.inflate(R.layout.fragment_frag1, container, false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        txt = (TextView) getActivity().findViewById(R.id.txt);
        Button btn = (Button) getActivity().findViewById(R.id.btn1);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i("Frag1","val: "+counter);
                if(counter &gt; 0) return;
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                Frag2 f2 = new Frag2();
                ft.replace(R.id.content_frame, f2);
                ft.addToBackStack("f2");
                ft.commit();
            }
        });

        Button btn2 = (Button) getActivity().findViewById(R.id.btn2);
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AsyncCounter ac = new AsyncCounter(counter);
                ac.execute();
            }
        });

    }

    void setVal(int i){
        counter = i;
    }

}
class AsyncCounter extends AsyncTask&lt;Void, Integer, Void&gt; {
    private int cnt;
    private  Frag1 f1 = new Frag1();

    public AsyncCounter(int counter) {
        cnt = counter;
    }

    @Override
    protected  Void doInBackground(Void... params) {
        for(int i=0;i&lt;60;i++){
            publishProgress(i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        Log.i("ASYNC TASK","val: "+values[0]);
        cnt = values[0];
        f1.setVal(cnt);
    }

    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
    }

}
