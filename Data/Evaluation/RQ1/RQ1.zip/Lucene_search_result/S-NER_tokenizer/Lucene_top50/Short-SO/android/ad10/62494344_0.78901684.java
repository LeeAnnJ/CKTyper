public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private Button btn;
    private ImageView imageView2;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        imageView = findViewById(R.id.image);
        imageView2=findViewById(R.id.image2);
        btn = findViewById(R.id.save);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmap=viewToBitmap(imageView,imageView.getWidth(),imageView.getHeight());
                imageView2.setImageBitmap(bitmap);
                String timeStamp = new SimpleDateFormat(&quot;yyyyMMdd_HHmmss&quot;,
                        Locale.getDefault()).format(new Date());
                String imageFileName = &quot;JPEG_&quot; + timeStamp + &quot;.jpg&quot;;
                String pathName = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + &quot;/testApp&quot;;
                File directory = new File(pathName);
                if (!directory.exists()) {
                    directory.mkdirs();
                }

                File imageFile = new File(directory, imageFileName);
                if (!imageFile.exists()) {
                    try {
                        imageFile.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                try {
                    OutputStream fOut = new FileOutputStream(imageFile);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                    fOut.close();
                    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    File f = new File(imageFile.getAbsolutePath());
                    Uri contentUri = Uri.fromFile(f);
                    mediaScanIntent.setData(contentUri);
                    sendBroadcast(mediaScanIntent);
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(&quot;EXCEP &quot;, e.getMessage());
                }

                // Show a Toast with the save location
                Toast.makeText(getApplicationContext(), pathName, Toast.LENGTH_SHORT).show();

            }




        });
    }
    private static Bitmap viewToBitmap(View view, int widh, int hight)
    {
        Bitmap bitmap=Bitmap.createBitmap(widh,hight, Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap); view.draw(canvas);
        return bitmap;
    }
