Intent shareIntent = new Intent();
shareIntent.setAction(Intent.ACTION_SEND);
shareIntent.putExtra(Intent.EXTRA_TEXT, sharingString);
shareIntent.setType("text/plain");
startActivity(shareIntent);
public static void hideKeyBoard(Activity activity, View view) {

    InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);

    if (view == null) {
        view = new View(activity);
    }
    if (imm != null) {

        if(view.getWindowToken()!=null)
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

        if(view.getApplicationWindowToken()!=null)
            imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);

    }
    view.clearFocus();
}
if(getActivity()!=null){
    Utils.hideKeyBoard(getActivity(),getActivity().getCurrentFocus());
}
