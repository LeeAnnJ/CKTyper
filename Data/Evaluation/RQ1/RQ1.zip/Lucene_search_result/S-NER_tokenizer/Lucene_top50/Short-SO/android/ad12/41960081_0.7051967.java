SET PARENTDIR=%cd%
cd %PARENTDIR%\allure-2.13.5\bin
allure.bat open %PARENTDIR%
parent_dir=$(pwd)
cd $parent_dir/allure-2.13.5/bin
allure open $parent_dir
public static void generateAllureReport() {
    String pattern = &quot;dd-MM-yyyy_HH:mm:ss&quot;;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
    String reportfolder = &quot;allure-report_&quot; + simpleDateFormat.format(new Date());
    executeShellCmd(&quot;allure generate allure-results&quot;);
    executeShellCmd(&quot;mv allure-report &quot; + reportfolder);
    executeShellCmd(&quot;cp -R src/main/resources/config/allure-2.13.5 &quot;+reportfolder);
    executeShellCmd(&quot;cp src/main/resources/config/open_report_mac.sh &quot;+reportfolder);
    executeShellCmd(&quot;cp src/main/resources/config/open_report_windows.bat &quot;+reportfolder);
}

public static void executeShellCmd(String shellCmd) {
    try {
        Process process = Runtime.getRuntime().exec(shellCmd);
        process.waitFor();
    } catch (Exception e) {
        e.printStackTrace();
        System.out.println(&quot;Error in Executing the command &quot; + shellCmd);
    }
}
