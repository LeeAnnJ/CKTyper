public class SearchActivity extends Activity implements OnTouchListener {

    RelativeLayout rlSearchLayout;
    EditText etSearchBar;
    ListView lvSearchResult;
    private static String searchText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search);
        setTitle("SearchActivity.java");

        etSearchBar = (EditText) findViewById(R.id.etSearchBar);
        lvSearchResult = (ListView) findViewById(R.id.lvSearchResult);

        searchText = etSearchBar.getText().toString();
        lvSearchResult.setOnTouchListener(this);

        String[] objects = { "One", "two" };
        ArrayAdapter&lt;String&gt; adapter = new ArrayAdapter&lt;String&gt;(this,
                android.R.layout.simple_list_item_1, objects);
        lvSearchResult.setAdapter(adapter);
    }

    @Override
    public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(etSearchBar.getWindowToken(), 0);

        return false;
    }
}
