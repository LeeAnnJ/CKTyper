public class GridAdapter extends BaseAdapter implements Filterable {

public interface BtnClickListener {
    public abstract void onBtnClick(String position);
}
private BtnClickListener mClickListener = null;
Context context;
private ArrayList&lt;Products&gt; filteredProducts;
private ArrayList&lt;Products&gt; products;
private ItemFilter prodFilter = null;
private LayoutInflater inflater;
public GridAdapter(Context context, ArrayList&lt;Products&gt; products, BtnClickListener listener) {
    this.context = context;
    inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    this.products = products;
    this.filteredProducts = products;
    mClickListener = listener;
}
public class ProductsListHolder{
    public ImageView prod_img;
    public TextView prod_price;
    public Button prod_cart;
    public TextView prod_desc;
    public Button add_to_cart;
}
public ArrayList&lt;Products&gt; getProducts() {
    return products;
}
public void setProducts(ArrayList&lt;Products&gt; products) {
    this.products = products;
}

public GridAdapter(){
}
@Override
public int getCount() {
    if(products!=null)
        return products.size();
    return 0;
}
@Override
public Object getItem(int position) {
    if(products!=null &amp;&amp; position &gt;=0 &amp;&amp; position&lt;getCount() )
        return products.get(position);
    return null;
}
@Override
public long getItemId(int position) {
    if(products!=null &amp;&amp; position &gt;=0 &amp;&amp; position&lt;getCount() ){
        Products temp = products.get(position);
        return products.indexOf(temp);
    }
    return 0;
}
@Override
public View getView(final int position, View convertView, ViewGroup parent) {
    View view = convertView;
    ProductsListHolder productsListHolder;

    if(view == null){
        view = inflater.inflate(R.layout.product_adapter, parent, false);
        productsListHolder = new ProductsListHolder();
        productsListHolder.prod_img = (ImageView) view.findViewById(R.id.prod_img);
        productsListHolder.prod_price = (TextView) view.findViewById(R.id.prod_price);
        productsListHolder.prod_desc = (TextView) view.findViewById(R.id.prod_desc);
        productsListHolder.add_to_cart = (Button) view.findViewById(R.id.add_to_cart);
        productsListHolder.add_to_cart.setTag(products.get((int) getItemId(position)).getId());
        view.setTag(productsListHolder);
    }
        else{
        productsListHolder = (ProductsListHolder) view.getTag();
    }
    productsListHolder.add_to_cart.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(mClickListener != null)
                mClickListener.onBtnClick((String) v.getTag());
        }
    });
        Products product = products.get(position);
        setProduct(position,productsListHolder,product);
    return view;
}

private void setProduct(int position, final ProductsListHolder productsListHolder, Products p) {
    Picasso.with(context).load(p.getImageResours()).into(new Target(){

        @Override
        public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
            productsListHolder.prod_img.setBackground(new BitmapDrawable(context.getResources(), bitmap));
        }
        @Override
        public void onBitmapFailed(final Drawable errorDrawable) {
        }
        @Override
        public void onPrepareLoad(final Drawable placeHolderDrawable) {
        }
    });
    productsListHolder.prod_price.setText("Rs: ".concat(Integer.toString(p.getPrice())));
    productsListHolder.prod_desc.setText(p.name);
}
@Override
public void notifyDataSetChanged() {
    super.notifyDataSetChanged();
}
@Override
public Filter getFilter() {
    if(prodFilter == null)
        prodFilter = new ItemFilter();
    return prodFilter;
}
private class ItemFilter extends Filter {
    @Override
    protected FilterResults performFiltering(CharSequence constraint) {

        String filterString = constraint.toString().toUpperCase();
        FilterResults results = new FilterResults();
        final ArrayList&lt;Products&gt; list = filteredProducts;
        int count = list.size();
        final ArrayList&lt;Products&gt; nlist = new ArrayList&lt;Products&gt;(count);
        Products filtPro;
        if (constraint == null || constraint.length() == 0) {
            results.values = filteredProducts;
            results.count = filteredProducts.size();
        }
        else {
            for (int i = 0; i &lt; count; i++) {
                filtPro = list.get(i);
                if (filtPro.getName().toUpperCase().contains(filterString)) {
                    nlist.add(filtPro);
                }
            }
            results.values = nlist;
            results.count = nlist.size();
        }
        return results;
    }
    @SuppressWarnings("unchecked")
    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        products = (ArrayList&lt;Products&gt;) results.values;
        notifyDataSetChanged();
    }
}
