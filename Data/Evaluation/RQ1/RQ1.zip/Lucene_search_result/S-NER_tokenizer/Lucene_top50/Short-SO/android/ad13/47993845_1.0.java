public static void trackView(Activity activity, String view) {
    trackFBView(activity, view);
    trackGAView(view);
}

private static void trackFBView(Activity activity, String view) {
    if (activity == null) {
        return;
    }

    FirebaseAnalytics firebaseAnalytics = getFirebaseAnalytics();
    if (firebaseAnalytics == null) {
        return;
    }

    firebaseAnalytics.setCurrentScreen(activity, view, null);
}

private static void trackGAView(String view) {
    Tracker tracker = Utils.getTracker();
    if (tracker == null) {
        return;
    }
    tracker.setScreenName(view);
    tracker.send(new HitBuilders.ScreenViewBuilder().build());
}

public static FirebaseAnalytics getFirebaseAnalytics() {
    if (false == isGooglePlayServicesAvailable()) {
        return null;
    }

    return FirebaseAnalytics.getInstance(JStockApplication.instance());
}
private ViewPager.OnPageChangeListener getOnPageChangeListener() {
    return new ViewPager.OnPageChangeListener() {

        @Override
        public void onPageSelected(int position) {

            if (position == 0) {
                Utils.trackView(DetailedStockFragmentActivity.this, "InfoFragment");
private static void trackFBView(Activity activity, String view) {
    if (activity == null) {
        return;
    }

    FirebaseAnalytics firebaseAnalytics = getFirebaseAnalytics();
    if (firebaseAnalytics == null) {
        return;
    }

    firebaseAnalytics.setCurrentScreen(activity, view, null);

    // Question: Should I do this to help Firebase makes better prediction?
    firebaseAnalytics.logEvent(view + "_ScreenView", null);
}
