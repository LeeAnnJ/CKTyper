public class CompositeOnChangeFocusListener implements OnFocusChangeListener{
      private View currentFocusedView = null;
      public void onFocusChange(View v, boolean hasFocus) {
           //on a focus change.
           if(currentFocusedView != v){
               InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
               imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
           }
           //case a view in this composite has focus.
           if(hasFocus) {
              currentFocusedView = v;
           }
           //case no view using this composite is focused.
           if(v == currentFocusedView &amp;&amp; !hasFocus){
               currentFocusedView = null;
               InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
               imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
           }
    }
}
OnFocusChangeListener listner = new CompositeOnFocusChangeListener();
//Attach the same exact listener to both.
edittext1.setOnFocusChangeListener(listner);
edittext2.setOnFocusChangeListener(listner);
