public class ListFragment extends Fragment {

private static final int REQUEST_TITLE = 0;
private RecyclerView mRecyclerView;
private TaskAdapter mAdapter;

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
                         Bundle savedInstanceState) {
    // Inflate the layout for this fragment
    View view = inflater.inflate(R.layout.fragment_list, container, false);

    mRecyclerView = view.findViewById(R.id.the_task_list);
    mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
    updateUI();

    return view;
}

@Override
public void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);

    if(resultCode == Activity.RESULT_OK &amp;&amp; requestCode == ListFragment.REQUEST_TITLE) {
       // Do something.
    }

}

@Override
public void onResume() {
    super.onResume();
    updateUI();
}

public void updateUI() {
    List&lt;Task&gt; taskList = TaskLab.get(getActivity()).getTaskList();

    if(mAdapter == null) {
        mAdapter = new TaskAdapter(taskList);
        mRecyclerView.setAdapter(mAdapter);

    }else {
        mAdapter.notifyDataSetChanged();
    }
}

private class TaskAdapter extends RecyclerView.Adapter&lt;TaskHolder&gt;{

    private List&lt;Task&gt; mTaskList;

    public TaskAdapter(List&lt;Task&gt; taskList) {

        mTaskList = taskList;
    }

    @Override
    public TaskHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.task_list_layout, parent, false);
        return new TaskHolder(view);
    }

    @Override
    public void onBindViewHolder(TaskHolder holder, int position) {
        Task currentTask = mTaskList.get(position);
        holder.bindData(currentTask);
    }

    @Override
    public int getItemCount() {
        return mTaskList.size();
    }
}

private class TaskHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    private Task mTask;
    private TextView mTaskTitle;
    private CheckBox mSolved;

    private static final String DIALOG = "edit_dialog";

    public TaskHolder(View itemView) {
        super(itemView);
        itemView.setOnClickListener(this);

        mTaskTitle = itemView.findViewById(R.id.task_title);
        mSolved = itemView.findViewById(R.id.task_solved);
    }

    public void bindData(Task task) {
        mTask = task;
        mTaskTitle.setText(mTask.getTitle());
        mSolved.setChecked(mTask.isSolved());
    }

    @Override
    public void onClick(View view) {
        FragmentManager manager = getFragmentManager();
        EditTaskFragment dialog = EditTaskFragment.newInstance(mTask.getTitle());
        dialog.setTargetFragment(ListFragment.this, REQUEST_TITLE);
        dialog.show(manager, DIALOG);
    }
}

}
public class EditTaskFragment extends DialogFragment {

private EditText mTaskTitle;
private String mTaskName;

private static final String ARG_TASK_TITLE = "task_title";
public static final String EXTRA_TASK_TITLE = "list_app_task_title";

private void sendResult(int resultCode, String taskName) {
    if(getTargetFragment() == null) {
        return;
    }

    Intent intent = new Intent();
    intent.putExtra(EXTRA_TASK_TITLE,taskName);

    getTargetFragment().onActivityResult(getTargetRequestCode(),resultCode, intent);
}

public static EditTaskFragment newInstance(String taskName) {

    Bundle args = new Bundle();
    args.putString(ARG_TASK_TITLE, taskName);

    EditTaskFragment fragment = new EditTaskFragment();
    fragment.setArguments(args);

    return fragment;
}

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    mTaskName = getArguments().getString(ARG_TASK_TITLE);
}

@Override
public Dialog onCreateDialog(Bundle savedInstanceState) {

    View view = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_edit_task_dialog, null);
    mTaskTitle = view.findViewById(R.id.edit_task_title);
    mTaskTitle.setText(mTaskName);

    return new AlertDialog.Builder(getActivity())
            .setView(view)
            .setTitle(R.string.edit_task_dialog_title)
            .setPositiveButton(R.string.edit_task_dialog_positive, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    sendResult(Activity.RESULT_OK, mTaskTitle.getText().toString());
                }
            })
            .setNegativeButton(R.string.edit_task_dialog_negative, null)
            .create();
}
}
public class TaskLab {

private static TaskLab sTaskLab;
private List&lt;Task&gt; mTaskList;

private TaskLab(Context context){
    mTaskList = new ArrayList&lt;&gt;();
    for(int i = 0; i &lt; 10; i++) {
        Task task = new Task();
        task.setTitle("Task #" + i);
        task.setSolved(i%2 == 0);
        mTaskList.add(task);
    }
}

public static TaskLab get(Context context) {
    if(sTaskLab == null) {
        sTaskLab = new TaskLab(context);
    }

    return sTaskLab;
}

public List&lt;Task&gt; getTaskList(){
    return mTaskList;
}

public Task getTask(int id){
    for(Task task : mTaskList) {
        if(task.getId().equals(id)){
            return task;
        }
    }

    return null;
}
}
