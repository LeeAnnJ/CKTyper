InputMethodManager imm = (InputMethodManager)
            Asocijacije.this.getSystemService(Context.INPUT_METHOD_SERVICE);

            if (imm != null){
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
            }
case R.id.bKonacno:

                        }

                LayoutInflater layoutInflaterK = LayoutInflater.from(context);  
                View promptViewK = layoutInflaterK.inflate(R.layout.popup_answer, null);
                AlertDialog.Builder alertDialogBuilderK = new AlertDialog.Builder(context);
                // set prompts.xml to be the layout file of the alertdialog builder
                alertDialogBuilderK.setView(promptViewK);
                final EditText inputK = (EditText)promptViewK.findViewById(R.id.userInput);

                InputMethodManager imm = (InputMethodManager)
                Asocijacije.this.getSystemService(Context.INPUT_METHOD_SERVICE);

                if (imm != null){
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
                }

                alertDialogBuilderK
                                        .setCancelable(false)
                                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {
                                                        // get user input and set it to result

                                                        //some code of mine
                                                    }
                                                })
                                        .setNegativeButton("Cancel",
                                                new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {
                                                        dialog.cancel();
                                                    }
                                               });
                                // create an alert dialog

                                AlertDialog alertK = alertDialogBuilderK.create();
                                alertK.show();

                                break;
