// MainActivity.java

public class MainActivity extends AppCompatActivity {

    EditText myEditText;
    ListView myListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myEditText = findViewById(R.id.my_edit_text);
        myEditText.setOnTextChangedListener(
            (s, start, before, count) -&gt; populateMyListView(s)
        );
    
        myListView = findViewById(R.id.my_list_view);    
        myListView.setOnItemClickListener(
            (parent, view, position, id) -&gt; submitMyEditText()
        );
    }
}
InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
public void submitMyEditText(View view,EditText myEditText){
      hideSoftKeyBoard(view.getContext(),myEditText);
      myEditText.clearFocus();
}
public static void hideSoftKeyBoard(Context context,View view){
 InputMethodManager imm = (InputMethodManager) context.getSystemService(Activity.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
} 
