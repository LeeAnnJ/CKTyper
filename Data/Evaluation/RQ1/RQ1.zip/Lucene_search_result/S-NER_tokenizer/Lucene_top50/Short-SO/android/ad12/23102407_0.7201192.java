W/System.err( 6973): java.lang.NullPointerException
W/System.err( 6973):    at android.app.Activity.startActivityForResult(Activity.java:3505)
W/System.err( 6973):    at android.app.Activity.startActivityForResult(Activity.java:3466)
W/System.err( 6973):    at plugin.ZXing.integrator.IntentIntegrator.initiateScan(IntentIntegrator.java:88)
W/System.err( 6973):    at plugin.ZXing.integrator.IntentIntegrator.initiateScan(IntentIntegrator.java:31)
W/System.err( 6973):    at plugin.ZXing.ZXingJarActivity.show(ZXingJarActivity.java:24)
W/System.err( 6973):    at plugin.ZXing.LuaLoader$1.run(LuaLoader.java:238)
W/System.err( 6973):    at android.os.Handler.handleCallback(Handler.java:733)
W/System.err( 6973):    at android.os.Handler.dispatchMessage(Handler.java:95)
W/System.err( 6973):    at android.os.Looper.loop(Looper.java:157)
W/System.err( 6973):    at android.app.ActivityThread.main(ActivityThread.java:5872)
W/System.err( 6973):    at java.lang.reflect.Method.invokeNative(Native Method)
W/System.err( 6973):    at java.lang.reflect.Method.invoke(Method.java:515)
W/System.err( 6973):    at com.android.internal.os.ZygoteInit$MethodAndArgsCaller.run(ZygoteInit.java:1069)
W/System.err( 6973):    at com.android.internal.os.ZygoteInit.main(ZygoteInit.java:885)
W/System.err( 6973):    at dalvik.system.NativeStart.main(Native Method)
public static void initiateScan(Activity activity) {
    if (activity == null){
        Log.d("ZXING PLUGIN", "ACTIVITY IS NULL (1)");
    }
    initiateScan(activity, null, null, null);
}
public static void initiateScan(Activity activity, String scanFormatsString,
                                String characterSet, ZXingLibConfig config) {
    if (activity == null){
        Log.d("ZXING PLUGIN", "ACTIVITY IS NULL (2)");
    }
    Intent intent = new Intent(activity, CaptureActivity.class);

    if (intent == null){
        Log.d("ZXING PLUGIN", "INTENT IS NULL (1)");
    }
    intent.putExtra(Intents.Scan.FORMATS, scanFormatsString);
    intent.putExtra(Intents.Scan.CHARACTER_SET, characterSet);
    intent.putExtra(ZXingLibConfig.INTENT_KEY, config);
    try{
        activity.startActivityForResult(intent, REQUEST_CODE);
    } catch (NullPointerException e){
        e.printStackTrace();
    }
}
public class ZXingJarActivity extends Activity {
private Handler handler = new Handler();

public int show() {
    IntentIntegrator.initiateScan(ZXingJarActivity.this);
   return 0;
}

@Override
protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    switch (requestCode) {
        case IntentIntegrator.REQUEST_CODE:
            IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode,
                    resultCode, data);
            if (scanResult == null) {
                return;
            }
            final String result = scanResult.getContents();
            if (result != null) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("ZXING PLUGIN", result);
                    }
                });
            }
            break;
        default:
    }
}
}
activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ZXingJarActivity ActivityClass = new ZXingJarActivity();
                ActivityClass.show();
            }
} );
