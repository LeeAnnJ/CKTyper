&lt;EditText
    android:paddingStart="10dp"
    android:paddingEnd="10dp"
    android:id="@+id/et_search"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:inputType="text"
    android:imeOptions="actionSearch"
    android:hint="@string/hint"
    android:background="@android:color/transparent"/&gt;
&lt;item
    android:id="@+id/action_search"
    android:title="@string/search"
    app:showAsAction="ifRoom"
    android:icon="@drawable/ic_search"&gt;
&lt;/item&gt;
&lt;item
    android:id="@+id/share"
    android:title="@string/share_this_app"
    app:showAsAction="never"
    android:icon="@drawable/ic_share"&gt;
&lt;/item&gt;
&lt;item
    android:id="@+id/rate"
    android:title="@string/rate_this_app"
    app:showAsAction="never"
    android:icon="@drawable/ic_rate"&gt;
&lt;/item&gt;
&lt;item
    android:id="@+id/about"
    android:title="@string/about"
    app:showAsAction="never"
    android:icon="@drawable/ic_about"&gt;
&lt;/item&gt;
&lt;item
    android:id="@+id/more_apps"
    android:title="@string/more_apps"
    app:showAsAction="ifRoom"
    android:icon="@drawable/ic_more_apps"&gt;
&lt;/item&gt;
public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.my_menu, menu);
    MenuItem item = menu.findItem(R.id.more_apps);
    item.setShowAsAction(MenuItem.SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW);
    return true;
}
private void handleMenuSearch() {
    ActionBar actionBar = getSupportActionBar(); //get the actionbar

    if (isSearchOpened) { //test if the search is open
        if (actionBar != null) {
            if (et_search.getText().toString().length() &gt; 0) {
                et_search.getText().clear();
                doSearch(et_search.getText().toString()); //Clears the previous highlights
                //open the keyboard focused in the et_Search
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(et_search, InputMethodManager.SHOW_IMPLICIT);
                }
            } else {
                et_search.getText().clear();
                doSearch(et_search.getText().toString()); //Clears the previous highlights
                actionBar.setDisplayShowCustomEnabled(false); //disable a custom view inside the actionbar
                actionBar.setDisplayShowTitleEnabled(true); //show the title in the actionbar

                //hides the keyboard
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(et_search.getWindowToken(), 0);
                }

                //add the search icon in the actionbar
                mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_open_search));

                isSearchOpened = false;
            }
        }
    } else { //open the search entry
        if (actionBar != null) {
            actionBar.setDisplayShowCustomEnabled(true); //enable it to display a custom view in the
            //action bar
            actionBar.setCustomView(R.layout.search_bar); //add the custom view
            actionBar.setDisplayShowTitleEnabled(false); //hide the title

            et_search = actionBar.getCustomView().findViewById(R.id.et_search); //the text editor
        }

        //this is a listener to do a search when the user clicks on search button
        et_search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    doSearch(et_search.getText().toString());
                    //hides the keyboard
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (imm != null) {
                        imm.hideSoftInputFromWindow(et_search.getWindowToken(), 0);
                    }
                    return true;
                }
                return false;
            }
        });

        et_search.requestFocus();

        //open the keyboard focused in the et_Search
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showSoftInput(et_search, InputMethodManager.SHOW_IMPLICIT);
        }

        //add the close icon
        mSearchAction.setIcon(getResources().getDrawable(R.drawable.ic_close_search));

        isSearchOpened = true;
    }
}
if (isSearchOpened) { //test if the search is open
        if (actionBar != null) {
            actionBar.setDisplayShowCustomEnabled(false); //disable a custom view inside the actionbar
            actionBar.setDisplayShowTitleEnabled(true); //show the title in the action bar
            // your other codes
        }
}
