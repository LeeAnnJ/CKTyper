requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                                WindowManager.LayoutParams.FLAG_FULLSCREEN)
   public void onGlobalLayout() {
      AndroidActivity activity = screen.getActivity();
      Window window = activity.getWindow();
      View view = window.getDecorView();  

      view.getWindowVisibleDisplayFrame(currentlyVisibleRect);

      if(currentlyVisibleRect.top &gt; 0) {
         // Below code will not work....but you get the idea
         Field field1 = view.getClass().getDeclaredField("mAttachInfo");
         Field field2 = field.get(view).getClass().getDeclaredField("mVisibleInsets");
         Rect rect = field2.get(field1.get(view));

         rect.top = 0;
      }
   }
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsoluteLayout;
import android.widget.ScrollView;

public class AndroidLayoutManager {

   private final Activity activity;
   private final Rectangle bounds;
   private final String name;

   public AndroidLayoutManager(Activity activity, Rectangle bounds, String name) {
      this.activity = activity;
      this.bounds = bounds;
      this.name = name;
   }

   public ViewGroup createLayout(ViewLayout viewLayout, ViewComponent headerView, ViewComponent mainView, ViewComponent footerView) {
      AbsoluteLayout relativeLayout = new AbsoluteLayout(activity);
      AbsoluteLayout.LayoutParams fullScreenParams = new AbsoluteLayout.LayoutParams(bounds.width, bounds.height, 0, 0);

      if(viewLayout.isHeaderIncluded()) {
         AbsoluteLayout.LayoutParams headerViewParams = headerView.getLayoutParams();
         View view = headerView.getView();

         view.setLayoutParams(headerViewParams);
         relativeLayout.addView(view, headerViewParams);
      }
      if(viewLayout.isMainIncluded()) {
         AbsoluteLayout.LayoutParams mainViewParams = mainView.getLayoutParams();
         View view = mainView.getView();
         View scrollView = createScrollView(view);

         scrollView.setLayoutParams(mainViewParams);
         relativeLayout.addView(scrollView, mainViewParams);
      }
      if(viewLayout.isFooterIncluded()) {
         AbsoluteLayout.LayoutParams footerViewParams = footerView.getLayoutParams();
         View view = footerView.getView();

         view.setLayoutParams(footerViewParams);
         relativeLayout.addView(view, footerViewParams);
      }
      relativeLayout.requestLayout();
      activity.setContentView(relativeLayout, fullScreenParams);
      mainView.getView().requestFocus();
      activity.getWindow().getDecorView().requestLayout();

      return relativeLayout;
   }

   private View createScrollView(View view) {
      ScrollView scrollView = new ScrollView(activity);  

      // ******** WTF??? This is causing a strange layout problem *******
      //scrollView.setFocusableInTouchMode(true);
      scrollView.requestFocus();
      scrollView.setFocusable(true);
      scrollView.setVerticalScrollBarEnabled(false);
      scrollView.addView(view);
      scrollView.setFillViewport(true);

      return scrollView;
   }

   @Override
   public String toString() {
      return name;
   }

   public static class ViewLayout {

      private Rectangle header;
      private Rectangle main;
      private Rectangle footer;

      public ViewLayout(Rectangle header, Rectangle main, Rectangle footer) {
         this.header = header;
         this.main = main;
         this.footer = footer;
      }

      public boolean isMainIncluded() {
         return main != null;
      }

      public boolean isFooterIncluded() {
         return footer != null;
      }

      public boolean isHeaderIncluded() {
         return header != null;
      }

      public Point getHeaderPoint() {
         return new Point(0, 0);
      }

      public Point getMainPoint() {
         if(header != null) {
            return new Point(0, header.height);
         }
         return new Point(0, 0);
      }

      public Point getFooterPoint() {
         if(header == null) {
            return new Point(0, main.height);
         }
         return new Point(0, main.height + header.height);
      }

      public int getHeight() {
         int totalHeight = main.height;

         if(header != null) {
            totalHeight += header.height;
         }
         if(footer != null) {
            totalHeight += footer.height;
         }
         return totalHeight;
      }
   }

   public static class ViewComponent {

      private final Rectangle rectangle;
      private final Point origin;
      private final View view;

      public ViewComponent(View view, Rectangle rectangle, Point origin) {
         this.view = view;
         this.rectangle = rectangle;
         this.origin = origin;
      }

      public AbsoluteLayout.LayoutParams getLayoutParams() {
         return new AbsoluteLayout.LayoutParams(rectangle.width, rectangle.height, origin.x, origin.y);
      }

      public View getView() {
         return view;
      }
   }
}
