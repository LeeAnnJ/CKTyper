public Config() {
    this.configFile = new Properties();
    InputStream input = null;
    try {
        input = new FileInputStream("resources/config.properties");
        this.configFile.load(input);
    } catch (IOException e) {
        System.err.println("[ err. ] " + e);
    }
}

public static void initConfig() {
    if(!new File("resources/config.properties").exists()) {
        Properties prop = new Properties();
        prop.setProperty("test_key_1", "Value1");
        prop.setProperty("test_key_2", "Value2");
        prop.setProperty("test_key_3", "Value3");
        prop.setProperty("test_key_4", "Value4");
        prop.keySet();
        try {
            prop.store(new FileOutputStream("resources/config.properties"), null);
            System.out.println("[ info ] Configuration file successful created.");
        } catch (IOException e) {
            System.err.println("[ err. ] " + e);
        }
    }
}
test_key_3=Value3
test_key_2=Value2
test_key_1=Value1
test_key_4=Value4
test_key_1=Value1
test_key_2=Value2
test_key_3=Value3
test_key_4=Value4
