// Function which capture Screenshot
public Bitmap captureScreenShot(View view) {
    /*
     * Creating a Bitmap of view with ARGB_4444.
     * */
    Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_4444);
    Canvas canvas = new Canvas(bitmap);
    Drawable backgroundDrawable = view.getBackground();

    if (backgroundDrawable != null) {
        backgroundDrawable.draw(canvas);
    } else {
        canvas.drawColor(Color.parseColor("#80000000"));
    }
    view.draw(canvas);
    return bitmap;
}

// Function which Save image.
private void saveImage(Bitmap bitmap) {
    File file = // Your Storage directory name + your filename
    if (file == null) {
        return;
    }
    try {
        FileOutputStream fos = new FileOutputStream(file);
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        fos.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
File file = new  File(“yourImageFilePath”);
if(file.exists())
{
    yourImageView.setImageURI(Uri.fromFile(file));
}
File file = new  File(“yourImageFilePath”);
if(file.exists())
{
  Bitmap bitmap = BitmapFactory.decodeFile(file.toString());
  yourImageView.setImageBitmap(bitmap);
}
