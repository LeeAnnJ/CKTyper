public static Bitmap TakeBitmapFromDialog(View v, int width, int height) {
Bitmap b = Bitmap.createBitmap(width , height, Bitmap.Config.ARGB_8888);                
Canvas c = new Canvas(b);
v.layout(0, 0, v.getLayoutParams().width, v.getLayoutParams().height);
v.draw(c);
return b;
}
 View v1 = view.getRootView();
 v1.setDrawingCacheEnabled(true);
 Bitmap bm = v1.getDrawingCache();
 BitmapDrawable bitmapDrawable = new BitmapDrawable(bm);
Bitmap cs = null;
view.setDrawingCacheEnabled(true);
view.buildDrawingCache(true);
cs = Bitmap.createBitmap(view.getDrawingCache());
Canvas canvas = new Canvas(cs);
view.draw(canvas);
canvas.save();
view.setDrawingCacheEnabled(false);
 String path = Images.Media.insertImage(getContentResolver(), cs,
                "MyImage", null);
 Uri file = Uri.parse(path);
 Intent sharingIntent = new Intent(Intent.ACTION_SEND);
 sharingIntent.setType("image/png");
 sharingIntent.putExtra(Intent.EXTRA_STREAM, file);
 startActivity(Intent.createChooser(sharingIntent,
                    "Share image using"));
