mViewPager = (ViewPager)findViewById(R.id.pager);
mViewPager.setOffscreenPageLimit(2);
public class SliderPagerAdapter extends PagerAdapter {

    private Activity activity;
    private ArrayList&lt;String&gt; images;

    public SliderPagerAdapter(Activity activity) {
        this.activity = activity;

    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {

        View view = LayoutInflater.from(container.getContext())
                .inflate(R.layout.item_slider, container, false);
        ImageView allImages = null;

      /MH: Loading Images in slider
        if(images.get(position).csImageFull.length()&gt;0)
        {
            CommonMethods.ShowImage(myContext, imageListing, allImages.get(position).csImageFull);

        }
        else
        {
            CommonMethods.ShowImage(myContext, allImages, images.get(position).csImageMedium);

        }

        container.addView(itemView);



        return view;
    }

    public void setData(ArrayList&lt;String&gt; images) {
        this.images = images;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return images == null ? 0 : images.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object obj) {
        return view == obj;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        View view = (View) object;
        container.removeView(view);
    }
}
