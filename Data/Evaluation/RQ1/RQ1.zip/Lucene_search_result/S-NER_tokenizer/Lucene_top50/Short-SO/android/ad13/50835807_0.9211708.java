public class ImageAdapter extends PagerAdapter {

private ImageView imageView;
private Context context;
private LayoutInflater inflater;
public ArrayList&lt;String&gt; listOfAllImages = new ArrayList&lt;&gt;();
private static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 1;

public ImageAdapter(Context context) {
    this.context = context;
    if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.M) {
        requestRead();
        checkPermission();
    } else {
        getAllShownImagesPath();
    }
}

private void requestRead() {
    if (ContextCompat.checkSelfPermission(context,
            Manifest.permission.READ_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED) {

        ActivityCompat.requestPermissions((Activity) context,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
    } else {
        getAllShownImagesPath();
    }
}

private void checkPermission(){
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
        getAllShownImagesPath();
    }
}

@Override
public int getCount() {
    return listOfAllImages.size();
}

@Override
public boolean isViewFromObject(View view, Object object) {
    return view == object;
}

@Override
public Object instantiateItem(ViewGroup container, int position) {
    inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View view = inflater.inflate(R.layout.photopager, null);
    imageView = (ImageView) view.findViewById(R.id.photoView2);

    Glide.with(context).load(listOfAllImages.get(position))
            .thumbnail(1f)
            .crossFade()
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .into(imageView);

    ViewPager viewPager = (ViewPager) container;
    viewPager.addView(view, 0);
    return view;
}

@Override
public void destroyItem(ViewGroup container, int position, Object object) {
    ViewPager vp = (ViewPager) container;
    View view = (View) object;
    vp.removeView(view);
}

private void getAllShownImagesPath() {
    Uri uri;
    Cursor cursor;
    int column_index_data;
    String absolutePathOfImage;
    uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

    String[] projection = {MediaStore.MediaColumns.DATA,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME};

    cursor = context.getContentResolver().query(uri, projection, null,
            null, null);

    column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
    while (cursor.moveToNext()) {
        absolutePathOfImage = cursor.getString(column_index_data);
        listOfAllImages.add(absolutePathOfImage);
    }

    cursor.close();
}
}
