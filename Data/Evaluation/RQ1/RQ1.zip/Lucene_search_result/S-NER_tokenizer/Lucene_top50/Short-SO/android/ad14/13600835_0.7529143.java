public class MainPageActivity extends SherlockFragmentActivity implements
        ActionBar.OnNavigationListener {

    MenuItem menuItem;
    EditText searchText;
    public static Context mContext;
    public static DataAdapter dataAdapter;
    ArrayList&lt;String&gt; accountList;
    public static List&lt;View&gt; currentViewBeingChanged = new ArrayList&lt;View&gt;();

    public static LayoutInflater layoutInflater;
    public static String checktab = "running", nameComp;
    int isRefresh;
    public static boolean isAutoRefresh = true;
    public static ArrayList&lt;String&gt; listItems;
    public static boolean check;
    public static boolean isAtleastOnce = true, listToBeRefreshed = false;
    public static ActionBar actionBar;
    public static int itemPosition, listPosition;
    public static FragmentManager fragmentManager;
    InputMethodManager imm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        mContext = this;

        layoutInflater = getLayoutInflater();

        fragmentManager = getSupportFragmentManager();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_page);

        actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);

        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

        Context context = getSupportActionBar().getThemedContext();

        ArrayAdapter&lt;String&gt; adapter = new ArrayAdapter&lt;String&gt;(context,
                android.R.layout.simple_spinner_dropdown_item);
        adapter.clear();
        for (int i = 0; i &lt; ManageAccountLists.accountList.size(); i++) {
            adapter.add(ManageAccountLists.accountList.get(i));
        }

        actionBar.setListNavigationCallbacks(adapter, this);

        tabPagerFunction();

    }

    public void tabPagerFunction() {

        FragmentPagerAdapter adapter = new GoogleMusicAdapter(
                getSupportFragmentManager());
        adapter.notifyDataSetChanged();

        ViewPager pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adapter);

        checktab = "running";

        final TabPageIndicator indicator = (TabPageIndicator) findViewById(R.id.indicator);
        indicator.setViewPager(pager);

        pager.setOnPageChangeListener(new OnPageChangeListener() {

            @Override
            public void onPageSelected(int arg0) {

                System.out.println("Tab selected..................");

                if (arg0 == 0) {

                    // Running tab is selected
                    indicator.setCurrentItem(arg0);

                    checktab = "running";
                    RunningInstancesActivity runningInstancesActivity = new RunningInstancesActivity();
                    runningInstancesActivity.callThread();

                } else {

                    // Stopped tab is selected
                    indicator.setCurrentItem(arg0);
                    checktab = "stopped";
                    StoppedInstancesActivity stoppedInstancesActivity = new StoppedInstancesActivity();
                    stoppedInstancesActivity.callThread();
                    InstanceStatusUpdate.isOnPostExecute = false;

                }

            }

            @Override
            public void onPageScrolled(int arg0, float arg1, int arg2) {

            }

            @Override
            public void onPageScrollStateChanged(int arg0) {

            }
        });

    }

    class GoogleMusicAdapter extends FragmentPagerAdapter {

        private final String[] CONTENT = new String[] { "Running", "Stopped" };

        public GoogleMusicAdapter(FragmentManager fm) {
            super(fm);
            notifyDataSetChanged();

        }

        @Override
        public Fragment getItem(int position) {

            switch (position) {
            /** Running tab is selected */
            case 0:
                checktab = "stopped";
                return RunningInstancesActivity.newInstance(0);

                /** Stopped tab is selected */
            case 1:

                checktab = "running";
                return StoppedInstancesActivity.newInstance(1);
            }
            return null;

        }

        @Override
        public CharSequence getPageTitle(int position) {
            return CONTENT[position % CONTENT.length].toUpperCase();
        }

        public CharSequence getPageTitle(int position, int number) {
            return CONTENT[position % CONTENT.length].toUpperCase();
        }

        @Override
        public int getCount() {
            return CONTENT.length;
        }
    }

    @Override
    public boolean onNavigationItemSelected(int itemPosition, long itemId) {

             System.out.println("Navigation item selected");

        // Performs fetching
    }



    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {

        System.out.println("Dispatch touvh event..");

        return super.dispatchTouchEvent(ev);

    }

}
