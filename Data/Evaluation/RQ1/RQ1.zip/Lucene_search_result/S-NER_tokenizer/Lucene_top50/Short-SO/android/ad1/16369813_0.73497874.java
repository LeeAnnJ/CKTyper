public void onPause(){
    super.onPause();
    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
}
package com.example.test_project;

import java.util.Calendar;

import com.example.test_project.R.string;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

public class NewWorkout extends Activity {
/** Called when the activity is first created. */

private TextView mDateDisplay;
private Button mPickDate;
private int mYear;
private int mMonth;
private int mDay;

private TextView mTimeDisplay;
private Button mTimePicker1;
private int hour;
private int minute;
private String zone;

static final int DATE_DIALOG_ID = 0;
static final int TIME_DIALOG_ID = 99;

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_new_workout);
    final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

    // capture our View elements
    mDateDisplay = (TextView) findViewById(R.id.dateOfWorkoutTextView);
    mPickDate = (Button) findViewById(R.id.dateOfWorkoutButton);
    mTimeDisplay = (TextView) findViewById(R.id.timeOfWorkoutTextView);
    mTimePicker1 = (Button) findViewById(R.id.timeOfWorkoutButton);


    // add a click listener to the button
    mPickDate.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            showDialog(DATE_DIALOG_ID);
        }
    });

    // get the current date
    final Calendar c = Calendar.getInstance();
    mYear = c.get(Calendar.YEAR);
    mMonth = c.get(Calendar.MONTH);
    mDay = c.get(Calendar.DAY_OF_MONTH);

    final Calendar t = Calendar.getInstance();
    hour = t.get(Calendar.HOUR_OF_DAY);
    minute = t.get(Calendar.MINUTE);

    //set the current time into the textview



    mTimePicker1.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
            showDialog(TIME_DIALOG_ID);
        }
    });

}

// updates the date in the TextView
private void updateDisplay() {
        StringBuilder string1 = new StringBuilder()
                // Month is 0 based so add 1
                .append(mMonth + 1).append("-")
                .append(mDay).append("-")
                .append(mYear).append(" ");
    mDateDisplay.setText(string1);
}

// the callback received when the user "sets" the date in the dialog
private DatePickerDialog.OnDateSetListener mDateSetListener =
        new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year,
                                  int monthOfYear, int dayOfMonth) {
                mYear = year;
                mMonth = monthOfYear;
                mDay = dayOfMonth;
                updateDisplay();
            }
        };

private TimePickerDialog.OnTimeSetListener timePickerListener = 
         new TimePickerDialog.OnTimeSetListener() {
     public void onTimeSet(TimePicker view, int selectedHour, int selectedMinute) {
         hour = selectedHour;
         minute = selectedMinute;
         updateTimeDisplay();
     }
 };

//set current time into textView
private void updateTimeDisplay() {
     if(hour &gt; 12){
         hour -= 12;
         zone = "PM";
     }
     else
         zone = "AM";

     if(minute &gt;= 10){
     mTimeDisplay.setText(new StringBuilder().append(hour)
                .append(":").append(minute).append(" ").append(zone));
     }
     else
         mTimeDisplay.setText(new StringBuilder().append(hour)
                .append(":").append("0").append(minute).append(" ").append(zone));
 }

@Override
protected Dialog onCreateDialog(int id) {
    switch (id) {
    case DATE_DIALOG_ID:
        return new DatePickerDialog(this, mDateSetListener, mYear, mMonth,
                mDay);
    case TIME_DIALOG_ID:
        return new TimePickerDialog(this, timePickerListener, hour, minute, false);
    }
    return null;
}



public void nameOfWorkout(View view){
    AlertDialog.Builder nameOfWorkoutAlert = new AlertDialog.Builder(this);
    nameOfWorkoutAlert.setTitle("Enter a Name for This Workout");

    // Set an EditText view to get user input 
    final EditText input = new EditText(this);
    nameOfWorkoutAlert.setView(input);
    // Prepping the soft keyboard to open with the AlertDialog
    final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE); 
    imm.hideSoftInputFromWindow(input.getWindowToken(), 0);

    nameOfWorkoutAlert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
    public void onClick(DialogInterface dialog, int whichButton) {
      String value = input.getText().toString();
      TextView edit = (TextView) findViewById(R.id.nameOfWorkoutTextView);
      edit.setText(value);
      imm.toggleSoftInput(InputMethodManager.RESULT_HIDDEN, 0);
      }
    });

    nameOfWorkoutAlert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
      public void onClick(DialogInterface dialog, int whichButton) {
          imm.toggleSoftInput(InputMethodManager.RESULT_HIDDEN, 0);
      }
    });
    //alert.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    nameOfWorkoutAlert.show();

    //Causing the soft keyboard to open with the AlertDialog
    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
}

public void onPause(){
    super.onPause();
    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
}

public void typeOfWorkout(View view){
    final String [] items=new String []{"Weight-lifting","Cardio","Mixture"};
    AlertDialog.Builder builder=new AlertDialog.Builder(this);
    builder.setTitle("Select Today's Workout type");

    builder.setItems(items, new android.content.DialogInterface.OnClickListener() {

    @Override
    public void onClick(DialogInterface dialog, int which) {
    // TODO Auto-generated method stub
    TextView txt=(TextView)findViewById(R.id.typeOfWorkoutTextView);
    txt.setText(items[which]);
    }
    });

    builder.show();

}

}
public class NewWorkout extends Activity {

    private EditText input
    ...
    public void nameOfWorkout(View view){
        // Set an EditText view to get user input 
        input = new EditText(this);
        ...
    }

    public void onPause() {
        if (input != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        }
        super.onPause();
    }
    ...
}
public void onPause()
{
  super.onPause();
getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
}
