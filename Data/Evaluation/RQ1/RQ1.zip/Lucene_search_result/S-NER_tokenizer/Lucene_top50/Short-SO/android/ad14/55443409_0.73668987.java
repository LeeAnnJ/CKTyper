@Override
    public void onBindViewHolder(final SearchViewHolder holder, int position) {

        holder.full_name.setText(fullNameList.get(position));
        holder.full_name.setBackgroundColor(selectedPos == position ? Color.GREEN : Color.LTGRAY);

        holder.full_name.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(final View v) {


                if (holder.getAdapterPosition() == RecyclerView.NO_POSITION) return;
                notifyItemChanged(selectedPos);
                selectedPos = holder.getLayoutPosition();
                notifyItemChanged(selectedPos);
                Toast.makeText(context, ((TextView) v).getText(), Toast.LENGTH_SHORT).show(); //Here I get the text string


                // close keyboard on click

                v.clearFocus();
                InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                        imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }



            }
        });
    }
