public class MyCustomAdapterDishes extends RecyclerView.Adapter&lt;RecyclerView.ViewHolder&gt;  implements View.OnClickListener{

    private Button sendBtn;
    private ChatAdapter adapter;
    private ArrayList&lt;Dishes&gt; dish;
    private Context mContext;
    View rowView;

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_ITEM = 1;
    private static final int TYPE_FOOTER = 2;
    private static final int TYPE_Paid = 3;
    int id =0;

    CommentsAsyncTask Commentstask;
    Typeface custom_font;
        public MyCustomAdapterDishes(Context context, ArrayList&lt;Dishes&gt; dish) {
                this.dish = dish;
                this.mContext = context;
            custom_font = Typeface.createFromAsset(mContext.getAssets(), "fonts/HelveticaNeueLTArabic-Light.ttf");
        }

        @Override
        public  RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {

            if(viewType == TYPE_HEADER) {
                View v = LayoutInflater.from (mContext).inflate (R.layout.drawer_header, null);
                return new HeaderViewHolder (v);
            }
            else if(viewType == TYPE_Paid&amp;&amp;id==0) {
                View v = LayoutInflater.from (mContext).inflate (R.layout.drawer_header, null);
                id=2;
                return new HeaderViewHolder (v);
            }

            else if(viewType == TYPE_FOOTER) {
                View v = LayoutInflater.from (mContext).inflate (R.layout.activity_chat, null);
                return new FooterViewHolder (v);
            } else if(viewType == TYPE_ITEM) {
                View v = LayoutInflater.from (mContext).inflate (R.layout.dish_row_item, null);
                v.setOnClickListener(this);
                return new GenericViewHolder (v);
            }
            return null;
        }

    @Override
    public int getItemViewType (int position) {
        if(isPositionHeader (position)) {
            return TYPE_HEADER;
        } else if(isPositionFooter (position)) {
            return TYPE_FOOTER;
        }
        else if(isPositionPaid (position)&amp;&amp;id&lt;=1) {
            return TYPE_Paid;
        }

        return TYPE_ITEM;
    }


    private boolean isPositionHeader (int position) {
        return position == 0;
    }

    private boolean isPositionPaid (int position) {

        return  !(dish.get (position-1).getIsFree());
    }


    private boolean isPositionFooter (int position) {
        return position == dish.size () + 1;
    }


    private Dishes getItem (int position) {
        return dish.get (position);
    }


    @Override
    public void onClick(final View view) {

    }


        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

            if(holder instanceof HeaderViewHolder) {
                HeaderViewHolder headerHolder = (HeaderViewHolder) holder;
            }

        else if(holder instanceof FooterViewHolder)

    {
        FooterViewHolder footerHolder = (FooterViewHolder) holder;
    }

    else if(holder instanceof GenericViewHolder) {
                Dishes currentItem = getItem(position - 1);
                GenericViewHolder genericViewHolder = (GenericViewHolder) holder;


                if(!currentItem.getIsFree()){
                    genericViewHolder.arrow.setVisibility(View.INVISIBLE);
                    genericViewHolder.lock.setVisibility(View.VISIBLE);
                }
                //Download image using picasso library
                Picasso.with(mContext).load(currentItem.getDishThumbnailUrl())
                        .error(R.drawable.no_internet)
                        .tag(mContext)
                        .placeholder( R.drawable.no_spic)
                        .into(genericViewHolder.imageView);

                genericViewHolder.DishName.setTypeface(custom_font);
                genericViewHolder.DishName.setText(currentItem.getDishName());
                genericViewHolder.LikesCount.setText(currentItem.getDishLikesCount());

                View.OnClickListener clickListener = new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //   CustomViewHolder holder = (CustomViewHolder) view.getTag();
                        // int position = holder.getPosition();

                        //     Dishes di = dish.get(position);
                        //   Toast.makeText(mContext, di.getDishName(), Toast.LENGTH_SHORT).show();
                    }
                };
    }
        }  

    @Override
        public int getItemCount() {
                return dish.size () + 2;
        }

    class FooterViewHolder extends RecyclerView.ViewHolder {


        public FooterViewHolder (View itemView) {
            super (itemView);
        }
    }

    class HeaderViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitleHeader;

        public HeaderViewHolder (View itemView) {
            super (itemView);
         //   this.txtTitleHeader = (TextView) itemView.findViewById (R.id.txtHeader);
        }
    }

    class GenericViewHolder extends RecyclerView.ViewHolder {
        protected ImageView lock;
        protected ImageView arrow;
        protected ImageView imageView;
        protected TextView DishName;
        protected TextView LikesCount;

        public GenericViewHolder (View view) {
            super (view);
            this.imageView = (ImageView) view.findViewById(R.id.thumbnail);
            this.DishName = (TextView) view.findViewById(R.id.DishName);
            this.LikesCount = (TextView) view.findViewById(R.id.LikesCount);
            this.lock= (ImageView) view.findViewById(R.id.lock);
            this.arrow=(ImageView) view.findViewById(R.id.arrow);


            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        }
    }
}
