&lt;activity
        android:name=".MainActivity"
        android:windowSoftInputMode="adjustPan" /&gt;
    @SuppressWarnings("ConstantConditions")
    public void hideKeyBoard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
    }
   this.getWindow().setSoftInputMode
    (WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
public void hideKeyboard(final boolean hide) {
    // Check if no view has focus:
    View view = this.getCurrentFocus();
    if (view == null) {
        return;
    }
    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    if (hide) {
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    } else {
        new Handler().postDelayed(() -&gt; imm.showSoftInput(view, 0), 50);
    }
}
    &lt;activity android:name=".Viewschedule"
          android:screenOrientation="portrait"
          android:windowSoftInputMode="adjustPan"&gt;&lt;/activity&gt;
   InputMethodManager imgr = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
  imgr.showSoftInput(view, 0);
