protected void setUp() throws Exception {
    super.setUp();
    mLithium = (LithiumExtension) Trio.getInstance(new LithiumExtension(this))
            .getExtension();
    config = StorefrontConfig.getInstance();
    Resources resources = getActivity().getResources();
    AssetManager asM = resources.getAssets();
    InputStream in = asM.open("config.global");
    OutputStream out = asM.openFd("config.properties").createOutputStream();
    config.readConfig(in, out);
    setTestSettings();
}
public class Config {

private static Config instance;
public Properties prop;

static {
    instance = new Config();
}

private Config () {
    prop = new Properties();
}

public void readConfig(InputStream in, OutputStream out) {

    try {

        prop.load(in);
        in.close();

        prop.store(out, "yay");
        out.close();
    }
    catch (Exception e) {
        System.out.println("Failed to create properties");
        System.exit(3);
        Log.d("Config", "Failed to create properly initialized config class");
    }
}

public static Config getInstance() {

    if(instance == null)
        instance = new Config();
    return instance;
}

public String getProperty (String key) {
    return prop.getProperty(key);
}
}
