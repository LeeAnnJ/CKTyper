 public static Bitmap loadBitmapFromView(View view) {
        Bitmap createBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        view.layout(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        view.draw(canvas);
        return createBitmap;
    }


textView.setText(" " + editText.getText() + " ");
                    Bitmap bitmap = loadBitmapFromView(textView);
                    loadSticker(bitmap);
               &lt;TextView
                android:id="@+id/text"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_centerHorizontal="true"
                android:layout_centerVertical="true"
                android:gravity="center_horizontal|center_vertical"
                android:padding="20dp"
                android:scrollbars="vertical"
                android:shadowColor="#fff"
                android:shadowDx="4"
                android:shadowDy="-4"
                android:shadowRadius="1"
                android:text="Your Text Here"
                android:textColor="#000"
                android:textSize="25sp"
                android:textStyle="bold" /&gt;
