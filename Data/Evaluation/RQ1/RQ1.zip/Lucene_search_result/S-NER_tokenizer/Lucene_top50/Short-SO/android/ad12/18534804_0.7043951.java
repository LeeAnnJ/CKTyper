public List&lt;? extends Fragment&gt; getFragments(){
    List&lt;? extends Fragment&gt; ipsumFragments = new ArrayList&lt;Fragment&gt;();
    ipsumFragments.add(BaconIpsumFragment.newInstance());
    ipsumFragments.add(BuseyIpsumFragment.newInstance());
    ipsumFragments.add(LoremIpsumFragment.newInstance());

    return ipsumFragments;
}
public class BaconIpsumFragment extends Fragment{

public static final BaconIpsumFragment newInstance(){

    BaconIpsumFragment baconFragment = new BaconIpsumFragment();
    Bundle args = new Bundle();
    baconFragment.setArguments(args);
    return baconFragment;   
}

@Override
public void onAttach(Activity activity){
    // Attempt to attach to the parent activity
    super.onAttach(activity);
}

// Called when the parent activity creates the fragment
@Override
public void onCreate(Bundle savedInstanceState){
    // Perform the default behavior
    super.onCreate(savedInstanceState);
}

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
    super.onCreateView(inflater, container, savedInstanceState);
    return inflater.inflate(R.layout.bacon_fragment, container, false);
}

@Override
public void onActivityCreated(Bundle savedInstanceState){
    // Last attempt to change any variables
    super.onActivityCreated(savedInstanceState);
}

}
public class MainActivity extends FragmentActivity {

private ActionBar tabbedActionBar = null;   
private String [] ipsumsArray = null;
private Resources resources = null;
private FragmentManager manager = null;
private FragmentTransaction transaction = null;

private List&lt;Fragment&gt; mIpsumFragments = null;
private LoremIpsumViewPager pagerAdapter = null;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    // Get the resources object
    resources = getResources();
    // get the String array from resources
    ipsumsArray = resources.getStringArray(R.array.ipsums_array);

    // Get all the fragments that we will attempt to display
    mIpsumFragments = getFragments();

    // get a reference to the action bar
    tabbedActionBar = getActionBar();
    // set the navigation mode for the action bar
    tabbedActionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

    for (int i = 0; i &lt; ipsumsArray.length; i++){
        Tab tab = tabbedActionBar.newTab();
        tab.setText(ipsumsArray[i]);
        tab.setTabListener(tabListener);
        tabbedActionBar.addTab(tab);
    }

//      setDefaultTab();


}

@Override
public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.main, menu);
    return true;
}

private TabListener tabListener = new TabListener(){

    @Override
    public void onTabReselected(Tab tab, FragmentTransaction arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onTabSelected(Tab tab, FragmentTransaction arg1) {

        // Get the fragment manager
        manager = getFragmentManager();
        transaction = manager.beginTransaction();


        int tabSelected = tab.getPosition();


    @Override
    public void onTabUnselected(Tab tab, FragmentTransaction arg1) {
        // TODO Auto-generated method stub

    }

};



private List&lt;Fragment&gt; getFragments(){
    List&lt;Fragment&gt; ipsumFragments = new ArrayList&lt;Fragment&gt;();

    ipsumFragments.add(BaconIpsumFragment.newInstance());
    ipsumFragments.add(BuseyIpsumFragment.newInstance());
    ipsumFragments.add(LoremIpsumFragment.newInstance());

    return ipsumFragments;
}

}
