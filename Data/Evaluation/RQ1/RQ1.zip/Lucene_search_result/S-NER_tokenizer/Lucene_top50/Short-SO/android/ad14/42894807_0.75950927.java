public class DBAdapter {

/////////////////////////////////////////////////////////////////////
//  Constants &amp; Data
/////////////////////////////////////////////////////////////////////
// For logging:
private static final String TAG = "DBAdapter";

// DB Fields
public static final String KEY_ROWID = "_id";
public static final int COL_ROWID = 0;
/*
 * CHANGE 1:
 */
// TODO: Setup your fields here:
public static final String KEY_IMM     = "imm";
public static final String KEY_TYPE    = "type";
public static final String KEY_WEIGHT  = "weight";
public static final String KEY_CG      = "cg";
public static final String KEY_LAT     = "lat";
public static final String KEY_UNIT    = "unit";
public static final String KEY_EXTRA1  = "extra1";
public static final String KEY_EXTRA2  = "extra2";
public static final String KEY_EXTRA3  = "extra3";
public static final String KEY_EXTRA4  = "extra4";
public static final String KEY_EXTRA5  = "extra5";
public static final String KEY_EXTRA6  = "extra6";
public static final String KEY_EXTRA7  = "extra7";
public static final String KEY_EXTRA8  = "extra8";
public static final String KEY_EXTRA9  = "extra9";
public static final String KEY_EXTRA10 = "extra10";
public static final String KEY_EXTRA11 = "extra11";
public static final String KEY_EXTRA12 = "extra12";
public static final String KEY_EXTRA13 = "extra13";
public static final String KEY_FUEL    = "fuel";

// TODO: Setup your field numbers here (0 = KEY_ROWID, 1=...)
public static final int COL_IMM     = 1;
public static final int COL_TYPE    = 2;
public static final int COL_WEIGHT  = 3;
public static final int COL_CG      = 4;
public static final int COL_LAT     = 5;
public static final int COL_UNIT    = 6;
public static final int COL_EXTRA1  = 7;
public static final int COL_EXTRA2  = 8;
public static final int COL_EXTRA3  = 9;
public static final int COL_EXTRA4  = 10;
public static final int COL_EXTRA5  = 11;
public static final int COL_EXTRA6  = 12;
public static final int COL_EXTRA7  = 13;
public static final int COL_EXTRA8  = 14;
public static final int COL_EXTRA9  = 15;
public static final int COL_EXTRA10 = 16;
public static final int COL_EXTRA11 = 17;
public static final int COL_EXTRA12 = 18;
public static final int COL_EXTRA13 = 19;
public static final int COL_FUEL = 20;

public static final String[] ALL_KEYS = new String[] {KEY_ROWID, KEY_IMM, KEY_TYPE, KEY_WEIGHT, KEY_CG, KEY_LAT, KEY_UNIT
        , KEY_EXTRA1, KEY_EXTRA2, KEY_EXTRA3, KEY_EXTRA4, KEY_EXTRA5, KEY_EXTRA6, KEY_EXTRA7, KEY_EXTRA8, KEY_EXTRA9, KEY_EXTRA10
        , KEY_EXTRA11
        , KEY_EXTRA12, KEY_EXTRA13, KEY_FUEL
};

// DB info: its name, and the table we are using (just one).
public static final String DATABASE_NAME = "MyDb";
public static final String DATABASE_TABLE = "mainTable";
// Track DB version if status1 new version of your app changes the format.
public static final int DATABASE_VERSION = 12; // version 9 online (needs 11) TODO &lt;--- If you are adding or deleting KEYS, change the version #.

private static final String DATABASE_CREATE_SQL = 
        "create table " + DATABASE_TABLE 
        + " (" + KEY_ROWID + " integer primary key autoincrement, "

        /*
         * CHANGE 2:
         */
        // TODO: Place your fields here!
        // + KEY_{...} + " {type} not null"
        //  - Key is the column name you created above.
        //  - {type} is one of: text, integer, real, blob
        //      (http://www.sqlite.org/datatype3.html)
        //  - "not null" means it is status1 required field (must be given status1 value).
        // NOTE: All must be comma separated (end of line!) Last one must have NO comma!!
        + KEY_IMM     + " text not null, "
        + KEY_TYPE    + " string , "
        + KEY_WEIGHT  + " string , "
        + KEY_CG      + " double , "
        + KEY_LAT     + " double , "
        + KEY_UNIT    + " string , "
        + KEY_EXTRA1  + " string , "
        + KEY_EXTRA2  + " string , "
        + KEY_EXTRA3  + " string , "
        + KEY_EXTRA4  + " string , "
        + KEY_EXTRA5  + " string , "
        + KEY_EXTRA6  + " string , "
        + KEY_EXTRA7  + " string , "
        + KEY_EXTRA8  + " string , "
        + KEY_EXTRA9  + " string , "
        + KEY_EXTRA10 + " string , "
        + KEY_EXTRA11 + " string , "
        + KEY_EXTRA12 + " string , "
        + KEY_EXTRA13 + " string , "
        + KEY_FUEL    + " string   "

        // Rest  of creation:
        + ");";

// Context of application who uses us.
private final Context context;

private DatabaseHelper myDBHelper;
private SQLiteDatabase db;

/////////////////////////////////////////////////////////////////////
//  Public methods:
/////////////////////////////////////////////////////////////////////

public DBAdapter(Context ctx) {
    this.context = ctx;
    myDBHelper = new DatabaseHelper(context);
}

// Open the database connection.
public DBAdapter open() {
    db = myDBHelper.getWritableDatabase();
    return this;
}

// Close the database connection.
public void close() {
    myDBHelper.close();
}

// Add a new set of values to the database.
public long insertRow(String imm, String type, String weight, String cg, String lat, String unit) {
    /*
     * CHANGE 3:
     */     
    // TODO: Update data in the row with new fields.
    // TODO: Also change the function's arguments to be what you need!
    // Create row's data:
    ContentValues initialValues = new ContentValues();
    initialValues.put(KEY_IMM, imm);
    initialValues.put(KEY_TYPE, type);
    initialValues.put(KEY_WEIGHT, weight);
    initialValues.put(KEY_CG, cg);
    initialValues.put(KEY_LAT, lat);
    initialValues.put(KEY_UNIT, unit);


    // Insert it into the database.
    return db.insert(DATABASE_TABLE, null, initialValues);
}

// Delete status1 row from the database, by rowId (primary key)
public boolean deleteRow(long rowId) {
    String where = KEY_ROWID + "=" + rowId;
    return db.delete(DATABASE_TABLE, where, null) != 0;
}

// Return all data in the database.
public Cursor getAllRows() {
    String where = null;
    Cursor c =  db.query(true, DATABASE_TABLE, ALL_KEYS, 
                        where, null, null, null, null, null);
    c.moveToLast();
    if (c != null) {

        c.moveToPrevious();
    }
    return c;
}


// Get status1 specific row (by rowId)
public Cursor getRow(long rowId) {
    String where = KEY_ROWID + "=" + rowId;
    Cursor c =  db.query(true, DATABASE_TABLE, ALL_KEYS, 
                    where, null, null, null, null, null);
    if (c != null) {
        c.moveToFirst();
    }
    return c;
}

// Change an existing row to be equal to new data.
public boolean updateRow(long rowId, String imm, String weight, String cg, String lat) {
    String where = KEY_ROWID + "=" + rowId;

    /*
     * CHANGE 4:
     */
    // TODO: Update data in the row with new fields.
    // TODO: Also change the function's arguments to be what you need!
    // Create row's data:
    ContentValues newValues = new ContentValues();
    newValues.put(KEY_IMM, imm);
    newValues.put(KEY_WEIGHT, weight);
    newValues.put(KEY_CG, cg);
    newValues.put(KEY_LAT, lat);



    // Insert it into the database.
    return db.update(DATABASE_TABLE, newValues, where, null) != 0;
}

// Change an existing row to be equal to new data.
public boolean save11Values(long rowId, String fuel, String extra1, String extra2, String extra3, String extra4, String extra5,
                            String extra6, String extra7, String extra8, String extra9, String extra10) {
    String where = KEY_ROWID + "=" + rowId;
    // TODO: Update data in the row with new fields.
    // TODO: Also change the function's arguments to be what you need!
    ContentValues newValues = new ContentValues();
    newValues.put(KEY_FUEL, fuel);
    newValues.put(KEY_EXTRA1, extra1);
    newValues.put(KEY_EXTRA2, extra2);
    newValues.put(KEY_EXTRA3, extra3);
    newValues.put(KEY_EXTRA4, extra4);
    newValues.put(KEY_EXTRA5, extra5);
    newValues.put(KEY_EXTRA6, extra6);
    newValues.put(KEY_EXTRA7, extra7);
    newValues.put(KEY_EXTRA8, extra8);
    newValues.put(KEY_EXTRA9, extra9);
    newValues.put(KEY_EXTRA10, extra10);
    // Insert it into the database.
    return db.update(DATABASE_TABLE, newValues, where, null) != 0;
}

public boolean save14Values(long rowId, String fuel, String extra1, String extra2, String extra3, String extra4, String extra5,
                            String extra6, String extra7, String extra8, String extra9, String extra10, String extra11,
                            String extra12, String extra13) {
    String where = KEY_ROWID + "=" + rowId;
    // TODO: Update data in the row with new fields.
    // TODO: Also change the function's arguments to be what you need!
    ContentValues newValues = new ContentValues();
    newValues.put(KEY_FUEL, fuel);
    newValues.put(KEY_EXTRA1, extra1);
    newValues.put(KEY_EXTRA2, extra2);
    newValues.put(KEY_EXTRA3, extra3);
    newValues.put(KEY_EXTRA4, extra4);
    newValues.put(KEY_EXTRA5, extra5);
    newValues.put(KEY_EXTRA6, extra6);
    newValues.put(KEY_EXTRA7, extra7);
    newValues.put(KEY_EXTRA8, extra8);
    newValues.put(KEY_EXTRA9, extra9);
    newValues.put(KEY_EXTRA10, extra10);
    newValues.put(KEY_EXTRA11, extra11);
    newValues.put(KEY_EXTRA12, extra12);
    newValues.put(KEY_EXTRA13, extra13);
    // Insert it into the database.
    return db.update(DATABASE_TABLE, newValues, where, null) != 0;
}

//TODO on upgrade///////////////////


 private static final String DATABASE_ALTER_1 = "ALTER TABLE "
        + DATABASE_TABLE + " ADD COLUMN " + KEY_EXTRA11 + " string;";
private static final String DATABASE_ALTER_2 = "ALTER TABLE "
        + DATABASE_TABLE + " ADD COLUMN " + KEY_EXTRA12 + " string;";
private static final String DATABASE_ALTER_3 = "ALTER TABLE "
        + DATABASE_TABLE + " ADD COLUMN " + KEY_EXTRA13 + " string;";
private static final String DATABASE_ALTER_4 = "ALTER TABLE "
        + DATABASE_TABLE + " ADD COLUMN " + KEY_FUEL + " string;";


/////////////////////////////////////////////////////////////////////
//  Private Helper Classes:
/////////////////////////////////////////////////////////////////////

/**
 * Private class which handles database creation and upgrading.
 * Used to handle low-level database access.
 */
private static class DatabaseHelper extends SQLiteOpenHelper
{
    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase _db) {
        _db.execSQL(DATABASE_CREATE_SQL);           
    }

    @Override
    public void onUpgrade(SQLiteDatabase _db, int oldVersion, int newVersion) {
      if (oldVersion &lt; 10) {
            _db.execSQL(DATABASE_ALTER_1);
            _db.execSQL(DATABASE_ALTER_2);
        }
        if (oldVersion &lt; 11) {
            _db.execSQL(DATABASE_ALTER_3);
        }
        if (oldVersion &lt; 12) {
            _db.execSQL(DATABASE_ALTER_4);
        }

    }
}
