public class BooksDetails extends Activity
{
    private Button btnBack;
    private TextView tvBookTitle, tvBookSentences, tvBookInSummary, tvSpecialSentences;
    private JustifiedTextView tvBookTxt;
    private Button btnFavorite, btnShare, btnRelated;
    public book mBook;
    private Share ds;
    private Button btnShareFacebook, btnShareTwitter, btnShareGooglePlus,btnCancelShare;// bookShare

    private int idCount;
    private IDGENERATOR idGen;
    private String uniqueTag;

    // private ProgressBar mProgress;
    private ProgressWheel mProgress;
    // getBookText getBookTextTask;

    public int homeBookId;
    private static int count = 0;

    public static int ifDidntFindAnId = -1;

    public static boolean shouldTerminate = false;
    public static int terminateCount = 0;

    private int currentTerminateCount = 0;
    private boolean isAppRunning = true;

    private UiLifecycleHelper uiHelper;
    private PendingAction pendingAction = PendingAction.NONE;

    private enum PendingAction
    {
            NONE, POST_PHOTO, POST_STATUS_UPDATE
    }

    private Session.StatusCallback callback = new Session.StatusCallback()
    {
            @Override
            public void call(Session session, SessionState state,
                    Exception exception)
            {
                    onSessionStateChange(session, state, exception);
            }
    };

    private String user_id = null;
    private int isFavourite = -1;

    BooksDetailsHelp booksDetailsHelp;

    private FontMan fMan;

    public FontMan getFontMan()
    {
            if (fMan == null)
            {
                    fMan = FontMan.getInstance(this);
            }
            return fMan;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
            // processing
    }
    @Override
    public void onDestroy()
    {
            super.onDestroy();
            if (uiHelper != null)
                    uiHelper.onDestroy();
            destroy();
    }

    private void destroy()
    {
            try
            {
                    tvBookTxt.destroy();
                    Globals.destroy(findViewById(R.id.rootView));
            }
            catch (Exception e)
            {
            }

            btnBack = null;
            tvBookTitle = tvBookSentences = tvBookInSummary = tvSpecialSentences = null;
            tvBookTxt = null;
            btnFavorite.setOnClickListener(null);
            btnShare.setOnClickListener(null);
            btnRelated.setOnClickListener(null);
            btnFavorite = btnShare = btnRelated = null;
            mBook = null;
            ds = null;

            btnShareFacebook.setOnClickListener(null);
            btnShareTwitter.setOnClickListener(null);
            btnShareGooglePlus.setOnClickListener(null);
            btnCancelShare.setOnClickListener(null);

            btnShareFacebook = btnShareTwitter = btnShareGooglePlus = btnCancelShare = null;
            idGen = null;
            uniqueTag = null;
            mProgress = null;
            uiHelper = null;
            pendingAction = null;
            callback = null;
            user_id = null;
            booksDetailsHelp.destroy();
            booksDetailsHelp = null;

            fMan = null;
            if (getUserSocialIdsTask != null)
            {
                    getUserSocialIdsTask.cancel(true);
            }
            getUserSocialIdsTask = null;

            finish();
            System.gc();
    }

    public synchronized static void destroy(View homeView)
    {
            try
            {
                    disableListeners(homeView);
            }
            catch (Exception e)
            {
                    // TODO: handle exception
            }
            try
            {
                    unbindDrawables(homeView);
            }
            catch (Exception e)
            {
        }
    }

    private static void disableListeners(View view)
    {
            try
            {
                    view.setOnClickListener(null);
            }
            catch (Exception e)
            {
                    // TODO: handle exception
            }

            if (view instanceof ViewGroup)
            {
                    for (int i = 0; i &lt; ((ViewGroup) view).getChildCount(); i++)
                    {
                            disableListeners(((ViewGroup) view).getChildAt(i));
                    }
            }
    }

    private static void unbindDrawables(View view)
    {
            if (view.getBackground() != null)
            {
                    view.getBackground().setCallback(null);
            }
            if (view instanceof ViewGroup)
            {
                    for (int i = 0; i &lt; ((ViewGroup) view).getChildCount(); i++)
                    {
                            unbindDrawables(((ViewGroup) view).getChildAt(i));
                    }
                    ((ViewGroup) view).removeAllViews();
            }
    }
