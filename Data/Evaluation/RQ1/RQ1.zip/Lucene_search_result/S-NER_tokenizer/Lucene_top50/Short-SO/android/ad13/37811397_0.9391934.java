 @Override
public View getView(int position, View convertView, ViewGroup parent) {
    SwipeMenuLayout layout = null;

    if (mAdapter instanceof BaseSwipListAdapter) {

        boolean swipEnable = (((BaseSwipListAdapter) mAdapter).getSwipEnableByPosition(position));
        if( listviewsize &gt; 0)
        layout.setSwipEnable(swipEnable);   ---&gt;This line is used to enable and disable the swipe left in listview.I need to use this method
        else
        layout.setSwipEnable(swipDisable);
    }

    return layout;
}
@Override
    public int getCount() {
        return listview.size();
    }
static public class ChatAdapter extends BaseAdapter  { // or BaseSwipListAdapter if you like

    private final List&lt;ChatMessage&gt; chatMessages;
    private Activity context;
    private int layoutId;
    String loggedUserId, loggedUserName;

    public ChatAdapter(Activity context, int resource, List&lt;ChatMessage&gt; chatMessages) {
        super(context, resource, chatMessages);
        this.context = context;
        layoutId = resource;
        this.chatMessages = chatMessages;
    }

    @Override
    public int getCount() {
        return chatMessages == null ? 0 : chatMessages.size();
    }

    @Override
    public Object getItem(int position) {
        return chatMessages == null ? null : chatMessages.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(layoutId, parent, false);
        }

        // assuming the view is a TextView
        ((TextView) view).setText(getItem(position).toString());

        return view;
    }

    public void add(ChatMessage chatMessage) {
        chatMessages.add(chatMessage);
        notifyDataSetChanged();
    }

    public void addAll(Collection&lt;? extends ChatMessage&gt; col) {
        chatMessages.addAll(col);
        notifyDataSetChanged();
    }

    public void clear() {
        chatMessages.clear();
        notifyDataSetChanged();
    }
}
