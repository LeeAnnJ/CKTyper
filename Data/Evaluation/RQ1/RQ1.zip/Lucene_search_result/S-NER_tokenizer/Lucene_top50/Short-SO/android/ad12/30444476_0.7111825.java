public class MainActivity extends ActionBarActivity
        implements NavigationDrawerFragment.NavigationDrawerCallbacks {

    private NavigationDrawerFragment mNavigationDrawerFragment;

    @Override
    protected void onCreate (Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNavigationDrawerFragment = (NavigationDrawerFragment)
                getSupportFragmentManager().findFragmentById(R.id.navigation_drawer);

        mNavigationDrawerFragment.setUp(
                R.id.navigation_drawer,
                (DrawerLayout) findViewById(R.id.drawer_layout));
    }

    @Override
    public void onNavigationDrawerItemSelected (int position) {
        ...
    }
}
@RunWith(RobolectricGradleTestRunner.class)
@Config(constants = BuildConfig.class)
public class MainActivityTests {

    private ActivityController&lt;MainActivity&gt; controller;
    private MainActivity activity;
    private MainActivity spy;

    @Test
    public void onCreate_shouldStartNavigationDrawerFragment () {

        controller = Robolectric.buildActivity(MainActivity.class);
        activity = controller.get();
        assertThat(activity).isNotNull();

        spy = spy(activity);
        spy.onCreate(null);

        verify(spy).onCreate(null);
    }
}
controller = Robolectric.buildActivity(MainActivity.class);
activity = controller.get();
assertThat(activity).isNotNull();
spy = spy(activity);
controller.create();
private MainActivity spyActivity;

@Before
public void setUp(){

    MainActivity activity = Robolectric.buildActivity(MainActivity.class).attach().get();
    spyActivity = spy(activity);

    spyActivity.onCreate(null);

}
public static &lt;T extends Activity&gt; T getSpy(ActivityController&lt;T&gt; activityController) {
    T spy = spy(activityController.get());
    ReflectionHelpers.setField(activityController, "component", spy);
    return spy;
}
controller = Robolectric.buildActivity(MainActivity.class);
activity = getSpy(controller.get());
