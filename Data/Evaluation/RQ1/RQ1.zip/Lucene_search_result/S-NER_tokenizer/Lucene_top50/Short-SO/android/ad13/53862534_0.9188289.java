public class WeatherViewPagerAdapter extends FragmentStatePagerAdapter {

private List&lt;Fragment&gt; fragments;
public WeatherViewPagerAdapter(FragmentManager fm) {
    super(fm);
    fragments = new LinkedList&lt;&gt;();
    if (Storage.getInstance().getWeatherModels().size() == 0){
        // Displays page but with "no weather available" message
        fragments.add(WeatherFragment.newInstance(null));
    }else{
        for (CurrentWeatherModel model : Storage.getInstance().getWeatherModels()){
            fragments.add(WeatherFragment.newInstance(model));
        }
    }
}

public void rediscoverWeather(){
    fragments.clear();
    if (Storage.getInstance().getWeatherModels().size() == 0){
        fragments.add(WeatherFragment.newInstance(null));
    }else{
        for (CurrentWeatherModel model : Storage.getInstance().getWeatherModels()){
            fragments.add(WeatherFragment.newInstance(model));
        }
    }
}

@Override
public int getItemPosition(@NonNull Object object) {
    return POSITION_NONE;
}

@Override
public int getCount() {
    return fragments.size();
}

@Override
public Fragment getItem(int position) {
    return fragments.get(position);
}

@Override
public Parcelable saveState() {
    return null;
}
}
public class WeatherViewPagerFragment extends Fragment {

private WeatherViewPagerAdapter adapter;
private ViewPager viewpager;
private TabLayout tabLayout;

public static WeatherViewPagerFragment newInstance(){
    return new WeatherViewPagerFragment();
}

@Override
public UniqueInfo getUniqueInfo() {
    return null;
}

@Override
public void update() {
    adapter.rediscoverWeather();
    setPage(0);
    adapter.notifyDataSetChanged();
}

public void setPage(int pageNumber){
    if (pageNumber &gt;=0 &amp;&amp; pageNumber &lt; adapter.getCount()){
        viewpager.setCurrentItem(pageNumber, true);
    }
}

@Nullable
@Override
public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
    return inflater.inflate(R.layout.weather_view_pager, container, false);
}

private void createAdapter(){
    adapter = new WeatherViewPagerAdapter(getChildFragmentManager());
    viewpager.setAdapter(adapter);
    tabLayout.setupWithViewPager(viewpager);
}

@Override
public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    viewpager = view.findViewById(R.id.viewpager);
    tabLayout = view.findViewById(R.id.sliding_tabs);
    createAdapter();
}
}
