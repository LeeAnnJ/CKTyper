public class CustomAdapter extends BaseAdapter {

private Activity activity;
private ArrayList&lt;Loger&gt; logs;
private static LayoutInflater inflater=null;
public Resources res;
Loger tempValues=null;
int i=0;
private URL url;


public CustomAdapter(Activity a, ArrayList&lt;Loger&gt; listLoger,Resources resLocal) {

    activity = a;
    logs=listLoger;
    res = resLocal;

    inflater = ( LayoutInflater )activity.
            getSystemService(Context.LAYOUT_INFLATER_SERVICE);

}

public int getCount() {

    if(logs.size()&lt;=0)
        return 1;
    return logs.size();
}

public Object getItem(int position) {
    return position;
}

public long getItemId(int position) {
    return position;
}

public static class ViewHolder{

    public TextView text;
    public TextView text1;
    public TextView textWide;
    public ImageView image;

}

public View getView(int position, View convertView, ViewGroup parent) {

    View vi = convertView;
    ViewHolder holder;

    if(convertView==null){

        vi = inflater.inflate(R.layout.liesviewlayout, null);

        holder = new ViewHolder();
        holder.text = (TextView) vi.findViewById(R.id.name);
        holder.text1=(TextView)vi.findViewById(R.id.comment);
        holder.image=(ImageView)vi.findViewById(R.id.image);

        vi.setTag( holder );
    }
    else
        holder=(ViewHolder)vi.getTag();

    if(logs.size()&lt;=0)
    {
        holder.text.setText("No Data");

    }
    else
    {

        tempValues=null;
        tempValues = ( Loger ) logs.get( position );



        holder.text.setText( tempValues.getFirstname() );
        holder.text1.setText( tempValues.getImageUrl() );
        holder.image.setImageResource(
                res.getIdentifier(
                        "com.androidexample.customlistview:drawable/"+tempValues.getImageUrl()
                        ,null,null));

    }
    return vi;
}

}
Resources res =getResources();
        lv = ( ListView )findViewById( R.id.listView ); 

        //Create Custom Adapter
        mAdapter=new CustomAdapter( this, listLoger,res );
        lv.setAdapter( mAdapter );
