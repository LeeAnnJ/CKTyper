int lastAddA=0;

public void addThreeforTeamA(View v) {
    scoreTeamA+=3;
    lastAddA = 3;
    displayForTeamA(scoreTeamA);
}

public void undoLastTeamA(View v) {
    scoreTeamA-=lastAddA;
    lastAddA = 0;//Reset to default
    displayForTeamA(scoreTeamA);
}
public class ScoreStack {
    private class ScoreNode {
        int score;
        ScoreNode next;

        ScoreNode(int score, ScoreNode next) {
            this.score = score;
            this.next = next;
        }
    }

    private int score = 0;
    private ScoreNode root = null;

    public void push(int score) {
        root = new ScoreNode(score, root);
        this.score += score;
    }

    public int pop() {
        if (root == null) {
            return 0;
        }
        int score = root.score;
        root = root.next;
        this.score -= score;
        return score;
    }

    public void reset() {
        root = null;
    }

    @Override
    public String toString() {
        return String.valueOf(score);
    }
}
public void addOneforTeamA(View v) {
    aTeamStack.push(1);
    displayForTeamA();
}

public void undoLastForA() {
    aTeamStack.pop();
    displayForTeamA();
}

public void displayForTeamA() {
    ((TextView) findViewById(R.id.team_a_score)).setText(aTeamStack);
}
public void displayScore(int id, String score) {
    ((TextView) findViewById(id)).setText(score);
}
