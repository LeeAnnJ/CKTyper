&lt;activity
    android:name="com.proj.activity.MainActivity"
    android:windowSoftInputMode="stateHidden" /&gt;
InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(mEditText.getWindowToken(), 0);
private void showKeyboard(View view) {
    InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    keyboard.showSoftInput(view, 0);
}

private void hideKeyboard() {
    InputMethodManager inputMethodManager = (InputMethodManager) this
            .getSystemService(Context.INPUT_METHOD_SERVICE);
    inputMethodManager.hideSoftInputFromWindow(this.getCurrentFocus()
            .getWindowToken(), 0);
}
public class Activity1 extends Activity implements OnFocusChangeListener
{
    protected void onCreate( Bundle b )
    {
         .....
        txtX = (EditText) findViewById(R.id.text_x);
        txtX.setOnFocusChangeListener(this);
    }

    public void hideKeyboard(View view)
    {
        InputMethodManager inputMethodManager =(InputMethodManager)context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    @Override
    public void onFocusChange(View view, boolean arg1)
    {
        if(! view.hasFocus())
            hideKeyboard(view);
    }
}
&lt;LinearLayout
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:clickable="true"
    android:focusableInTouchMode="true" &gt;

        &lt;EditText
            android:id="@+id/text_x"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content" /&gt;
&lt;/LinearLayout&gt;
