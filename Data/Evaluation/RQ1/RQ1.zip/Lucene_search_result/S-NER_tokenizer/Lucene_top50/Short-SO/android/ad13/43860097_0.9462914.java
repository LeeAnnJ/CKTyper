item.getActionView().setLongClickable(true);
item.getActionView().setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    return false;
                }
            });
@Override
protected void onStart() {
    super.onStart();
    View view = findViewById(R.id.navigation_courses); // BottomNavigationView menu item id
    view.setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View view) {
            Toast.makeText(getApplicationContext(), "Long pressed", Toast.LENGTH_SHORT).show();
            return false;
        }
    });
}
private void overrideOnMenuItemLongClickListener(BottomNavigationView bottomNavigationView){

if(bottomNavigationView == null){
    return;
}

int count = bottomNavigationView.getChildCount();
if(count &lt;= 0){
    return;
}

ViewGroup menuView = (ViewGroup) bottomNavigationView.getChildAt(0);
if(menuView == null){
    return;
}

int menuItemViewSize = menuView.getChildCount();
if(menuItemViewSize &lt;= 0){
    return;
}

for(int i=0; i &lt; menuItemViewSize; i++){
    menuView.getChildAt(i).setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            return true;
        }
    });
}
private void overrideOnMenuItemLongClickListener(BottomNavigationView bottomNavigationView) {
    if (bottomNavigationView != null &amp;&amp; bottomNavigationView.getChildCount() &gt; 0) {
        ViewGroup menuView = (ViewGroup) bottomNavigationView.getChildAt(0);
        if (menuView != null) {
            for (int i = 0; i &lt; menuView.getChildCount(); i++) {
                menuView.getChildAt(i).setOnLongClickListener(v -&gt; true);
            }
        }
    }
}
fun BottomNavigationView.setLonClkListner() {
    val position = 4 //item index in which u want to set LongClickListner
    val menuView = getChildAt(0) as ViewGroup
    menuView.getChildAt(position).setOnLongClickListener {
        findNavController().navigate(R.id.toSwitchAccount)
        true
    }
}
