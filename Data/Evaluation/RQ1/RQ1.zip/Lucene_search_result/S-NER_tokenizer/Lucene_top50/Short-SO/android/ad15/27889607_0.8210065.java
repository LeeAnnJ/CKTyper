public class classA {

    private static class classOne{


        protected static int a; 
        protected static String b; 

        public Haustier (int x, String y){          
            a= x; b = y; 
        }


        void print (int a, String b){
            System.out.println("this is a result "+a+" . This is also a  "+b+" result.");   
        }


        public static void main(String[] args){

            classOne H1 = new classOne(4, "Fluffy");
            classOne H2 = new classOne(3, "Lessi");


            H1.print(a, b);
            H2.print(a, b);

            }
    }

    }
ClassA classAInstance = new ClassA(); // here you are using your constructor
classAInstance.printValue();          // here you are calling your method.
