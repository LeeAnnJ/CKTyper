import java.net.ServerSocket;
import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

public class HttpServer {

    public static void main(String[] args) throws Throwable {
        //http://localhost:3000
        ServerSocket ss = new ServerSocket(3000);

        while (true) {
            //Waiting for socket
            Socket s = ss.accept();
            System.out.println("Client accepted");
            //The main process
            new SocketProcessor(s,ss).start();
        }
    }

    private static class SocketProcessor implements Runnable {
        private Thread t;
        private Socket s;
        private ServerSocket ss;
        private InputStream is;
        private OutputStream os;

        private SocketProcessor(Socket s,ServerSocket ss) throws Throwable {
            t = new Thread(this, "Server Thread");
            this.ss=ss;
            this.s = s;
            this.is = s.getInputStream();
            this.os = s.getOutputStream();
        }

        public void run() {
            try {
                readInputHeaders();               
                writeResponse("&lt;html&gt;&lt;body&gt;&lt;h1&gt;Hello&lt;/h1&gt;&lt;/body&gt;&lt;/html&gt;");


            } catch (Throwable t) {
                /*do nothing*/
            } finally {
                try {
                    s.close();
                } catch (Throwable t) {

                }
            }
            System.out.println("Client processing finished");
        }


        public void start()
        {
            t.start();
        }

        private void writeResponse(String s) throws Throwable {
            String response = "HTTP/1.1 200 OK\r\n" +
                    "Server: Server\r\n" +
                    "Content-Type: text/html\r\n" +
                    "Content-Length: " + s.length() + "\r\n" +
                    "Connection: close\r\n\r\n";
            String result = response + s;
            os.write(result.getBytes());
            os.flush();
        }

        private void readInputHeaders() throws Throwable {
            BufferedReader br = new BufferedReader(new InputStreamReader(is));
            while(true) {
                String s = br.readLine();
                System.out.println(s);
                if(s == null || s.trim().length() == 0) {
                    break;
                }
            }
        }
    }
}
readInputHeaders();
t.wait(1000);
writeResponse("&lt;html&gt;&lt;body&gt;&lt;h1&gt;Hello&lt;/h1&gt;&lt;/body&gt;&lt;/html&gt;");
