public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private Button btn;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        imageView = findViewById(R.id.image);
        btn = findViewById(R.id.save);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmap=viewToBitmap(imageView,imageView.getWidth(),imageView.getHeight());
                FileOutputStream outputStream;
                File sdCard=Environment.getExternalStorageDirectory();
                File dir=new File(sdCard.getAbsolutePath()+"/Yourfiles");
                dir.mkdir();
                String filename=(String.format("%d.jpg",System.currentTimeMillis()));
                File outfile=new File(dir,filename);
                try {
                    outputStream=new FileOutputStream(outfile);
                    bitmap.compress(Bitmap.CompressFormat.JPEG,100,outputStream);

                    outputStream.flush();
                    outputStream.close();
                    Intent i=new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    i.setData(Uri.fromFile(outfile));
                    sendBroadcast(i);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
    }
    private static Bitmap viewToBitmap(View view, int widh, int hight)
    {
        Bitmap bitmap=Bitmap.createBitmap(widh,hight, Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(bitmap); view.draw(canvas);
        return bitmap;
    }

}
