 @OnClick(R.id.guess_button)
void submit() {
    submitLetter();
}

private void submitLetter() {
    Editable userInput = mGuessInput.getText();
    String guessStr = mUserInput.toString();
    if (mGuessStr.length() != 0) {
        checkGuess(
                String.valueOf(mGuessStr).charAt(0),
                mCodeWord.toUpperCase()
        );
        mUserInput.clear();
        mGuessInput.clearFocus();
        hideKeyboard(MainActivity.this);
    }
}
public static void hideKeyboard(Activity activity) {
    InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
   View view = activity.getCurrentFocus();
    if (view == null) {
        view = new View(activity);
    }
    if (imm != null) {
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
public void hideKeyboardOnKeyTouch(EditText editText) {
    final int generatedKeyCode = KeyEvent.getMaxKeyCode();
    editText.setOnEditorActionListener(new OnEditorActionListener() {
        @Override
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if (event.getAction() == generatedKeyCode) {
             hideKeyboard(MainActivity.this);
            }
            return false;
        }
    });

}
