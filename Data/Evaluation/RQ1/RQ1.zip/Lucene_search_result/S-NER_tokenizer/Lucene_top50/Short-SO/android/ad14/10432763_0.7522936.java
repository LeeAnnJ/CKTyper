//OpenGL ES 2.0 view class
public class OGLES2View extends GLSurfaceView 
{
    private static final int OGLES_VERSION = 2;
    private static Handler softKeyboardHandler;
    private final static int SHOW_IME_KEYBOARD = 0;
    private final static int HIDE_IME_KEYBOARD = 1;
    private static EditText textEdit;
    private static  InputMethodManager imm;

    private void setSoftKeyboardHandler()
    {
        softKeyboardHandler = new Handler()
        {
            public void handleMessage(Message msg)
            {
                switch(msg.what)
                {
                    case SHOW_IME_KEYBOARD:
                        textEdit.requestFocus();
                        imm.showSoftInput(textEdit,inputMethodManager.SHOW_IMPLICIT);//Nothing happens
                        Log.i("GLVIEW","SHOW KEYBOARD");
                        break;

                    case HIDE_IME_KEYBOARD:
                        imm.hideSoftInput(textEdit, 0);
                        Log.i("GLVIEW","HIDE KEYBOARD");
                        break;

                    default:
                        break;
                }
            }
        };
    }

    public OGLES2View(Context context) 
    {
        super(context);
        textEdit = new EditText(context);
        setEGLContextClientVersion(OGLES_VERSION);
        setRenderer(new OGLES2Renderer());
        imm = (InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);
        setSoftKeyboardHandler();
    }

    public static void showIMEKeyboard() 
    {
        softKeyboardHandler.sendEmptyMessage(SHOW_IME_KEYBOARD);
    }

    public static void hideIMEKeyboard()
    {
        softKeyboardHandler.sendEmptyMessage(HIDE_IME_KEYBOARD);
    }

    //In main activity class
    private GLSurfaceView ogles2SurfaceView = null;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //...
        ogles2SurfaceView = new OGLES2View(this);
        setContentView(ogles2SurfaceView);
    }
class DrawingPanel extends SurfaceView implements SurfaceHolder.Callback {

private static DrawThread _thread;    

public DrawingPanel(Context context, AttributeSet attrs) {
    super(context, attrs);
    getHolder().addCallback(this);       
   _thread = new DrawThread(getHolder(), this);
}
....
&lt;FrameLayout
xmlns:android="http://schemas.android.com/apk/res/android"
 android:layout_width="fill_parent" 
android:layout_height="fill_parent"&gt;
&lt;!-- YOUR SURFACE --&gt;
&lt;com.yourcompany.DrawingPanel android:id="@+id/surfaceView" android:layout_width="fill_parent" 
android:layout_height="fill_parent"&gt;&lt;/com.yourcompany.DrawingPanel&gt;

&lt;!-- YOUR BUTTONS --&gt;
&lt;RelativeLayout android:id="@+id/controlPanel" android:layout_width="fill_parent" android:orientation="horizontal"
android:layout_height="fill_parent" &gt;   
&lt;RelativeLayout android:layout_width="50px" android:orientation="vertical"
    android:layout_height="fill_parent"  android:gravity="center_vertical" android:layout_alignParentLeft="true"&gt;
         &lt;Button android:id="@+id/leftButton" android:layout_width="wrap_content" 

        android:layout_height="50px" android:background="@xml/button_left_state"/&gt; 
        &lt;Button android:id="@+id/upgradeButton" android:layout_width="wrap_content" 
        android:layout_below="@id/leftButton"
        android:layout_height="50px" android:background="@xml/button_upgrade_state"/&gt; 
&lt;/RelativeLayout&gt;
&lt;/RelativeLayout&gt;           
 &lt;/FrameLayout&gt;
  @Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);     
    setContentView(R.layout.gameview);
   ...
