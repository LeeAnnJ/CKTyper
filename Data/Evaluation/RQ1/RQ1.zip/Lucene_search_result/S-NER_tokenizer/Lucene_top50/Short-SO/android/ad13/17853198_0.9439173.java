 public class WallpaperChooser extends Activity {

@Override
public void onCreate(Bundle icicle) {
    super.onCreate(icicle);
    setContentView(R.layout.wallpaper_chooser_base);

    Fragment fragmentView = getFragmentManager().findFragmentById(
            R.id.wallpaper_chooser_fragment);
    if (fragmentView == null) {

        DialogFragment fragment = WallpaperChooserDialogFragment
                .newInstance();
        fragment.show(getFragmentManager(), "dialog");
    }
}
 public class WallpaperChooserDialogFragment extends DialogFragment implements
    AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {

private static final String TAG = "MainActivity.WallpaperChooserDialogFragment";
private static final String EMBEDDED_KEY = "org.app.wallpapers."
        + "WallpaperChooserDialogFragment.EMBEDDED_KEY";
private static final String SD = Environment.getExternalStorageDirectory().getAbsolutePath();
private boolean mEmbedded;
private Bitmap mBitmap = null;   
private ImageAdapter mAdapter;
private ImageView image;
private ArrayList&lt;Integer&gt; mThumbs;
private ArrayList&lt;Integer&gt; mImages;
private WallpaperLoader mLoader;
private WallpaperDrawable mWallpaperDrawable = new WallpaperDrawable();

public static WallpaperChooserDialogFragment newInstance() {
    WallpaperChooserDialogFragment fragment = new WallpaperChooserDialogFragment();
    fragment.setCancelable(true);
    return fragment;
}

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (savedInstanceState != null &amp;&amp; savedInstanceState.containsKey(EMBEDDED_KEY)) {
        mEmbedded = savedInstanceState.getBoolean(EMBEDDED_KEY);
    } else {
        mEmbedded = isInLayout();
    }
}

@Override
public void onSaveInstanceState(Bundle outState) {
    outState.putBoolean(EMBEDDED_KEY, mEmbedded);
}

private void cancelLoader() {
    if (mLoader != null &amp;&amp; mLoader.getStatus() != WallpaperLoader.Status.FINISHED) {
        mLoader.cancel(true);
        mLoader = null;
    }
}
@Override
public void onDetach() {
    super.onDetach();

    cancelLoader();
}
@Override
public void onDestroy() {
    super.onDestroy();

    cancelLoader();
}
@Override
public void onDismiss(DialogInterface dialog) {
    super.onDismiss(dialog);
    /* On orientation changes, the dialog is effectively "dismissed" so this is called
     * when the activity is no longer associated with this dying dialog fragment. We
     * should just safely ignore this case by checking if getActivity() returns null
     */
    Activity activity = getActivity();
    if (activity != null) {
        activity.finish();
    }
}
@Override
public Dialog onCreateDialog(Bundle savedInstanceState) {
    findWallpapers();

    return null;
}
@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
    findWallpapers();
   if (mEmbedded) {
        View view = inflater.inflate(R.layout.wallpaper_chooser, container, false);
        view.setBackgroundDrawable(mWallpaperDrawable);

        final Gallery gallery = (Gallery) view.findViewById(R.id.gallery);
        gallery.setCallbackDuringFling(false);
        gallery.setOnItemSelectedListener(this);
        //gallery.setAdapter(new ImageAdapter(getActivity()));
        mAdapter = new ImageAdapter(getActivity());
        gallery.setAdapter(mAdapter);

        return view;
    }
    return null;
}

private void selectWallpaper(int position) {
    try {
        WallpaperManager wpm = (WallpaperManager) getActivity().getSystemService(
                Context.WALLPAPER_SERVICE);
        wpm.setResource(mImages.get(position));
        Activity activity = getActivity();
        activity.setResult(Activity.RESULT_OK);
        activity.finish();
    } catch (IOException e) {
        Log.e(TAG, "Failed to set wallpaper: " + e);
    }
}

public void onItemClick(AdapterView&lt;?&gt; parent, View view, int position, long id) {
    selectWallpaper(position);

}

public void onItemSelected(AdapterView&lt;?&gt; parent, View view, int position, long id) {
    if (mLoader != null &amp;&amp; mLoader.getStatus() != WallpaperLoader.Status.FINISHED) {
        //image.startAnimation(animFadeOut);
        mLoader.cancel();
    }
    mLoader = (WallpaperLoader) new WallpaperLoader().execute(position);
}

public void onNothingSelected(AdapterView&lt;?&gt; parent) {
}

private void findWallpapers() {
    mThumbs = new ArrayList&lt;Integer&gt;(24);
    mImages = new ArrayList&lt;Integer&gt;(24);

    final Resources resources = getResources();
    final String packageName = resources.getResourcePackageName(R.array.all_wallpapers);

    addWallpapers(resources, packageName, R.array.all_wallpapers);
}

private void addWallpapers(Resources resources, String packageName, int list) {
    final String[] extras = resources.getStringArray(list);
    for (String extra : extras) {
        int res = resources.getIdentifier(extra, "drawable", packageName);
        if (res != 0) {
            final int thumbRes = resources.getIdentifier(extra + "_thumb",
                    "drawable", packageName);

            if (thumbRes != 0) {
                mThumbs.add(thumbRes);
                mImages.add(res);
            }
        }
    }    
}


private class ImageAdapter extends BaseAdapter implements ListAdapter, SpinnerAdapter {
    private LayoutInflater mLayoutInflater;

    ImageAdapter(Activity activity) {
        mLayoutInflater = activity.getLayoutInflater();
    }
    public int getCount() {
        return mThumbs.size();
    }

    public Bitmap getImage(int i)
    {
        return getBitmap(((Integer)mImages.get(i)).intValue());
    }

    public Bitmap getItem(int i)
    {
        return getBitmap(((Integer)mImages.get(i)).intValue());
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view;

        if (convertView == null) {
            view = mLayoutInflater.inflate(R.layout.wallpaper_item, parent, false);
        } else {
            //image.startAnimation(animFadeIn);
            view = convertView;
        }

        image = (ImageView) view.findViewById(R.id.wallpaper_image);
        int thumbRes = mThumbs.get(position);
        image.setImageResource(thumbRes);
        Drawable thumbDrawable = image.getDrawable();
        if (thumbDrawable != null) {
            thumbDrawable.setDither(true);
        } else {
            Log.e(TAG, "Error decoding thumbnail resId=" + thumbRes + " for wallpaper #"
                    + position);
        }

        return view;
    }
}

class WallpaperLoader extends AsyncTask&lt;Integer, Void, Bitmap&gt; {
    BitmapFactory.Options mOptions;

    WallpaperLoader() {
        mOptions = new BitmapFactory.Options();
        mOptions.inDither = false;
        mOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;
    }

    @Override
    protected Bitmap doInBackground(Integer... params) {
        if (isCancelled()) return null;
        try {
            return BitmapFactory.decodeResource(getResources(),
                    mImages.get(params[0]), mOptions);
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    @Override
    protected void onPostExecute(Bitmap b) {
        if (b == null) return;
        if (!isCancelled() &amp;&amp; !mOptions.mCancel) {
            // Help the GC
            if (mBitmap != null) {
                mBitmap.recycle();
            }

            View v = getView();

            if (v != null) {
                mBitmap = b;
                mWallpaperDrawable.setBitmap(b);
                v.postInvalidate();
            } else {
                mBitmap = null;
                mWallpaperDrawable.setBitmap(null);

            }

            mLoader = null;
        } else {
           b.recycle();
        }
    }

    void cancel() {
        mOptions.requestCancelDecode();
        super.cancel(true);
    }
}

static class WallpaperDrawable extends Drawable {

    Bitmap mBitmap;
    int mIntrinsicWidth;
    int mIntrinsicHeight;

    /* package */void setBitmap(Bitmap bitmap) {
        mBitmap = bitmap;
        if (mBitmap == null)
            return;
        mIntrinsicWidth = mBitmap.getWidth();
        mIntrinsicHeight = mBitmap.getHeight();


    }

    @Override
    public void draw(Canvas canvas) {
        if (mBitmap == null) return;
        int width = canvas.getWidth();
        int height = canvas.getHeight();
        int x = (width - mIntrinsicWidth) / 2;
        int y = (height - mIntrinsicHeight) / 2;
        canvas.drawBitmap(mBitmap, x, y, null);


    }

    @Override
    public int getOpacity() {
        return android.graphics.PixelFormat.OPAQUE;
    }
}
private Bitmap getBitmap(int i)
{
    System.out.println(i);
    if(i != 0)
    {
        System.out.println("ResourceID != 0");
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), i);
        PrintStream printstream = System.out;
        StringBuilder stringbuilder = new StringBuilder("Bitmap = null = ");
        boolean flag;
        if(bitmap == null)
            flag = true;
        else
            flag = false;
        printstream.println(stringbuilder.append(flag).toString());
        if(bitmap != null)
            return bitmap;
    }
    return null;
}
