public class ReadConfigFile {
    protected InputStream input = null;
    protected Properties prop = null;

    public ReadConfigFile() {
        try {
            ReadConfigFile.class.getClassLoader().getResourceAsStream(Constant.CONFIG_PROPERTIES_DIRECTORY);
            prop = new Properties();
            prop.load(input);
    try {
        input = ReadConfigFile.class.getClassLoader().getResourceAsStream(Constant.CONFIG_PROPERTIES_DIRECTORY);
        prop = new Properties();
        prop.load(input);

    } catch (IOException e) {
        e.printStackTrace();
    }
package utils;

public class Constant {

    /*
     * Config Property File 
     */

    public final static String CONFIG_PROPERTIES_DIRECTORY = "properties\\config.properties";

    public final static String CHROME_DRIVER_DIRECTORY = System.getProperty("user.dir") + "\\src\\test\\java\\resources\\chromedriver.exe";

    public final static String GECKO_DRIVER_DIRECTORY = System.getProperty("user.dir") + "\\src\\test\\java\\resources\\geckondriver.exe";

}
