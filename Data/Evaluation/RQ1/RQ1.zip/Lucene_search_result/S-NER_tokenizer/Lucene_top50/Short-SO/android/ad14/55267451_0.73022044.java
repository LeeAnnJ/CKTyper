    CompletableFuture feature = CompletableFuture.supplyAsync (() -&gt;       composeMethod ( )).
            thenAccept (s -&gt; System.out.println ("wassup java" + s)).
            thenRun (() -&gt; System.out.println (" imm immortal"));
    nonblockingmethod ( );
private static void nonblockingmethod() {
        System.out.println ("why  should i wait for you ");
    }

    private static String composeMethod() {
        try {
            TimeUnit.MILLISECONDS.sleep (3);
            File file = Paths.get ("/Users/solo/solo1.txt").toFile ( );

            if (!file.exists ( )) {
                file.createNewFile ( );
            }

        } catch (Exception e) {

        }
        return "   resultdaa";
    }
