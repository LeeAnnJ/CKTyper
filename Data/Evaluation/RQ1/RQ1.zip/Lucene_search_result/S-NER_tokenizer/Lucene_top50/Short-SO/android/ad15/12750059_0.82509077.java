public interface Hashable {

/**
 * Return the base offset for the {@link Object#hashCode()}, this number
 * should be unique and odd;
 * 
 * @return int
 */
public int getBaseOffset();

/**
 * Return the base offset for the class fields{@link Object#hashCode()},
 * this number should be unique and odd;
 * 
 * @return int
 */
public int getFieldOffset();

/**
 * Return an {@link Object} array of the fields to use for
 * {@link Object#equals(Object)} and {@link Object#hashCode()}
 * 
 * @return {@link Object} array
 */
public Object[] getHashFields();
}
public class HashUtil {

    /**
     * This method will create a hash code based on the
     * {@link Hashable#getHashFields()}. If the object is immutable this method
     * only needs to be called once through lazy initialization, otherwise the
     * class can call out to it through the {@link Object#hashCode()} override.
     * &lt;p&gt;
     * &lt;b&gt;Example:&lt;/b&gt;
     * 
     * &lt;pre&gt;
     * public int hashCode() {
     *     return HashUtil.createHash(this);
     * }
     * &lt;p&gt;
     * @param hashable
     *            {@link Object} implementing {@link Hashable} interface
     * @return int
     * to use for hash code
     */
    public static int createHash(Hashable hashable) {
        HashCodeBuilder builder = new HashCodeBuilder(hashable.getBaseOffset(), hashable.getFieldOffset());

        for (Object o : hashable.getHashFields()) {
            if (o != null) {
            builder.append(o);
            }
        }
        return builder.toHashCode();
    }

    /**
     * Evaluates whether two {@link Hashable} objects are equal. This method is
     * intended for use when overriding {@link Object#equals(Object)}.
     * &lt;p&gt;
     * &lt;b&gt;Example:&lt;/b&gt;
     * 
     * &lt;pre&gt;
     * public boolean equals(Object o) {
     *     return HashUtil.equals(this, o);
     * }
     * &lt;p&gt;
     * @param h1 first {@link Hashable} to compare
     * @param h2 second {@link Hashable} to compare
     * @return true if they are equal
     */
    public static boolean equals(Hashable h1, Hashable h2) {
        if (h1.getHashFields() == null || h2.getHashFields() == null) {
            if (!(h1.getHashFields() == null &amp;&amp; h2.getHashFields() == null)) {
            return false;
            }
            return true;
        }
        if (h1.getHashFields().length != h2.getHashFields().length) {
            return false;
        }
        EqualsBuilder builder = new EqualsBuilder();
        for (int x = 0; x &lt; h1.getHashFields().length; x++) {
            Object o1 = h1.getHashFields()[x];
            Object o2 = h2.getHashFields()[x];
            builder.append(o1, o2);
        }
        return builder.isEquals();
    }
}
