username=
user_hash=
saved_email=
email_hash=
public static String getConfigValue(Context context, String name) {
    Resources resources = context.getResources();
    String TAG = "Retrieve";
    try {
        InputStream rawResource = resources.openRawResource(R.raw.app_prefs);
        Properties properties = new Properties();
        properties.load(rawResource);
        return properties.getProperty(name);
    } catch (Resources.NotFoundException e) {
        Log.e(TAG, "Unable to find the config file: " + e.getMessage());
    } catch (IOException e) {
        Log.e(TAG, "Failed to open config file.");
    }
    return null;
}
private void commitUserInfotoFile(Context context, String username, String passhash, String rmemail, String rmemailhash) {
    Resources resources = context.getResources();
    String TAG = "Store";
    try {
        InputStream rawResource = resources.openRawResource(R.raw.app_prefs);
        Properties properties = new Properties();
        properties.load(rawResource);
        //tried using setProperty as well as put but neither works
        properties.setProperty("username", username);
        properties.put("username", username);
        properties.setProperty("user_hash", passhash);
        properties.setProperty("saved_email", rmemail);
        properties.setProperty("email_hash", rmemailhash);
        Log.e(TAG, "Wrote the values to the stored file");
    } catch (Resources.NotFoundException e) {
        Log.e(TAG, "Unable to find the config file: " + e.getMessage());
    } catch (IOException e) {
        Log.e(TAG, "IO Exception loading file.");
    }
}
