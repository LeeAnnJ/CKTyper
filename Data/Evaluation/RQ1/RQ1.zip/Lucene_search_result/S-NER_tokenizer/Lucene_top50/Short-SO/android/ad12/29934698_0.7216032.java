src/main/java/...
src/main/resources/application.conf

src/test/java/...
src/test/resources/module/test.module.conf
  @Test
  public void testLoadConfig() {
    final Config config = ConfigFactory.parseResources("test.module.conf");
    System.out.println(config);
  }
  @Test
  public void testActorForFailure() {
//    final Config config = ConfigFactory.load("test.module.conf");
    final Config config = ConfigFactory.load();
    System.out.println(config.getString("location"));

  }
