private Bitmap getBitmapFromView(View view) {
    view.buildDrawingCache();
    Bitmap returnedBitmap = Bitmap.createBitmap(view.measuredWidth,
            view.measuredHeight,
            Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(returnedBitmap);
    canvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC_IN);
    Drawable drawable = view.background;
    drawable.draw(canvas);
    view.draw(canvas);
    return returnedBitmap;
}
Point getViewLocationOnScreen(View v) {
    int[] coor = new int[]{0, 0};
    v.getLocationOnScreen(coor);
    return new Point(coor[0], coor[1]);
}
for (int x = 0; x &lt; myBitmap.getWidth(); x++) {
    for (int y = 0; y &lt; myBitmap.getHeight(); y++) {
        int color = myBitmap.getPixel(x, y);
    }
}
