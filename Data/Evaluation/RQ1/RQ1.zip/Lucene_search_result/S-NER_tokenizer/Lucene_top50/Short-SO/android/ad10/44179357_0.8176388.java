&lt;LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:orientation="vertical"
    android:layout_width="370dp"
    android:layout_height="400dp"
    android:background="@drawable/ic_background"&gt;

    &lt;TextView
        android:id="@+id/address"
        android:layout_width="match_parent"
        android:textColor="@color/white"
        android:textSize="40sp"
        android:textStyle="bold"
        android:gravity="center"
        android:layout_height="wrap_content"/&gt;
&lt;/LinearLayout&gt; 
private void generateAndShareImage(){
    final LayoutInflater inflater = (LayoutInflater)this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    final View view = inflater.inflate(R.layout.image_address, null);
    final TextView addressView = (TextView) view.findViewById(R.id.address);
    addressView.setText("Test Address");

    final Bitmap cardImage = getBitmapFromView(view);
    //store image in external storage
    String savedImagePath = storeImage(cardImage);
    if(savedFilePath != null){
        scanGallery(savedImagePath);
    }
}

private void scanGallery(final String path) {
    try {
        MediaScannerConnection.scanFile(getBaseContext(), new String[] { path },null, new MediaScannerConnection.OnScanCompletedListener() {
            public void onScanCompleted(String path, Uri uri) {
            }
        });
    } catch (Exception e) {
        Log.e("Error scanning gallery",e.getMessage());
    }
}

private Bitmap getBitmapFromView(@NonNull  final View view){
    final Bitmap bitmap = Bitmap.createBitmap(370, 400, Bitmap.Config.ARGB_8888);
    final Canvas canvas = new Canvas(bitmap);
    view.draw(canvas);
    return bitmap;
}
