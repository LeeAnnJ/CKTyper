            synchronized(s1) {
                synchronized(s2) {
                    s1.equals(s2);
                }
            }
            synchronized(s1) {
                synchronized(s2) {
                    s2.equals(s1);
                }
            }
while(forever){
    synchronized(s1){
        s1.equals(s2);
    }
}
while(forever){
   synchronized(s1){
    s2.equals(s1);
   }
}
 private static final Object lock = new Object(); // May be context-local.

 [...]

     synchronized (lock) {
         synchronized (s1) {
             synchronized (s2) {
                 return s1.equals(s2);
             }
          }
     }
    int h1 = System.identityHashCode(s1);
    int h2 = System.identityHashCode(s2);
    return
         h1&lt;h2 ? lockFirstEquals(h1, h2) :
         h2&lt;h1 ? lockFirstEquals(h2, h1) :
         globalLockEquals(h1, h2);
public StringBuffer append(StringBuffer other) {
    if (other == null) {
        return append("null");
    }
    int thisHash  = System.identityHashCode(this);
    int otherHash = System.identityHashCode(other);
    if (thisHash &lt; otherHash) {
        synchronized (this) {
            synchronized (other) {
                appendImpl(other);
            }
        }
    } else if (otherHash &lt; thisHash) {
        synchronized (other) {
            synchronized (this) {
                appendImpl(other);
            }
        }
    } else {
        append(other.toString()); // Or append((Object)other);
    }
    return this;
}
