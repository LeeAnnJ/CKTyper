class MainActivity : AppCompatActivity() {

    private var scrollView: ScrollView? = null
    private var imagePath: File? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //create bitmap from the ScrollView
        fun getBitmapFromView(view: View, height: Int, width: Int): Bitmap {
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val bgDrawable = view.background
            if (bgDrawable != null)
                bgDrawable.draw(canvas)
            else
                canvas.drawColor(Color.WHITE)
            view.draw(canvas)
            return bitmap
        }

        ERROR LINE fun shareIt(imagePath: File? = imagePath) {

            val uri = FileProvider.getUriForFile(this@MainActivity, BuildConfig.APPLICATION_ID + ".provider", imagePath!!)

            val sharingIntent = Intent(Intent.ACTION_SEND)
            sharingIntent.type = "image/*"
            val shareBody = "APP"
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "APP")
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody)
            sharingIntent.putExtra(Intent.EXTRA_STREAM, uri)

            startActivity(Intent.createChooser(sharingIntent, "SARE VIA"))
        }
        var share = findViewById&lt;View&gt;(R.id.share) as Button
        share = findViewById&lt;View&gt;(R.id.share) as Button
        share.setOnClickListener {
            val bitmap = getBitmapFromView(scrollView!!, scrollView!!.getChildAt(0).height, scrollView!!.getChildAt(0).width)
            saveBitmap(bitmap)
            shareIt()
        }
    }
    @Throws(IOException::class)
    private fun createScreenShotImageFile(): File {
        var mediaStorageDir = File(
            Environment.getExternalStorageDirectory(),
            "YourAppName"
        )
        var screenShotDirectory = "${mediaStorageDir}/screenShots"
        val file = File(screenShotDirectory)
        if (!file.exists()) {
            file.mkdirs()
        }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val imageFileName = "screeShotImage-$timeStamp.png"
        return File(screenShotDirectory, imageFileName)
    }

    fun saveBitmap(bitmap: Bitmap) {
        imagePath =  createScreenShotImageFile()
        val fos: FileOutputStream
        try {
            fos = FileOutputStream(imagePath)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos)
            fos.flush()
            fos.close()
        } catch (e: FileNotFoundException) {
            Log.e("GREC", e.message, e)
        } catch (e: IOException) {
            Log.e("GREC", e.message, e)
        }
    }
}
