public class SaveSharedPreference {

    static final String PREF_LANGUAGE="language";

    static SharedPreferences getSharedPreferences(Context ctx) {
        return PreferenceManager.getDefaultSharedPreferences(ctx);
    }    

    public static void setLanguage(Context context,String language){
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(PREF_LANGUAGE,language);
        editor.commit();
    }

    public static String getLaguage(Context context){
        return getSharedPreferences(context).getString(PREF_LANGUAGE,"");
    }

}
if (SaveSharedPreference.getLaguage(context).length()!=0) {

        if(SaveSharedPreference.getLaguage(context).toString().equals("si")){
             String languageToLoad = SaveSharedPreference.getLaguage(context); // your language
             Locale locale = new Locale(languageToLoad);
             Locale.setDefault(locale);
             Configuration config = new Configuration();
             config.locale = locale;
             getBaseContext().getResources().updateConfiguration(config,
                    getBaseContext().getResources().getDisplayMetrics());
        } else {
            String languageToLoad = SaveSharedPreference.getLaguage(context).toString(); // your language
            Locale locale = new Locale(languageToLoad);
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = locale;
            getBaseContext().getResources().updateConfiguration(config,
                    getBaseContext().getResources().getDisplayMetrics());
        }
} else {    
    String languageToLoad = "en"; // your language
    Locale locale = new Locale(languageToLoad);
    Locale.setDefault(locale);
    Configuration config = new Configuration();
    config.locale = locale;
    getBaseContext().getResources().updateConfiguration(config,
                    getBaseContext().getResources().getDisplayMetrics());
}
@Override
    protected void onResume() {
        super.onResume();
}
&lt;resources&gt;
    &lt;string name="label_dash_board_name"&gt;My dashboard&lt;/string&gt;
&lt;/resources&gt;
&lt;resources&gt;
    &lt;string name="label_dash_board_name"&gt;දත්ත පුවරුව&lt;/string&gt;
&lt;/resources&gt;    
