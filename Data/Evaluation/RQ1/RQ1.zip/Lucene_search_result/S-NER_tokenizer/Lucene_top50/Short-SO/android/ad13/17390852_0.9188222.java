    public void refreshListIcons() {

            if (categories != null) {

                SettingsValue[] values = adapter.getValues();
                for (int i = 0; i &lt; values.length; i++) {
                    values[i].icon = ResManager
                            .GetSkinDrawable(categories[i].iconName + ".bin");
                }

                adapter.setValues(values);

                mListView.setAdapter(adapter);
                adapter.notifyDataSetChanged();
            }
    }
@Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.settings_item, null);
        }
...
}
package com.waze.settings;


public class SettingValueAdapter extends BaseAdapter {

    private SettingsValue[] values;
    private LayoutInflater inflater;
    public SettingValueAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    public SettingsValue[] getValues() {
        return values;
    }

    @Override
    public int getCount() {
        if (values == null) {
            return 0;
        }
        return values.length;
    }


    @Override
    public Object getItem(int arg0) {
        return values==null? null : values[arg0];       
    }

    @Override
    public long getItemId(int arg0) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.settings_item, null);
        }
        SettingsValue item = values[position];
        CheckedTextView name = (CheckedTextView) convertView.findViewById(R.id.itemText);
        ImageView iconView = (ImageView) convertView.findViewById(R.id.itemIcon);
        if (iconView != null &amp;&amp; (item != null) &amp;&amp; (item.icon != null)) {
            iconView.setImageDrawable(item.icon);
            iconView.setVisibility(View.VISIBLE);
        } else {
            iconView.setVisibility(View.GONE);
        }
        name.setText(item.display);
        name.setChecked(item.isSelected);
        View container = convertView.findViewById(R.id.itemContainer);
        if (position == 0) {
            if (position == values.length-1) {
                container.setBackgroundResource(R.drawable.item_selector_single);
            } else {
                container.setBackgroundResource(R.drawable.item_selector_top);
            }
        } else {
            if (position == values.length-1) {
                container.setBackgroundResource(R.drawable.item_selector_bottom);
            } else {
                container.setBackgroundResource(R.drawable.item_selector_middle);
            }
        }
        container.setPadding(0, 0, 0, 0);
        return convertView;
    }

    public void setValues(SettingsValue[] values) {
        this.values = values;
        notifyDataSetChanged();
    }
}
