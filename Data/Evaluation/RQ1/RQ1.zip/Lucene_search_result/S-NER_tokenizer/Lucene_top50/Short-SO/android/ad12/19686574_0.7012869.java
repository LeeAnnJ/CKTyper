ResourceConfig.registerInstances(resourceInstance);
new org.glassfish.jersey.servlet.ServletContainer(ResourceConfig);
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;

public class HelloWorldJerseyJetty {

    // http://localhost:8080/resources/resource

    public static void main(String[] args) throws Exception {

        Server server = new Server(8080);

        ResourceConfig config = new ResourceConfig();
        config.registerInstances(new Resource("Hello World"));
        org.glassfish.jersey.servlet.ServletContainer jerseyServlet = new org.glassfish.jersey.servlet.ServletContainer(config);

        ServletContextHandler handler = new ServletContextHandler();
        handler.addServlet(new ServletHolder(jerseyServlet), "/resources/*");

        server.setHandler(handler);
        server.start();
        server.join();

    }

    @Path("resource")
    public static class Resource {

        private final String message;

        public Resource(String message) {
            this.message = message;
        }

        @GET
        @Produces(MediaType.TEXT_PLAIN)
        public String get() {
            return message;
        }
    }
}
        ResourceConfig config = new ResourceConfig();
        config.registerInstances(new Resource("Hello World"));
        AtmosphereServlet atmosphereServlet = new AtmosphereServlet();
        atmosphereServlet.???

        ServletContextHandler handler = new ServletContextHandler();
        handler.addServlet(new ServletHolder(atmosphereServlet), "/resources/*");
