import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class testLotus {

    public static void main(String[] args) {
        JFrame gui= new JFrame();
        JLabel h1 = new JLabel("Some text");
        JTextField text = new JTextField(15);

        JPanel panel = new JPanel();

        h1.setBounds(180,50,120,20); //this is it
        text.setBounds(180,90,120,20); // and this

        panel.setLayout(null);
        panel.add(h1);
        panel.add(text);

        gui.getContentPane().add(panel);
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setSize(800,600 );
        gui.setVisible(true);
    }
}
