mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

    private String TAG = getClass().getSimpleName();

    @Override
    public boolean onQueryTextChange(String queryText) {
        Log.d(TAG, "onQueryTextChange = " + queryText);
        //Toast.makeText(MapActivity.this, "Change: " + queryText, Toast.LENGTH_SHORT).show();
        addMarkers(queryText);

        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String queryText) {
        Log.d(TAG, "onQueryTextSubmit = " + queryText);
        //Toast.makeText(MapActivity.this, "Change: " + queryText, Toast.LENGTH_SHORT).show();
        addMarkers(queryText);

        if (mSearchView != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);

            if (imm != null) {
                   imm.hideSoftInputFromWindow(mSearchView.getWindowToken(), 0);
            }

            mSearchView.clearFocus();
        }

        return true;
    }
});
