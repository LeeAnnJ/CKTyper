public class RunnerTest {

    public static void main(String[] args) throws Throwable {
        System.setProperty("TagConfigFile", "../../config/application.properties");

        //...

        String sConfigFile = System.getProperty("TagConfigFile", "null");

        try (InputStream streamFromResources = Props.class.getClassLoader().getResourceAsStream(sConfigFile)) {
            /* work wiht  streamFromResources */
        } catch (IOException | NullPointerException ee) {
            throw new PropsRuntimeException("Failed to access properties file", ee);
        }
    }
}
 1. "../../config/application.properties"
 2. "src/resources/config/application.properties"
 3. "../../resources/config/application.properties"
