     &lt;EditText
        android:id="@+id/editText1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:focusable="true"
        android:ems="10" &gt;
     &lt;/EditText&gt;
public static void hideSoftKeyboard (Activity activity, View view) {
 InputMethodManager imm =(InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE);
 imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);}
&lt;activity android:name="com.your.package.ActivityName"
      android:windowSoftInputMode="stateHidden"  /&gt;
