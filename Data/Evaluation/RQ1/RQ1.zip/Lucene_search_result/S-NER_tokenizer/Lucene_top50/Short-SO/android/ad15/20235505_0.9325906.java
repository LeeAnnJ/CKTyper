run:
h1 is 123456789
Expected: h1 is 123456789
1
2
tail digit:1
3
tail digit:2
4
tail digit:3
5
tail digit:4
6
tail digit:5
7
tail digit:6
8
tail digit:7
9
tail digit:8
h3 is null
Expected: h3 is 123456789
BUILD SUCCESSFUL (total time: 0 seconds)
if(newList.head != null || newList != null)
                {
                    System.out.println ("not null :D");
                    System.out.println(newList.toString());
                }
public static void main(String[] args)
{
       // Create a HugeNumber that is 123456789
   HugeNumber h1 = new HugeNumber();
   for (int i=9; i&gt;=1; i--)
   {
       h1.addDigit(i);
   }
   System.out.println("h1 is " + h1.toString());
       System.out.println("Expected: h1 is 123456789");

 // Make a copy of h1
   HugeNumber h3 = new HugeNumber(h1);
   System.out.println("h3 is " + h3.toString());
       System.out.println("Expected: h3 is 123456789");
}
class HugeNumber
{


/**
* Inner class to store a digit within a node
*/
private class DigitNode
{
    private int digit=0;            // Value for this digit
    private DigitNode next=null;    // Reference to next digit
    private DigitNode prev=null;    // Reference to previous digit
    /**
    * DigitNode constructor, initializes number
    */
    public DigitNode(int d)
    {
        digit = d;                        
            }
    /* Accessor and mutator methods */
    public int getDigit()
    {
        return digit;
    }
    public void setDigit(int d)
    {
        digit = d;
    }
    public DigitNode getNext()
    {
        return next;
    }
    public void setNext(DigitNode nextNode)
    {
        next = nextNode;
    }
    public DigitNode getPrev()
    {
        return prev;
    }
    public void setPrev(DigitNode prevNode)
    {
        prev = prevNode;
    }
}

// Variable declarations
private DigitNode head = null;  // Head points to the most significant digit in   the list
private DigitNode tail = null;      // Tail points to the least significant digit in the list


/**
* Constructors
*/
public HugeNumber()
{

}

/**
* addDigit adds a new digit, d, as a new most significant
* digit for the list.
* @param d new digit to add as the MSD
*/
public void addDigit(int d)
{
        DigitNode nodes = new DigitNode(d);
        if (head != null)
        {
            head.setPrev(nodes);
            nodes.setNext(head);
        }

        head = nodes;

        if(tail == null)
        {
            tail = nodes;
        }


}

/**
* Resets the HugeNumber to a null, empty value
*/
public void resetValue()
{
    head = null;
            tail = null;
}

/**
* @return String The HugeNumber converted to a string
*/
 public String toString() {
    if (head == null)
    {
        return null;              
    }

    String print = "";
    DigitNode temp = head;

    while (temp != null) {
        print = print + temp.getDigit();
        temp = temp.getNext();
    }
    return print;
}
    /**
* Deep copy constructor
* @param newVal Input HugeNumber to copy to this HugeNumber
    */
public HugeNumber(HugeNumber newVal)
{
    // Traverse the input HugeNumber, copying each node to a new list
    //
            HugeNumber newList = new HugeNumber ();
            newList.head = newVal.head;                
            newList.tail = newList.head;  

            DigitNode currentNode = new DigitNode(1);
            DigitNode OldListNode = newVal.head;

            //to make sure the head is copied
            System.out.println(newList.head.digit);

            while(currentNode != newVal.tail)
            {
                OldListNode = OldListNode.next;
                currentNode = OldListNode;  

                //to make sure the currentNode is the one we want to copy and it is being transverse
                System.out.println(currentNode.digit);


                currentNode.setPrev(newList.tail);
                newList.tail.setNext(currentNode);
                newList.tail = currentNode;

                // to make sure the list is linked
                System.out.println("tail digit:" + newList.tail.prev.digit);
            }

                if(newList.head  == null || newList == null )
                {
                    System.out.println("--------------------------newList is null :(");
                }


}



}
