InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(myEditText.getWindowToken(), 0);
private final Handler mHandler = new Handler() {

    @Override
    public void handleMessage(Message msg) {
        if (null != mProgress) {
            mProgress.show();
        }
    }
};
private void showWaitPopup(final boolean doShow) {
    if (doShow) {
        if (null == mProgress) {
            mProgress = new ProgressDialog(this);
            mProgress.setMessage(getString(R.string.searching));
            mProgress.setCancelable(false);

            // launch timer here
            mHandler.sendEmptyMessageDelayed(0, 100);
        }
    } else {
        if (null != mProgress) {
            mProgress.dismiss();
            mProgress = null;
        }
    }
}
SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
searchManager.setOnDismissListener(new OnDismissListener() {

    @Override
    public void onDismiss() {
        final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, 0);
    }
});
InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
imm.toggleSoftInput(0, 0);
