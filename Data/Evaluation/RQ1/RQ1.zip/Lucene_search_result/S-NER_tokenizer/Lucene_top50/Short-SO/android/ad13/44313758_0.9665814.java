try{
    //where null values occur
}catch(NullPointerException e){
  System.out.println("errr");//you dont want add this but it is good to display something.
}
public void startProgress();

public void updateProgress(String message, int progress);

public void stopProgress();
public class MainView {
private JComponent view = null;

private ProgressView progressView = null;
private LoadDataView loadDataView = null;

public MainView(){
    progressView = new ProgressView();
    loadDataView = new LoadDataView();
}

public JComponent getView(){
    if (view == null) view = createView();
    return view;
}

private JComponent createView(){
    JPanel result = new JPanel( new BorderLayout() );

    result.add( progressView.getView(), BorderLayout.NORTH );
    result.add( loadDataView.getView(), BorderLayout.CENTER );

    return result;
}

public static void main(String[] args) throws IOException {
    MainView mainView = new MainView();

    JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    frame.getContentPane().add( mainView.getView() );

    frame.setSize(400, 200);
    frame.setVisible(true);
}
public class ProgressView {

private static ProgressHandlerImpl progressHandler = new ProgressHandlerImpl(); 

private JComponent view = null;

public static ProgressHandler getProgressHandler(){
    return progressHandler;
}

public JComponent getView(){
    if (view == null) view = createView();
    return view;
}

private JComponent createView(){
    JPanel result = new JPanel( new BorderLayout() );        
    result.add( progressHandler.getMessageLabel(), BorderLayout.NORTH );
    result.add( progressHandler.getProgressBar(), BorderLayout.CENTER );
    return result;
}

private static class ProgressHandlerImpl implements ProgressHandler{
    public JProgressBar progressBar = null;
    public JLabel messageLabel = null;

    public ProgressHandlerImpl(){
        progressBar = new JProgressBar();
        progressBar.setVisible(false);
        progressBar.setStringPainted(true);

        messageLabel = new JLabel();
        messageLabel.setVisible(false);
    }

    public JProgressBar getProgressBar(){
        return progressBar;
    }

    public JLabel getMessageLabel(){
        return messageLabel;
    }

    @Override
    public void startProgress(){
        java.awt.EventQueue.invokeLater( new Runnable(){ public void run(){
        progressBar.setValue(0);
        progressBar.setVisible(true); } } );            
    }

    @Override
    public void updateProgress(String message, int progress) {
        java.awt.EventQueue.invokeLater( new Runnable(){  public void run(){
        progressBar.setValue(progress); 

        if (message == null) return;

        if ( !messageLabel.isVisible() ) messageLabel.setVisible(true);

        messageLabel.setText(message);
        } } );  
    }

    @Override
    public void stopProgress(){
        java.awt.EventQueue.invokeLater( new Runnable(){  public void run(){
        progressBar.setValue(0);
        progressBar.setVisible(false); 
        messageLabel.setVisible(false);} } );  
    }       
}
public class LoadDataView {
private JComponent view = null;
private Thread thread = null;

public JComponent getView(){
    if (view == null) view = createView();
    return view;
}

private JComponent createView(){
    JPanel result = new JPanel();

    JButton startProgressButton = new JButton("start");
    startProgressButton.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent e) { startProgress(); } } );        
    result.add(startProgressButton);

    JButton stopProgressButton = new JButton("stop");
    stopProgressButton.addActionListener( new ActionListener() { public void actionPerformed(ActionEvent e) { stopProgress(); } } );        
    result.add(stopProgressButton);

    return result;
}

private void startProgress(){
    if (thread != null) throw new IllegalStateException();

    thread = new Thread( new Runnable(){ public void run(){
        ProgressView.getProgressHandler().startProgress();

        for (int i = 0; i &lt; 100; i++){
            ProgressView.getProgressHandler().updateProgress("Loading...", i);

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {                   
                ProgressView.getProgressHandler().updateProgress("Loading stopped!", i);
                //do some other logging
                break;
            }
        }

    } } );

    thread.start();
}

private void stopProgress(){
    if (thread == null) return;

    thread.interrupt(); 

    thread = null;
}
public JProgressBar getProgressBar()
{
    return p1hp;
}
UI ui = new UI();
final JProgressBar progressBar = ui.getProgressBar();
public static void main(String[] args) throws IOException {

    java.awt.EventQueue.invokeLater(new Runnable() {
        @Override
        public void run() {
            UI ui = new UI();
            ui.setVisible(true);
            ui.getProgressBar().setStringPainted(true);
            ui.getProgressBar().setValue(12);
        }
    });
