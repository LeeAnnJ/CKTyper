googleMap.addMarker(new MarkerOptions()
    .position(new LatLng(latitude, longitude))
    .title("Your position")).showInfoWindow();
Marker marker = mMap.addMarker(new MarkerOptions().position(currentPosition).title("Your text"));
marker.showInfoWindow();
public BitmapDescriptor getBitmapFromView(String title) {
        View view = LayoutInflater.from(activity.getApplicationContext()).inflate(R.layout.marker_tooltip, null);
        ((TextView) view.findViewById(R.id.tooltips_title)).setText(title);

        //Get the dimensions of the view. In my case they are in a dimen file
        int width = activity.getResources().getDimensionPixelSize(R.dimen.tooltips_width);
        int height = activity.getResources().getDimensionPixelSize(R.dimen.tooltips_height);

        int measuredWidth = View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY);
        int measuredHeight = View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY);

        view.measure(measuredWidth, measuredHeight);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        view.draw(canvas);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

...
marker.setIcon(getBitmapFromView(marker.getTitle()));
...
public void makersMaker(GoogleMap googleMap){
    IconGenerator iconFactory = new IconGenerator(this);                            
    Marker marker1 = googleMap.addMarker(new MarkerOptions().position(newLatLng(-1.3177336,36.8251902));                  
    marker1.setIcon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon("Marker 1")));
    Marker marker2 = googleMap.addMarker(new MarkerOptions().position(new LatLng(-1.2857399,36.8214088)));                
    marker2.setIcon(BitmapDescriptorFactory.fromBitmap(iconFactory.makeIcon("Marker 2")));
}
