    private Bitmap getToBitmap(ImageView view, int Width, int Heigth){
    Bitmap bitmap = Bitmap.createBitmap(Width,Heigth, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    view.draw(canvas);
    return bitmap;
}
    private void TrySaveMediaStore(){
    String path = Environment.getExternalStorageDirectory().toString();
    OutputStream FileOut = null;
    File file = new File(path,"DCIM/MyFolder");
    file.mkdirs();
    Toast.makeText(getApplicationContext(),file.getAbsolutePath(),Toast.LENGTH_SHORT).show();

    try{
        FileOut = new FileOutputStream(file);
        FileOut.flush();
        FileOut.close();
        Bitmap bitmap = getToBitmap(img,img.getMaxWidth(),img.getMaxHeight());
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,FileOut);
        MediaStore.Images.Media.insertImage(getContentResolver(), file.getAbsolutePath(), file.getName(), file.getName());
        Toast.makeText(this,file.getAbsolutePath(),Toast.LENGTH_SHORT).show();
    }catch (FileNotFoundException e){
        return;
    }catch (IOException e){
        e.printStackTrace();
    }

}
&lt;uses-permission android:name="android.permission.INTERNET" /&gt;
&lt;uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" /&gt;
&lt;uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" /&gt;
