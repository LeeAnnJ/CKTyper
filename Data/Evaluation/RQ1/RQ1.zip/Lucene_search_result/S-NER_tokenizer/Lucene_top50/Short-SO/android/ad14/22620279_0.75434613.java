public void finishFragment() {
    View focus = getCurrentFocus();
    InputMethodManager imm = null;
    if (focus != null) {
        imm = (InputMethodManager) focus.getContext().
                getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm.isActive()) {
            imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        }
    }
    if (getFragmentManager().getBackStackEntryCount() &gt; 1) {
        getFragmentManager().popBackStack();
    }
}
