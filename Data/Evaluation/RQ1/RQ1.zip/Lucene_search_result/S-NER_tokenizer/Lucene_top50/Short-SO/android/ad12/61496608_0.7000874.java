    public class Language {
        private static String PREFS_LANGUAGE = "LANGUAGE";

        public static void setLanguage(Context context, String language, Activity activity) {
            // Save selected language
            persist(language);

            // Update language
            Locale locale = new Locale(language);
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.locale = Locale.UK;
            context.getResources().updateConfiguration(config, MainApplication.getContext().getResources().getDisplayMetrics());
            activity.onConfigurationChanged(config);
        }

        private static SharedPreferences getSharedPrefs(Context context) {
            return context.getSharedPreferences(context.getPackageName(), Context.MODE_PRIVATE);
        }

        private static void persist(String language) {
            SharedPreferences.Editor editor = getSharedPrefs(MainApplication.getContext()).edit();
            editor.putString(PREFS_LANGUAGE, language);
            editor.apply();
        }
    }
       fun setLanguage(language: String){
            Language.setLanguage(MainApplication.getContext(),language, this)
        }

         override fun onConfigurationChanged(newConfig: Configuration) {
            super.onConfigurationChanged(newConfig)
             recreate()
        }
