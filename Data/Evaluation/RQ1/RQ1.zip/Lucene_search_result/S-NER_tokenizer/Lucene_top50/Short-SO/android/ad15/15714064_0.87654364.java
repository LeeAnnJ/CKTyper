public class MainActivity extends Activity {
     WebView browser;
    private static String inp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         browser=(WebView)findViewById(R.id.w1);


         // browser.loadDataWithBaseURL("x-data://base",inp,"text/html", "UTF-8",null);
         browser.loadData(inp, "text/html", "UTF-8"); 



    }
    public void insertUndergraduate(){
        AndroidOpenDbHelper androidOpenDbHelperObj = new AndroidOpenDbHelper(this);
        SQLiteDatabase sqliteDatabase = androidOpenDbHelperObj.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        inp = "&lt;html&gt;"+"&lt;body&gt;&lt;h1&gt;hai mohan&lt;/h1&gt;&lt;/body&gt;"+"&lt;/html&gt;";
        contentValues.put(AndroidOpenDbHelper.COLUMN_NAME_PAGE,inp);

    }
}
