package com.epicgames.ue4;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Map;
import java.util.Properties;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.YourCompany.AdMobPlugin.R;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.AdapterStatus;

import com.epicgames.ue4.network.NetworkChangedManager;


public class GameApplication extends Application implements LifecycleObserver, Application.ActivityLifecycleCallbacks {
    private static final Logger Log = new Logger(&quot;UE4&quot;, &quot;GameApp&quot;);

    private static final String LOG_TAG = &quot;LogAdMaster&quot;;

    private static boolean isForeground = false;

    private AppOpenAdManager appOpenAdManager;
    private Activity currentActivity;
    private boolean AdMaster_autoInit = true;
    private boolean AdMaster_autoAppOpenAd = false;
    private String AdMaster_appOpenAdId = &quot;ca-app-pub-3940256099942544/3419835294&quot;;
    private boolean AdMaster_isAppOpenShowed = false;

    public Context getContext() { return (Context)this; }

    public void AndroidThunk_AdMaster_initialize() {
        MobileAds.initialize(this, initializationStatus -&gt; {
            Map&lt;String, AdapterStatus&gt; statusMap = initializationStatus.getAdapterStatusMap();
            for (String adapterClass : statusMap.keySet()) {
                AdapterStatus status = statusMap.get(adapterClass);
                android.util.Log.d(LOG_TAG, String.format(
                    &quot;Adapter name: %s, Description: %s, Latency: %d&quot;,
                    adapterClass, status.getDescription(), status.getLatency()));
            }
        });
    }
    
    /** Show the ad if one isn't already showing. */
    public void AndroidThunk_AdMaster_showAppOpenAdIfAvailable() {
        // We wrap the showAdIfAvailable to enforce that other classes only interact with MyApplication
        // class.
        appOpenAdManager.showAdIfAvailable(currentActivity);
    }

    private void loadProperties() {
        android.util.Log.d(LOG_TAG, &quot;LOADING&quot;);
        Resources resources = getContext().getResources();

        try {
            InputStream rawResource = resources.openRawResource(R.raw.config);
            Properties properties = new Properties();
            properties.load(rawResource);

            String autoInit = properties.getProperty(&quot;admaster.auto_init&quot;);
            String autoAppOpenAd = properties.getProperty(&quot;admaster.auto_app_open_ad&quot;);
            String appOpenAdId = properties.getProperty(&quot;admaster.app_open_ad_id&quot;);

            if (autoInit != null) {
                AdMaster_autoInit = Boolean.parseBoolean(autoInit);
            }
            if (autoAppOpenAd != null) {
                AdMaster_autoAppOpenAd = Boolean.parseBoolean(autoAppOpenAd);
            }
            if (appOpenAdId != null) {
                AdMaster_appOpenAdId = appOpenAdId;
            }

        } catch (Resources.NotFoundException e) {
            android.util.Log.e(LOG_TAG, &quot;Unable to find the config file: &quot; + e.getMessage());
        } catch (IOException e) {
            android.util.Log.e(LOG_TAG, &quot;Failed to open config file.&quot;);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();

        loadProperties();

        this.registerActivityLifecycleCallbacks(this);

        if (AdMaster_autoInit) {
            AndroidThunk_AdMaster_initialize();
        }

        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);

        appOpenAdManager = new AppOpenAdManager(AdMaster_appOpenAdId);

        NetworkChangedManager.getInstance().initNetworkCallback(this);
    }

    @Override
    public void attachBaseContext(Context base) {
        super.attachBaseContext(base);

    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();

    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);

    }

    @Override
    public void onConfigurationChanged (Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    void onEnterForeground() {
        Log.verbose(&quot;App in foreground&quot;);
        isForeground = true;

        android.util.Log.d(LOG_TAG, &quot;AdMaster_autoInit: &quot; + AdMaster_autoInit + &quot;\r\nAdMaster_autoAppOpenAd: &quot; + AdMaster_autoAppOpenAd + &quot;\r\nAdMaster_isAppOpenShowed: &quot; + AdMaster_isAppOpenShowed);

        if (AdMaster_autoInit &amp;&amp; AdMaster_autoAppOpenAd &amp;&amp; !AdMaster_isAppOpenShowed) {
            android.util.Log.d(LOG_TAG, &quot;ACTIVITY: &quot; + (currentActivity != null ? &quot;NOT NULL&quot; : &quot;NULL&quot;));
            android.util.Log.d(LOG_TAG, &quot;appOpenAdManager: &quot; + (currentActivity != null ? &quot;NOT NULL&quot; : &quot;NULL&quot;));
            // Show the ad (if available) when the app moves to foreground.
            appOpenAdManager.showAdAndWaitUntilLoaded(currentActivity);
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    void onEnterBackground() {
        Log.verbose(&quot;App in background&quot;);
        isForeground = false;
    }

    @SuppressWarnings(&quot;unused&quot;)
    public static boolean isAppInForeground() {
        return isForeground;
    }

    public static boolean isAppInBackground() {
        return !isForeground;
    }

    /** ActivityLifecycleCallback methods. */
    @Override
    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}

    @Override
    public void onActivityStarted(Activity activity) {
        // Updating the currentActivity only when an ad is not showing.
        if (!appOpenAdManager.isShowingAd) {
            currentActivity = activity;
        }
    }

    @Override
    public void onActivityResumed(Activity activity) {}

    @Override
    public void onActivityStopped(Activity activity) {}

    @Override
    public void onActivityPaused(Activity activity) {}

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {}

    @Override
    public void onActivityDestroyed(Activity activity) {}

    /** Interface definition for a callback to be invoked when an app open ad is complete. */
    public interface OnShowAdCompleteListener {
        void onShowAdComplete();
    }

    private class AppOpenAdManager {
        private static final String LOG_TAG = &quot;AppOpenAdManager&quot;;
        private String AD_UNIT_ID = &quot;ca-app-pub-3940256099942544/3419835294&quot;;

        private AppOpenAd appOpenAd = null;
        private boolean isLoadingAd = false;
        private boolean isShowingAd = false;

        /** Keep track of the time an app open ad is loaded to ensure you don't show an expired ad. */
        private long loadTime = 0;

        /** Constructor. */
        public AppOpenAdManager(String adUnitAd) { AD_UNIT_ID = adUnitAd; }

        /** Request an ad. */
        private void loadAd(Context context) {
            // Do not load ad if there is an unused ad or one is already loading.
            if (isLoadingAd || isAdAvailable()) {
                return;
            }

            isLoadingAd = true;
            AdRequest request = new AdRequest.Builder().build();
            AppOpenAd.load(
                context, AD_UNIT_ID, request,
                AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
                new AppOpenAd.AppOpenAdLoadCallback() {
                    @Override
                    public void onAdLoaded(AppOpenAd ad) {
                        // Called when an app open ad has loaded.
                        android.util.Log.d(LOG_TAG, &quot;Open App Ad was loaded.&quot;);
                        appOpenAd = ad;
                        isLoadingAd = false;

                        loadTime = (new Date()).getTime();
                    }

                    @Override
                    public void onAdFailedToLoad(LoadAdError loadAdError) {
                        // Called when an app open ad has failed to load.
                        android.util.Log.d(LOG_TAG, loadAdError.getMessage());
                        isLoadingAd = false;
                    }
            });
        }

        /** Utility method to check if ad was loaded more than n hours ago. */
        private boolean wasLoadTimeLessThanNHoursAgo(long numHours) {
            long dateDifference = (new Date()).getTime() - this.loadTime;
            long numMilliSecondsPerHour = 3600000;
            return (dateDifference &lt; (numMilliSecondsPerHour * numHours));
        }

        /** Check if ad exists and can be shown. */
        private boolean isAdAvailable() {
            return appOpenAd != null &amp;&amp; wasLoadTimeLessThanNHoursAgo(4);
        }

        public void showAdAndWaitUntilLoaded(@NonNull final Activity activity) {
            android.util.Log.d(LOG_TAG, &quot;INSIDE METHOD&quot;);
            int attempts = 5;
            while (!isShowingAd &amp;&amp; attempts != 0) {
                android.util.Log.d(LOG_TAG, &quot;Show App Open Ad attempt: &quot; + attempts);
                showAdIfAvailable(activity);
                attempts--;
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            AdMaster_isAppOpenShowed = true;
        }

        /** Shows the ad if one isn't already showing. */
        private void showAdIfAvailable(@NonNull final Activity activity) {
            showAdIfAvailable(
                    activity,
                    () -&gt; {
                        // Empty because the user will go back to the activity that shows the ad.
                    });
        }
        public void showAdIfAvailable(
            @NonNull final Activity activity,
            @NonNull OnShowAdCompleteListener onShowAdCompleteListener) {
            
            // If the app open ad is already showing, do not show the ad again.
            if (isShowingAd) {
                android.util.Log.d(LOG_TAG, &quot;The app open ad is already showing.&quot;);
                return;
            }

            // If the app open ad is not available yet, invoke the callback then load the ad.
            if (!isAdAvailable()) {
                android.util.Log.d(LOG_TAG, &quot;The app open ad is not ready yet.&quot;);
                onShowAdCompleteListener.onShowAdComplete();
                loadAd(activity);
                return;
            }

            appOpenAd.setFullScreenContentCallback(
                new FullScreenContentCallback() {

                    @Override
                    public void onAdDismissedFullScreenContent() {
                        // Called when fullscreen content is dismissed.
                        // Set the reference to null so isAdAvailable() returns false.
                        android.util.Log.d(LOG_TAG, &quot;Ad dismissed fullscreen content.&quot;);
                        appOpenAd = null;
                        isShowingAd = false;

                        onShowAdCompleteListener.onShowAdComplete();
                        loadAd(activity);
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        // Called when fullscreen content failed to show.
                        // Set the reference to null so isAdAvailable() returns false.
                        android.util.Log.d(LOG_TAG, adError.getMessage());
                        appOpenAd = null;
                        isShowingAd = false;

                        onShowAdCompleteListener.onShowAdComplete();
                        loadAd(activity);
                    }

                    @Override
                    public void onAdShowedFullScreenContent() {
                        // Called when fullscreen content is shown.
                        android.util.Log.d(LOG_TAG, &quot;Ad showed fullscreen content.&quot;);
                    }
            });
            isShowingAd = true;
            appOpenAd.show(activity);
        }
    }
}
