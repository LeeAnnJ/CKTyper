public void hideKeyboard(){
    View view = this.getActivity().getCurrentFocus();
    if (view != null){
        InputMethodManager imm = (InputMethodManager)((this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE)));
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

    }

    ShowProgressDialog(getResources().getString(R.string.saving_design));
    new SaveTemplateTask().execute();
}
public boolean hideKeyboard() {
    View view = this.getActivity().getCurrentFocus();
    if (view != null) {
        InputMethodManager imm = (InputMethodManager) ((this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE)));
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    return true;
}
    if (hideKeyboard()) {
        ShowProgressDialog(getResources().getString(R.string.saving_design));
        new SaveTemplateTask().execute();
    }
