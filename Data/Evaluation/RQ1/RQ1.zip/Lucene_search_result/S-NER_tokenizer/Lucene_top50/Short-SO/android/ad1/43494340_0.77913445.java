public class KeyboardUtils {

    private static final KeyboardUtils instance = new KeyboardUtils();

    private KeyboardUtils() {}

    public static KeyboardUtils getInstance() {
        return instance;
    }

    public void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    public void focusEt(final EditText et) {
        et.setOnFocusChangeListener((view, hasFocus) -&gt; {
            if (!hasFocus) {
                hideKeyboard(view);
            }
        });
    }
}
public class KeyboardUtils {

    public static void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }

    public static void focusEt(final EditText et) {
        et.setOnFocusChangeListener((view, hasFocus) -&gt; {
            if (!hasFocus) {
                hideKeyboard(view);
            }
        });
    }
}
