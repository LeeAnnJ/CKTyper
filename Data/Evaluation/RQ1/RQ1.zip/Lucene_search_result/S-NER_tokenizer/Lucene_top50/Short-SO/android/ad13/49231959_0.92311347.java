public class PhotoPagerAdapter extends PagerAdapter {

private ImageView imageView;
private Context context;
private LayoutInflater inflater;
private ArrayList&lt;String&gt; listOfAllImages = new ArrayList&lt;&gt;();
private ArrayList&lt;Bitmap&gt; listOfAllBitmap = new ArrayList&lt;&gt;();

public PhotoPagerAdapter(Context context) {
    this.context = context;
    getAllShownImagesPath();
}

@Override
public int getCount() {
    return listOfAllImages.size();
}

@Override
public boolean isViewFromObject(View view, Object object) {
    return view == object;
}

@Override
public Object instantiateItem(ViewGroup container, int position) {
    inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View view = inflater.inflate(R.layout.photopager, null);
    imageView = (ImageView) view.findViewById(R.id.photoView2);


    imageView.setImageBitmap(listOfAllBitmap.get(position));
    imageView.setRotation(90);

    ViewPager viewPager = (ViewPager) container;
    viewPager.addView(view, 0);
    return view;
}

@Override
public void destroyItem(ViewGroup container, int position, Object object) {
    ViewPager vp = (ViewPager) container;
    View view = (View) object;
    vp.removeView(view);
}

private void getAllShownImagesPath() {
    Uri uri;
    Cursor cursor;
    int column_index_data;
    String absolutePathOfImage;
    uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

    String[] projection = {MediaStore.MediaColumns.DATA,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME};

    cursor = context.getContentResolver().query(uri, projection, null,
            null, null);

    column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
    while (cursor.moveToNext()) {
        absolutePathOfImage = cursor.getString(column_index_data);
        listOfAllImages.add(absolutePathOfImage);
        listOfAllBitmap.add(BitmapFactory.decodeFile(absolutePathOfImage));
    }

    cursor.close();
}
}
public class ShowCamera2 extends BaseFragment{

private View mainView;
private ViewPager viewPager;
private PhotoPagerAdapter photoPagerAdapter;
private Button prev, next;
private TextView imageCount;

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    mainView = inflater.inflate(R.layout.camera_fragment, container, false);

    prev = (Button) mainView.findViewById(R.id.prevPhoto2);
    next = (Button) mainView.findViewById(R.id.nextPhoto2);

    viewPager = (ViewPager) mainView.findViewById(R.id.viewPager);
    photoPagerAdapter = new PhotoPagerAdapter(this.getActivity());
    viewPager.setAdapter(photoPagerAdapter);

    prev.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            viewPager.setCurrentItem(viewPager.getCurrentItem() - 1);
        }
    });

    next.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
        }
    });

    return mainView;
}
}
public class PhotoPagerAdapter extends PagerAdapter {

private ImageView imageView;
private Context context;
private LayoutInflater inflater;
private ArrayList&lt;String&gt; listOfAllImages = new ArrayList&lt;&gt;();
private ArrayList&lt;Bitmap&gt; listOfAllBitmap = new ArrayList&lt;&gt;();

public PhotoPagerAdapter(Context context) {
    this.context = context;
    getAllShownImagesPath();
}

@Override
public int getCount() {
    return listOfAllBitmap.size();
}

@Override
public boolean isViewFromObject(View view, Object object) {
    return view == object;
}

@Override
public Object instantiateItem(ViewGroup container, int position) {
    inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View view = inflater.inflate(R.layout.photopager, null);
    imageView = (ImageView) view.findViewById(R.id.photoView2);


    imageView.setImageBitmap(listOfAllBitmap.get(position));
    imageView.setRotation(90);

    ViewPager viewPager = (ViewPager) container;
    viewPager.addView(view, 0);
    return view;
}

@Override
public void destroyItem(ViewGroup container, int position, Object object) {
    ViewPager vp = (ViewPager) container;
    View view = (View) object;
    vp.removeView(view);
}

private void getAllShownImagesPath() {
    Uri uri;
    Cursor cursor;
    int column_index_data;
    String absolutePathOfImage;
    uri = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

    String[] projection = {MediaStore.MediaColumns.DATA,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME};

    cursor = context.getContentResolver().query(uri, projection, null,
            null, null);

    column_index_data = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
    while (cursor.moveToNext()) {
        absolutePathOfImage = cursor.getString(column_index_data);
        //listOfAllImages.add(absolutePathOfImage);
        listOfAllBitmap.add(decodeBitmapURI(context, absolutePathOfImage, 1000, 500));
    }

    cursor.close();
}

public Bitmap decodeBitmapURI(Context context, String uri, int imageWidth, int imageHeight) {

    // First decode with inJustDecodeBounds=true to check dimensions
    final BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    try {
        BitmapFactory.decodeStream(context.getContentResolver().openInputStream(Uri.parse(uri)), null, options);
        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, imageWidth, imageHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeStream(context.getContentResolver().openInputStream(Uri.parse(uri)), null, options);
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    }

    return null;
}

public int calculateInSampleSize(
        BitmapFactory.Options options, int reqWidth, int reqHeight) {
    // Raw height and width of image
    final int height = options.outHeight;
    final int width = options.outWidth;
    int inSampleSize = 1;

    if (height &gt; reqHeight || width &gt; reqWidth) {

        final int halfHeight = height / 2;
        final int halfWidth = width / 2;

        // Calculate the largest inSampleSize value that is a power of 2 and keeps both
        // height and width larger than the requested height and width.
        while ((halfHeight / inSampleSize) &gt;= reqHeight
                &amp;&amp; (halfWidth / inSampleSize) &gt;= reqWidth) {
            inSampleSize *= 2;
        }
    }

    return inSampleSize;
}
}
