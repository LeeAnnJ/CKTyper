public static void changeLocale(Context context, String locale) {
    Resources res = context.getResources();
    Configuration conf = res.getConfiguration();
    conf.locale = new Locale(locale);
    res.updateConfiguration(conf, res.getDisplayMetrics());
}
Class&lt;?&gt; activityManagerNative = Class.forName("android.app.ActivityManagerNative");
Object am = activityManagerNative.getMethod("getDefault").invoke(activityManagerNative);
Object config = am.getClass().getMethod("getConfiguration").invoke(am);
config.getClass().getDeclaredField("locale").set(config, item.getLocale());
config.getClass().getDeclaredField("userSetLocale").setBoolean(config, true);
am.getClass().getMethod("updateConfiguration", android.content.res.Configuration.class).invoke(am, config);
package android.app;

public abstract class ActivityManagerNative implements IActivityManager {

    public static IActivityManager getDefault(){
        return null;
    }

}
package android.app;

import android.content.res.Configuration;
import android.os.RemoteException;

public interface IActivityManager {
    public abstract Configuration getConfiguration () throws RemoteException;
    public abstract void updateConfiguration (Configuration configuration) throws RemoteException;
}
@Override
    public Resources getResources() {
        if(mRes == null)
        mRes = new PowerfulResources(getAssets(),new DisplayMetrics(), null);
        return mRes;
    }

    public static class PowerfulResources extends Resources{

        /**
         * Create a new Resources object on top of an existing set of assets in an
         * AssetManager.
         *
         * @param assets  Previously created AssetManager.
         * @param metrics Current display metrics to consider when
         *                selecting/computing resource values.
         * @param config  Desired device configuration to consider when
         */
        public PowerfulResources(AssetManager assets, DisplayMetrics metrics, Configuration config) {
            super(assets, metrics, config);
        }

        @NonNull
        @Override
        public String getString(int id) throws NotFoundException {
            //do your stuff here
            return super.getString(id);
        }
    }
public abstract class MyLangActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        Locale locale = // get the locale to use...
        Configuration conf = getResources().getConfiguration();
        if (Build.VERSION.SDK_INT &gt;= 17) {
            conf.setLocale(locale);
        } else {
            conf.locale = locale;
        }

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        getResources().updateConfiguration(conf, metrics);
        super.onCreate(savedInstanceState);
    }
}
