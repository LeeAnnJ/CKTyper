private void Finder(String toFind){

    if(searchList == null) {
        searchList = new ArrayList&lt;&gt;();
    }
    searchList.clear();

    if(toFind != null || !toFind.trim().equals("")) {
        for(String str : words) {
            if(str.toLowerCase().contains(toFind.toLowerCase()))
                searchList.add(str);
        }
    }
    notifyDataToListView();
}

private void notifyDataToListView() {
    if(adapter == null) {
        adapter = new BaseAdapter() {
            @Override
            public int getCount() {
                return searchList == null ? 0 : searchList.size();
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                if(convertView == null) {
                    convertView = new TextView(getApplicationContext());
                }
                ((TextView) convertView).setText(searchList.get(position));
                return null;
            }
        };
        myListView.setAdapter(adapter);
    }else {
        adapter.notifyDataSetChanged();
    }
}
