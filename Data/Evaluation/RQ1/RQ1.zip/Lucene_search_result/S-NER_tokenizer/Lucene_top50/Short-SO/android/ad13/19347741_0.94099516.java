public class CustomAdapter extends BaseAdapter {

    private List&lt;ViewHolder&gt; viewHolders;

    @Inject
    public CustomAdapter(@Assisted List&lt;ViewHolder&gt; viewHolders) {
        this.viewHolders = viewHolders;
    }

    @Override
    public int getCount() {
        return viewHolders.size();
    }

    @Override
    public Object getItem(int i) {
        return viewHolders.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return viewHolders.get(i).getView(view);
    }
}
public class ListViewHolder extends ViewHolder {

    @Override
    public View getView(View view) {
        Holder holder;

        if (view == null) {
            view = LayoutInflater.from(contextProvider.get()).inflate(R.layout.entry, null);
            holder = new Holder();

            holder.text = (TextView) view.findViewById(R.id.textView);

            view.setTag(viewStructure);
        } else {
            holder = (Holder) view.getTag();
        }

        holder.text.setText(/* date */);

        return view;
    }
}
public class ListFragment extends RoboFragment {

    private CustomAdapter customAdapter = null;

    private List&lt;ViewHolder&gt; viewHolders = new ArrayList&lt;ViewHolder&gt;();

    private ListView listView;

    private Handler handler = new Handler();

    @Inject
    private ListFragment(AdapterFactory adapterFactory) {
        customAdapter = adapterFactory.createAdapter(viewHolders);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.list, container, false);

        listView = (ListView) view.findViewById(R.id.listView);

        listView.setAdapter(customAdapter);

        return view;
    }

    public void setContentRange(List&lt;ViewHolder&gt; viewHolders, int range) {
        update(viewHolders.subList(0, range));
    }

    private void update(List&lt;ViewHolder&gt; content) {
        viewHolders.clear();
        viewHolders.addAll(content);

        if (customAdapter != null) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    customAdapter.notifyDataSetChanged();
                    //customAdapter.notifyDataSetInvalidated();

                    if (listView != null) {
                        listView.invalidateViews();
                    //    listView.requestLayout();
                    //    listView.refreshDrawableState();
                    }
                }
            });
        }
    }
}
@Inject
private ListViewHolder(Holder holder) { // Guice will create the holder
    super(holder);
}

@Override
public View getView(View view) {
    Holder holder;

    if (view == null) {
        view = LayoutInflater.from(contextProvider.get()).inflate(R.layout.entry, null);
        holder = getHolder(); // getHolder is defined in ViewHolder, and returns the object created in the constructor

        holder.text = (TextView) view.findViewById(R.id.textView1);

        view.setTag(viewStructure);
    } else {
        holder = (DualTextViewStructure) view.getTag();
    }

    holder.text.setText(/* Date */);

    return view;
}
