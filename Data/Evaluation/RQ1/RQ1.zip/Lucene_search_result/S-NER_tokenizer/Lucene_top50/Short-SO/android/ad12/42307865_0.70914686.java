import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Main {
    public static void main(String[]args) {
        File configFile = new File("test.properties");
        System.out.println("Reading config from = " + configFile.getAbsolutePath());

        FileInputStream fis = null;
        Properties properties = new Properties();

        try {
            fis = new FileInputStream(configFile);
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        } finally {
            if(fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {}
            }
        }

        System.out.println("user = " + properties.getProperty("user"));
    }
}
Reading config from = C:\test.properties
user = Flood2d
sourceSets {
    main {
        resources {
            srcDirs = ["src\main\config\com\my_app1"]
            includes = ["**/*.properties"]
        }
    }
 }
myproj/
      /configs
FileInputStream input = new FileInputStream("src/main/.../config.dev.properties");

Properties prop = new Properties()
prop.load(input);
// ....your code
