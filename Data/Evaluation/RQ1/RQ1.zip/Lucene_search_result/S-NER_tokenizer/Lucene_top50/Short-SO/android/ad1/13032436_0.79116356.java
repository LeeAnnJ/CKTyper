InputMethodManager im = (InputMethodManager) getSystemService(MyActivity.INPUT_METHOD_SERVICE);
im.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
     /* Hide Keyboard */
    public static void hideKeyboard(Activity activity){
        InputMethodManager inputMethodManager = (InputMethodManager)activity
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        View focus = activity.getCurrentFocus();
        if(focus != null)
            inputMethodManager.hideSoftInputFromWindow(focus.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }
InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(myEditText.getWindowToken(), 0);
public static ArrayList&lt;View&gt; getAllViewsFromRoots(View...roots) {
    ArrayList&lt;View&gt; result = new ArrayList&lt;View&gt;();
    for (View root : roots) {
        getAllViews(result, root);
    }
    return result;
}

private static void getAllViews(ArrayList&lt;View&gt; allviews, View parent) {
    allviews.add(parent);
    if (parent instanceof ViewGroup) {
        ViewGroup viewGroup = (ViewGroup)parent;
        for (int i = 0; i &lt; viewGroup.getChildCount(); i++) {
            getAllViews(allviews, viewGroup.getChildAt(i));
        }
    }
}
public static EditText getEditText(View root) {
    ArrayList&lt;View&gt; views = getAllViewsFromRoots(root);
    for (View view : views) {
        if (view instanceof EditText &amp;&amp; view.getVisibility() == View.VISIBLE) {
            return (EditText) view;
        }
    }
    return null;
}
open class BaseActivity : AppCompatActivity() {

fun Fragment.hideKeyboard() {
    view?.let { activity?.hideKeyboard(it) }
}

fun Context.hideKeyboard(view: View) {
    val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
    inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
}

}
