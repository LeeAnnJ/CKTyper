&lt;config-file target="AndroidManifest.xml" parent="/manifest/application"&gt;
    &lt;activity android:name="com.example.android.camera2video.MediaCustomActivity" android:label="@string/activity_name" android:theme="@style/Theme.Transparent"&gt;
        &lt;intent-filter&gt;
            &lt;action android:name="android.intent.action.MAIN" /&gt;
            &lt;category android:name="android.intent.category.LAUNCHER" /&gt;
        &lt;/intent-filter&gt;
    &lt;/activity&gt;
&lt;/config-file&gt;
&lt;source-file src="src/android/MediaCustom.java" target-dir="src/com/example/android/camera2video" /&gt;
&lt;source-file src="src/android/MediaCustomActivity.java" target-dir="src/com/example/android/camera2video" /&gt;
&lt;source-file src="src/android/Camera2VideoFragment.java" target-dir="src/com/example/android/camera2video" /&gt;
public void show() {
    if (cameraFragment != null) {
        return;
    }
    cameraFragment = Camera2VideoFragment.newInstance(cordova, callbackContext);
    cordova.getActivity().runOnUiThread(new Runnable() {
         @Override
         public void run() {
            cordova.getActivity().setContentView(resources.getIdentifier("activity_camera", "layout", packageName));
            FragmentManager fragmentManager = cordova.getActivity().getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(resources.getIdentifier("container", "id", packageName), cameraFragment);
            fragmentTransaction.commit();

            MediaCustomActivity.start(cordova.getActivity());
        }
    });
}

public void hide() {
    if (cameraFragment == null) {
        return;
    }
    cordova.getActivity().runOnUiThread(new Runnable() {
        @Override
        public void run() {
            MediaCustomActivity.stop(cordova.getActivity());

            cordova.getActivity().setContentView(getView());
            FragmentManager fragmentManager = cordova.getActivity().getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.remove(cameraFragment);
            fragmentTransaction.commitAllowingStateLoss(); // commit();
            cameraFragment = null;
        }
    });
}
public static void start(Activity activity) {
    Intent intent = new Intent(activity, MediaCustomActivity.class);
    activity.startActivity(intent);
}

public static void stop(Activity activity) {
    // what can we do here?
}

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    super.init();

    Window window = this.getWindow();
    window.setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
}

@Override
public boolean onKeyDown(int keyCode, KeyEvent event) {
    if (keyCode == KeyEvent.KEYCODE_BACK) {
        return false;
    }
    return super.onKeyDown(keyCode, event);
}
