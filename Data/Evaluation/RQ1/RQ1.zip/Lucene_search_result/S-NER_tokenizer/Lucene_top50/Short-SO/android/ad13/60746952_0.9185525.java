import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Timer;

public class GameClock {

    private final Observer observer;
    private final View view;

    public GameClock() {
        view = new View();
        observer = new Observer(view);
        setupTimer();
    }

    private void setupTimer() {
        int fps = 30;
        int delay = Math.round(1000/fps);
        observer.setFps(fps);
        Timer timer = new Timer(delay, observer);
        timer.setInitialDelay(0);
        timer.start();
    }

    public static void main(String[] args) {
        new GameClock();
    }
}

class View {

    private JLabel counter;

    View(){
        createAndShowGui();
    }

    void createAndShowGui(){
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        counter = new JLabel("0", SwingConstants.CENTER);
        f.add(counter);
        f.pack();
        f.setVisible(true);
    }

    void setCounter(int i){
        counter.setText(String.valueOf(i));
    }
}

class Observer implements ActionListener {

    private int timerFrame;
    private int fps;
    private final boolean paused;
    private final View view;

    public Observer(View view) {
        this.view = view;
        paused = false;
        timerFrame = 0;
    }

    @Override
    public void actionPerformed(ActionEvent aEvent) {
        if (! paused) {
            updateAll();
        }
    }

    public int getTimerFrame() {
        return timerFrame;
    }

    public void setFps(int fps) {
        this.fps = fps;
    }

    private void nextTimerFrame() {
        timerFrame = timerFrame &gt;= fps ?    0 : timerFrame + 1;
    }

    public void updateAll() {
        nextTimerFrame();
        view.setCounter(timerFrame);
    }
}
