InputMethodManager im = (InputMethodManager)
                                 getSystemService(Context.INPUT_METHOD_SERVICE);
if(im null){
        im.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
    }
InputMethodManager im = (InputMethodManager)
                                  getSystemService(Context.INPUT_METHOD_SERVICE);
if(im != null){
        im.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY);
    }
&lt;EditText
    android:id="@+id/name"
    android:inputType="text"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"/&gt;
        button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editText.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
                }
            });
    button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideSoftKeyboard(MainActivity.this);
            }
        });


public void hideSoftKeyboard(Activity theActivity) {
        final InputMethodManager inputMethodManager = (InputMethodManager) theActivity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (inputMethodManager.isActive()) {
            if (theActivity.getCurrentFocus() != null) {
                inputMethodManager.hideSoftInputFromWindow(theActivity.getCurrentFocus().getWindowToken(), 0);
            }
        }
}
