 public void onMapReady(MapboxMap mapboxMap) {
                IconFactory iconFactory=IconFactory.getInstance(context);
                for(int i=0;i&lt;coordinates.size();i++){
                    mapboxMap.addMarker(new MarkerOptions()
                    .position(new LatLng(lat,longt))
                    .icon(iconFactory.fromResource(R.drawable.ic_location_green))
                          //can we inflate a view here instead of assigning a drawable image?
                }

            }
  /**
   * Utility class to generate Bitmaps for Symbol.
   * &lt;p&gt;
   * Bitmaps can be added to the map with {@link com.mapbox.mapboxsdk.maps.MapboxMap#addImage(String, Bitmap)}
   * &lt;/p&gt;
   */
  private static class SymbolGenerator {

    /**
     * Generate a Bitmap from an Android SDK View.
     *
     * @param view the View to be drawn to a Bitmap
     * @return the generated bitmap
     */
    public static Bitmap generate(@NonNull View view) {
      int measureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
      view.measure(measureSpec, measureSpec);

      int measuredWidth = view.getMeasuredWidth();
      int measuredHeight = view.getMeasuredHeight();

      view.layout(0, 0, measuredWidth, measuredHeight);
      Bitmap bitmap = Bitmap.createBitmap(measuredWidth, measuredHeight, Bitmap.Config.ARGB_8888);
      bitmap.eraseColor(Color.TRANSPARENT);
      Canvas canvas = new Canvas(bitmap);
      view.draw(canvas);
      return bitmap;
    }
  }
