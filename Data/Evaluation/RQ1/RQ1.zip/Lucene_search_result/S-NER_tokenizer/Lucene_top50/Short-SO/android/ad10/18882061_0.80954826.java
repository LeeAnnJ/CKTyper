Bitmap map = getBitmapFromView(cView);
Canvas canvas = new Canvas(map);
RelativeLayout layout = (RelativeLayout) findViewById(R.id.activity_display);
for (int x=0; x &lt; canvasList.size(); x++) {
    Canvas currCanvas = canvasList.get(x) 
    View view = new View(this);
    view.draw(currCanvas);
    layout.addView(canvasList.get(x));
}
