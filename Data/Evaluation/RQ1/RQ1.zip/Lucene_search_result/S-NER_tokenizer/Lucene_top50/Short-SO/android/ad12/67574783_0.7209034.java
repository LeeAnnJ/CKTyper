@Override
public void onAttach(@NonNull Context context) {
    super.onAttach(LocaleHelper.onAttach(context));
}
private View.OnClickListener updateLanguage() {
    return (View v) -&gt; {
        String code = v.getTag() != null ? v.getTag().toString() : getString(R.string.en_code);

        LocaleHelper.setLocale(getContext(), code);
        navController.navigate(R.id.action_languageFragment_to_instructionFragment);
    };
}
Locale locale = new Locale(language);
Locale.setDefault(locale);

Resources resources = context.getResources();
Configuration config = resources.getConfiguration();
config.setLocale(locale);

return context.createConfigurationContext(config);
