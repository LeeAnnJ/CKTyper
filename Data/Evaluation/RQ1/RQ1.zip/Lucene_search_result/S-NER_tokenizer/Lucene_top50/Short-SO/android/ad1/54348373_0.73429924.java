mEditText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View view, boolean hasFocus) {
            if ( hasFocus )
            {
                hideKeyBoard();
            }
        }
    });
private void hideKeyBoard()
{
    View view = this.getCurrentFocus();
    if (view != null) {
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        if( imm != null )
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
