public class Home extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        final ImageView login_username_btn = (ImageView) findViewById(R.id.login_username_btn);

        login_username_btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Login.class);
                startActivity(intent);
            }
        });
    }

}


public class Login extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        setContentView(R.layout.login);

        final EditText etUsuario = (EditText) findViewById(R.id.txtUsuario);
        final EditText etSenha = (EditText) findViewById(R.id.txtSenha);
        final ImageView ivVoltar = (ImageView) findViewById(R.id.voltarBtn);

        ivVoltar.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(findViewById(android.R.id.content)
                    .getWindowToken(), 0);

                finish();
            }
        });


    @Override
    protected void onPause() {
        super.onPause();

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(findViewById(android.R.id.content)
            .getWindowToken(), 0);
    }
}


And on LogCat shows "GC_EXTERNAL_ALLOC freed" and "GC_EXPLICIT freed" messages.
