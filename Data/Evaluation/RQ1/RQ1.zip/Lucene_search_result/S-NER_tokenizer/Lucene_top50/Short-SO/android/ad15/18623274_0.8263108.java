/*
 * SonarSource :: Web :: Sonar Plugin
 * Copyright (c) 2010-2017 SonarSource SA and Matthijs Galesloot
 * sonarqube@googlegroups.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.sonar.plugins.web.checks.coding;

import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.sonar.check.Rule;
import org.sonar.plugins.web.checks.AbstractPageCheck;
import org.sonar.plugins.web.node.Node;
import org.sonar.plugins.web.node.TagNode;
import org.sonar.plugins.web.node.TextNode;

@Rule(key = "HeadingNotEmptyCheck")
public class HeadingNotEmptyCheck extends AbstractPageCheck {

    private static final String[] headingTagsArray = StringUtils.split("H1,H2,H3,H4,H5,H6", ',');
    private TagNode startHeadingNode;
    private TextNode textNode;

    @Override
    public void startDocument(List&lt;Node&gt; nodes) {
        startHeadingNode = null;
        textNode = null;
    }

    @Override
    public void startElement(TagNode element) {
        if (isHeading(element)) {
            this.startHeadingNode = element;
            this.textNode = null;
        }
    }

    @Override
    public void endElement(TagNode element) {
        if (isHeading(element)) {
            if (startHeadingNode == null || !startHeadingNode.getNodeName().equals(element.getNodeName())) {
                createViolation(element.getStartLinePosition(),
                        "The tag \"" + element.getNodeName() + "\" has no corresponding start tag.");
                this.textNode = null;
                return;
            }
            // found matching start tag for end tag
            startHeadingNode = null;

            if (textNode == null) {
                createViolation(element.getStartLinePosition(),
                        "The tag \"" + element.getNodeName() + "\" heading must not be empty.");
                return;
            }
        }
    }

    @Override
    public void characters(TextNode textNode) {
        if (!textNode.isBlank()) {
            this.textNode = textNode; 
        }
    }

    private boolean isHeading(TagNode node) {
        for (String headingTag : headingTagsArray) {
            if (node.equalsElementName(headingTag)) {
                return true;
            }
        }
        return false;
    }
}
public final class CheckClasses {

  private static final List&lt;Class&gt; CLASSES = ImmutableList.of(
    ...,
    HeadingNotEmptyCheck.class,
    ...
&lt;p&gt;When at least one heading element (marked by &amp;lt;h1&amp;gt; through &amp;lt;h6&amp;gt;) is present, it is a best practice to ensure it contains content.&lt;/p&gt;
&lt;h2&gt;Noncompliant Code Example&lt;/h2&gt;
&lt;pre&gt;
&amp;lt;div&amp;gt;
  &amp;lt;h1&amp;gt;&amp;lt;/h1&amp;gt; &amp;lt;!-- Noncompliant; empty content --&amp;gt;
  &amp;lt;h2&amp;gt;&amp;lt;/h2&amp;gt; &amp;lt;!-- Noncompliant; empty content --&amp;gt;
&amp;lt;/div&amp;gt;
&lt;/pre&gt;
&lt;h2&gt;Compliant Solution&lt;/h2&gt;
&lt;pre&gt;
&amp;lt;div&amp;gt;
  &amp;lt;h1&amp;gt;&amp;lt;/h1&amp;gt;
  &amp;lt;h2&amp;gt;&amp;lt;/h2&amp;gt;
&amp;lt;/div&amp;gt;
&lt;/pre&gt;
{
  "title": "Headings must not be empty ",
  "type": "BUG",
  "status": "ready",
  "remediation": {
    "func": "Constant\/Issue",
    "constantCost": "2min"
  },
  "tags": [
    "accessibility",
    "bug"
  ],
  "defaultSeverity": "Minor"
}
/*
 * SonarSource :: Web :: Sonar Plugin
 * Copyright (c) 2010-2017 SonarSource SA and Matthijs Galesloot
 * sonarqube@googlegroups.com
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.sonar.plugins.web.checks.coding;

import java.io.File;

import org.junit.Rule;
import org.junit.Test;
import org.sonar.plugins.web.checks.CheckMessagesVerifierRule;
import org.sonar.plugins.web.checks.TestHelper;
import org.sonar.plugins.web.visitor.WebSourceCode;

public class HeadingNotEmptyCheckTest {
    @Rule
    public CheckMessagesVerifierRule checkMessagesVerifier = new CheckMessagesVerifierRule();

    @Test
    public void testRule() {
        HeadingNotEmptyCheck check = new HeadingNotEmptyCheck();

        WebSourceCode sourceCode = TestHelper.scan(new File("src/test/resources/checks/HeadingNotEmptyCheck.html"),
                check);

        checkMessagesVerifier.verify(sourceCode.getIssues()).next().atLine(8)
                .withMessage("The tag \"h1\" heading must not be empty.").next().atLine(12)
                .withMessage("The tag \"h2\" heading must not be empty.").next();
    }
}
&lt;!DOCTYPE html&gt;
&lt;html&gt;
&lt;head&gt;
&lt;title&gt;Title of the document&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;!-- invalid empty heading --&gt;
    &lt;h1&gt;&lt;/h1&gt;
    &lt;!-- valid heading --&gt;
    &lt;h1&gt;h1 has content&lt;/h1&gt;
    &lt;!-- invalid empty heading --&gt;
    &lt;h2&gt;&lt;/h2&gt;
    &lt;!-- valid heading --&gt;
    &lt;h2&gt;h2 has content&lt;/h2&gt;
    &lt;!-- invalid nested heading --&gt;
    &lt;h1&gt;h1 has content
        &lt;h2&gt;h2 has content&lt;/h2&gt;
    &lt;/h1&gt;
&lt;/body&gt;
&lt;/html&gt;
