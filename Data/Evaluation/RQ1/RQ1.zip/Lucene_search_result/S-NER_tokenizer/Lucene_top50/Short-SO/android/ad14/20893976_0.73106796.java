&lt;LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
xmlns:tools="http://schemas.android.com/tools"
android:layout_width="match_parent"
android:layout_height="match_parent"
android:orientation="vertical"
tools:context=".MainActivity" &gt;

&lt;LinearLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="horizontal" &gt;

    &lt;Button
        android:id="@+id/btnSetScore"
        android:layout_weight="1"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:text="@string/winning_score" /&gt;

    &lt;Button
        android:id="@+id/btnAddPlayer"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:layout_weight="1"
        android:text="@string/add_player"
        android:textSize="@dimen/activity_horizontal_margin" /&gt;

    &lt;Button
        android:id="@+id/btnSetPenalty"
        android:layout_weight="1"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:text="@string/set_penalty"
        android:textSize="@dimen/activity_horizontal_margin" /&gt;

&lt;/LinearLayout&gt;

&lt;ListView
    android:id="@+id/lvScoreBoard"
    android:layout_width="match_parent"
    android:layout_height="0dp"
    android:layout_weight="10"
    tools:listitem="@layout/row" &gt;

&lt;/ListView&gt;

&lt;LinearLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="horizontal" &gt;

    &lt;Button
        android:id="@+id/btnStatistics"
        android:layout_weight="1"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:text="@string/statistics" /&gt;

    &lt;Button
        android:id="@+id/btnNewGame"
        android:layout_weight="1"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:text="@string/new_game" /&gt;

&lt;/LinearLayout&gt;
&lt;LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="horizontal" &gt;

    &lt;TextView
        android:id="@+id/tvPlayer"
        android:layout_weight="4"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:text="@string/player"
        android:textAppearance="?android:attr/textAppearanceLarge" /&gt;

    &lt;CheckBox
        android:id="@+id/cbFarkle1"
        android:layout_weight="1"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:enabled="false"
        android:focusable="false"
        android:text="" /&gt;

    &lt;CheckBox
        android:id="@+id/cbFarkle2"
        android:layout_weight="1"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:enabled="false"
        android:focusable="false"
        android:text="" /&gt;

    &lt;TextView
        android:id="@+id/tvScore"
        android:layout_weight="2"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:text="@string/player_score"
        android:gravity="right"
        android:textAppearance="?android:attr/textAppearanceLarge" /&gt;

&lt;/LinearLayout&gt;
public class MainActivity extends Activity{

String winningScore = "";
String playerName = "";
String playerScore = "";
String farklePenalty = "";
int penalty;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    // Creates Buttons
    final Button btnSetScore = (Button) findViewById(R.id.btnSetScore);
    Button btnAddPlayer = (Button) findViewById(R.id.btnAddPlayer);
    final Button btnSetPenalty = (Button) findViewById(R.id.btnSetPenalty);
    Button btnStatistics = (Button) findViewById(R.id.btnStatistics);
    Button btnNewGame = (Button) findViewById(R.id.btnNewGame);

    // Creates ListView for player score board
    final ListView lvScoreBoard = (ListView) findViewById(R.id.lvScoreBoard);

    // Sets the game winning score when the Set Score button is pressed.
    btnSetScore.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO:
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Set Winning Score");

            final EditText input = new EditText(MainActivity.this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER);

            builder.setView(input);

            builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    winningScore = input.getText().toString();
                    btnSetScore.setText(winningScore);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
                }
            });

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {    
                    dialog.cancel();        
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
                }

            });

            builder.show();

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        }
    });

    // Adds a new player to the game when Add Player button is pressed.
    btnAddPlayer.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Add Player");

            final EditText input = new EditText(MainActivity.this);
            input.setInputType(InputType.TYPE_CLASS_TEXT);

            builder.setView(input);

            builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    playerName = input.getText().toString();



                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
                }
            });

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {    
                    dialog.cancel();        
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
                }

            });

            builder.show();

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        }
    });

    // Sets the third farkle penalty when Set Penalty button is pressed.
    btnSetPenalty.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Set Farkle Penalty");

            final EditText input = new EditText(MainActivity.this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER);

            builder.setView(input);

            builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    farklePenalty = input.getText().toString();
                    penalty = Integer.parseInt(input.getText().toString());
                    btnSetPenalty.setText(farklePenalty);
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
                }
            });

            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {    
                    dialog.cancel();        
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.toggleSoftInput(InputMethodManager.HIDE_NOT_ALWAYS, 0);
                }

            });

            builder.show();

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        }
    });

    // Changes to statistics activity when Statistics button is pressed.
    btnStatistics.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub

        }

    });

    // Resets all data when New Game button is pressed.
    // This will also have the ability to keep player names, 
    // but erase farkle counts, player scores, penalty, 
    // and winning score.
    btnNewGame.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub

        }
    });
}

@Override
public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.main, menu);
    return true;
}

}
public class GeneralAdapter extends BaseAdapter {

private static final CharSequence Name = null;
private LayoutInflater mInflater = null;
private ArrayList&lt;String&gt; info = null;

public GeneralAdapter( ArrayList&lt;String&gt; info) {
    this.info = info;
}

String name;
String score = "0";
boolean farkle1 = false;
boolean farkle2 = false;

@Override
public int getCount() {
    return info.size();
}

@Override
public Object getItem(int position) {
    return info.get(position);
}

@Override
public long getItemId(int position) {
    return position;
}

@Override
public View getView(int position, View convertView, ViewGroup parent) {
    ViewHolder holder;

    if (convertView == null) {
        convertView = mInflater.inflate(R.layout.row, null);

        holder = new ViewHolder();
        holder.generalTV = (TextView) convertView.findViewById(R.id.tvPlayer);
        holder.generalCB = (CheckBox) convertView.findViewById(R.id.cbFarkle1);
        holder.generalCB2 = (CheckBox) convertView.findViewById(R.id.cbFarkle2);
        holder.generalTV2 = (TextView) convertView.findViewById(R.id.tvScore);

        convertView.setTag(holder);
    } else {
        holder = (ViewHolder) convertView.getTag();
    }

    holder.generalTV.setText(name);
    holder.generalCB.setChecked(farkle1);
    holder.generalCB2.setChecked(farkle2);
    holder.generalTV2.setText(score);

    return null;
}

private class ViewHolder {
    TextView generalTV;
    TextView generalTV2;
    CheckBox generalCB;
    CheckBox generalCB2;
}
