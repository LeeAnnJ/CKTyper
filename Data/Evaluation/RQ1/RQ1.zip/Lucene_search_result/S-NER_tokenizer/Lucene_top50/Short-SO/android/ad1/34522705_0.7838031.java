public static void hideKeyboard(Context ctx) {
        InputMethodManager inputManager = (InputMethodManager) ctx
                .getSystemService(Context.INPUT_METHOD_SERVICE);

        // check if no view has focus:
        View v = ((Activity) ctx).getCurrentFocus();
        if (v == null)
            return;

        inputManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }
getActivity().getWindow().setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
hideKeyboard();

if (hideKeyboard()) {
     ShowProgressDialog(getResources().getString(R.string.saving_design));
     Toast.makeText(getActivity().getApplicationContext(), "Saving design", Toast.LENGTH_LONG).show();
     new SaveTemplateTask().execute();
}
public boolean hideKeyboard() {
    View view = this.getActivity().getCurrentFocus();
    if (view != null) {
        InputMethodManager imm = (InputMethodManager) ((this.getActivity().getSystemService(Context.INPUT_METHOD_SERVICE)));
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        return true;
    }
    return false;
}
