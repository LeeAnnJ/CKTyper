&lt;build&gt;
  &lt;resources&gt;
    &lt;resource&gt;
      &lt;directory&gt;config&lt;/directory&gt;
      &lt;includes&gt;
        &lt;include&gt;**/*&lt;/include&gt;
      &lt;/includes&gt;
    &lt;/resource&gt;
  &lt;/resources&gt;
&lt;/build&gt;
Properties config = null;
// try load config file from pre-defined location, first attempt
config = read("config/config.xml");
// if nothing is here, load config file from classpath, default.
if (config == null)
  config = read("src/main/resources/config.xml");
