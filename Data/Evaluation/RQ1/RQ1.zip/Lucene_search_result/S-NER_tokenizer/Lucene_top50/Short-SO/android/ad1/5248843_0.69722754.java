    InputMethodManager imm = (InputMethodManager) Main.mainClassInstance
.getSystemService(Main.mainClassInstance.INPUT_METHOD_SERVICE);

   imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
public void showKeyboard(View v) {
    InputMethodManager imm = (InputMethodManager) Main.mainClassInstance
            .getSystemService(Main.mainClassInstance.INPUT_METHOD_SERVICE);
    imm.showSoftInput(v, imm.SHOW_IMPLICIT);
}
