public class Classes extends Activity {

ImageView imageViewNewClass;
ListView mListView;
String[] stg1;
List&lt;String[]&gt; names2 = null;
DataManipulatorClass dataManipulator;
CustomAdapter customAdapter;
public Classes classes = null;

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.classes);

    imageViewNewClass = (ImageView) findViewById(R.id.newclass);
    mListView = (ListView) findViewById(R.id.displaydata);

    Resources res =getResources();
    classes = this;
    customAdapter=new CustomAdapter( classes, stg1,res );
    mListView.setAdapter( customAdapter );

    imageViewNewClass.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            Intent intent = new Intent(Classes.this, Class_Create.class);
            startActivity(intent);
        }
    });

    mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView&lt;?&gt; parent, View item,
                int position, long id) {
            Toast.makeText(getApplicationContext(),
                    "Listview item clicked", Toast.LENGTH_LONG).show();
        }
    });

    dataManipulator = new DataManipulatorClass(this);
    names2 = dataManipulator.selectAll();

    stg1 = new String[names2.size()];
    int x = 0;
    String stg;

    for (String[] name : names2) {
        stg = "Class Name : " + name[1];
        stg1[x] = stg;
        x++;
    }

    ArrayAdapter&lt;String&gt; adapter = new ArrayAdapter&lt;String&gt;(this,
            android.R.layout.simple_list_item_1, stg1);

    mListView.setAdapter(new ArrayAdapter&lt;String&gt;(this, R.layout.check,
            stg1));
    mListView.setAdapter(adapter);
    adapter.notifyDataSetChanged();
}
}
public class CustomAdapter extends BaseAdapter {

/*********** Declare Used Variables *********/
private Activity activity;
private String[] data;
private static LayoutInflater inflater = null;
public Resources res;
int i = 0;

/************* CustomAdapter Constructor *****************/
public CustomAdapter(Activity a, String[] stg1, Resources resLocal) {

    /********** Take passed values **********/
    activity = a;
    data = stg1;
    res = resLocal;

    /*********** Layout inflator to call external xml layout () ***********/
    inflater = (LayoutInflater) activity
            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

}

/******** What is the size of Passed Arraylist Size ************/
public int getCount() {
    if (data.length &lt;= 0)
        return 1;
    return data.length;
}

public Object getItem(int position) {
    return position;
}

public long getItemId(int position) {
    return position;
}

public static class ViewHolder {
    public CheckBox checkBox;
}

public View getView(int position, View convertView, ViewGroup parent) {

    View vi = convertView;
    ViewHolder holder;

    if (convertView == null) {
        vi = inflater.inflate(R.layout.check, null);
        holder = new ViewHolder();
        holder.checkBox = (CheckBox) vi.findViewById(R.id.checkBox1);
        vi.setTag(holder);
    } else
        holder = (ViewHolder) vi.getTag();
    return vi;
}
public void onClick(View v) {
    Log.v("CustomAdapter", "=====Row button clicked=====");
}
}
