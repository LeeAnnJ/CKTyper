 @POST
    @Path("/dispatch")
    public Response dispatchEvent(){
     Thread steps = new Thread(new HandlerExecutor());
            steps.start();
    }
public class HandlerExecutor implements Runnable {
    @Override
    public void run() {
        Handler first = HandlerLocator.getHandler();
        if (first != null) {
            first.process();
        }
    }
} 
public class HandlerLocator {
    public static Map&lt;String, List&lt;Handler&gt;&gt; allHandlers = null;        
    public static Handler getHandler() {    
        Handler first = null;           
        List&lt;Handler&gt;&gt; h = new HashMap&lt;String, List&lt;Handler&gt;&gt;();
            List&lt;Handler&gt; list = new ArrayList&lt;Handler&gt;();
            list.add(new ConsoleHandler());
            list.add(new FileHandler());
            list.add(new FinalHandler());
            h.put("1", list);
        List&lt;Handler&gt; clientHandlers = h.get("1");          
        if (clientHandlers != null) {
            int size = clientHandlers.size();
                Handler h1, prev = null;

                for (int i = 0; i &lt; size; i++) {
                    h1 = (Handler) clientHandlers.get(i);

                    if (first == null) {
                        first = h1;
                    } else {
                        prev.setNext(h1);
                    }
                    prev = h1;
                }
        }
        return first;
    }
}
public interface Handler extends Serializable {
    Handler setNext(Handler next);
    void process();
}
public abstract class BasicHandler implements Handler {
    private Handler next;
    public BasicHandler() {
        this.next = null;
    }

    @Override
    public Handler setNext(Handler next) {
        this.next = next;
        return next;
    }

    @Override
    public void process()  {    
        doProcess();
        if (next != null) {
            next.process();
        } else {
            // done
        }
    }

    public abstract void doProcess() ;
}


public class ConsoleHandler extends BasicHandler {
    @Override
    public void doProcess()   {
        System.out.println("processed ConsoleHandler");
    }
}
