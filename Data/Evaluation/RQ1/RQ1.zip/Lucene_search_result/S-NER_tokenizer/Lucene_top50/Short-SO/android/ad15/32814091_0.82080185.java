import java.util.Scanner;

public class HeadPhone {

//Three constants to denote headphone volume
public static final int LOW = 1;
public static final int MEDIUM = 2;
public static final int HIGH = 3;

//Private variables 
private static int volume;
private boolean pluggedIn;
private String manufacturer;
private String headPhoneColor;

//This constructs the default headphone object
HeadPhone(){
   volume = MEDIUM;
   pluggedIn = false;
   manufacturer = "DEFAULT";
   headPhoneColor = "DEFAULT";
   }

   public void setVolume(int v){
   if(v &lt; LOW){
       volume = LOW;
   }
   else if(v &gt; HIGH){
       volume = HIGH;
   }
   else{
       volume = v;  
   }
}

public void setPluggedIn(boolean p){
   pluggedIn = p;
}

public void setManufacturer(String m){
   manufacturer = m;
}

public void setColor(String C){
   headPhoneColor = C;
}

public int getVolume(){
   return volume;
}

public boolean getPluggedIn(){
   return this.pluggedIn;
}

public String getManufacturer(){
   return this.manufacturer;
}

public String getColor(){
   return this.headPhoneColor;
}

public void changeVolume(int volume){
   setVolume(volume);
}

public String toString(){
   String temp = "Volume: " + volume + "\nPlugged In: " + pluggedIn +
           "\nManufacturer: " + manufacturer + "\nColor: " + headPhoneColor + "\n";
   return temp;
}

public static void main(String args[]){
   String volMessage = "What volume would you like to set? 1 for LOW, 2 for MEDIUM, or 3 for HIGH. ";          

   //Creates the object h1 and displays its statistics
   HeadPhone h1 = new HeadPhone();
   h1.setVolume(LOW);
   h1.setManufacturer("Logitech");
   h1.setColor("Black");
   h1.setPluggedIn(true);
   h1.changeVolume(MEDIUM);
   System.out.println("Headphone Set #1\n" + h1);

   //Creates the object h2 and displays its statistics
   HeadPhone h2 = new HeadPhone();
   h2.setVolume(LOW);
   h2.setManufacturer("Steel Series");
   h2.setColor("Silver");
   h2.setPluggedIn(true);
   h2.changeVolume(HIGH);
   System.out.println("Headphone Set #2\n" + h2);

   //Creates the object h3 and displays its statistics
   HeadPhone h3 = new HeadPhone();
   h3.setVolume(LOW);
   h3.setManufacturer("Panasonic");
   h3.setColor("Red");
   h3.setPluggedIn(true);
   h3.changeVolume(LOW);
   System.out.println("Headphone Set #3\n" + h3);

   Scanner input = new Scanner(System.in);

   //This logic allows the user to either select to change the volume on their headphones or not
   System.out.print("\n\nWould you like to change the volume on your headphones? Y or N? ");
   String choice = input.nextLine();
   if (choice.equals("Y") || choice.equals("y")){
       System.out.print("\nWhich headphone set would you like to change the volume of? 1, 2, or 3? ");
       int hpSelect = input.nextInt();


       //This switch statement allows the user to change the volume of their selected headphone set
       switch(hpSelect){
            case 1:
                System.out.print(volMessage);
                int volSelect = input.nextInt();
                if (volSelect == 1){
                    h1.changeVolume(LOW);
                    System.out.println("\n" + h1);
                    break;
                }      

            case 2:
                System.out.print(volMessage);
                volSelect = input.nextInt();
                if (volSelect == 2){
                    h1.changeVolume(MEDIUM);
                    System.out.println("\n" + h2);
                    break;
                } 

            case 3:
                System.out.print(volMessage);
                volSelect = input.nextInt();
                if (volSelect == 3){
                    h1.changeVolume(HIGH);
                    System.out.println("\n" + h3);
                    break;
                }

            default:
                System.out.println("Invalid entry.");
                break;



       }//End switch statement

       input.close();
   }//End if statement

   else{
        System.out.println("Okay! Enjoy your music!");
   }
switch(hpSelect){
        case 1:
            System.out.print(volMessage);
            int volSelect = input.nextInt();
            if (volSelect == 1){
                h1.changeVolume(LOW);
                System.out.println("\n" + h1);   
            }; break;    

        case 2:
            System.out.print(volMessage);
            volSelect = input.nextInt();
            if (volSelect == 2){
                h1.changeVolume(MEDIUM);
                System.out.println("\n" + h2);
            }; break;

        case 3:
            System.out.print(volMessage);
            volSelect = input.nextInt();
            if (volSelect == 3){
                h1.changeVolume(HIGH);
                System.out.println("\n" + h3);
            }; break;

        default:
            System.out.println("Invalid entry.");
            break;



   }//End switch statement
Which headphone set would you like to change the volume of? 1, 2, or 3? 1
What volume would you like to set? 1 for LOW, 2 for MEDIUM, or 3 for HIGH. 1

Volume: 1
Plugged In: true
Manufacturer: Logitech
Color: Black
    case 3:
        System.out.print(volMessage);
        volSelect = input.nextInt();
        if (volSelect == 3){
            h1.changeVolume(HIGH);
            System.out.println("\n" + h3);

        }
    break;
