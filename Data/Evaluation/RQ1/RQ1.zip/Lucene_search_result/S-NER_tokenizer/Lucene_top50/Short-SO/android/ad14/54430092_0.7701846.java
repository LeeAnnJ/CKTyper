public class MainPresentationFragment extends PresentationFragment {
private EditText textView3;

public MainPresentationFragment() {}

public static MainPresentationFragment newInstance(Context context, Display display){
    MainPresentationFragment mainPresentationFragment = new MainPresentationFragment();
    mainPresentationFragment.setDisplay(context, display);
    return mainPresentationFragment;
}

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
                         Bundle savedInstanceState) {
    textView3 = rootView.findViewById(R.id.editText3);
    textView3.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
        textView3.requestFocus();
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, InputMethodManager.SHOW_FORCED);
    }
return rootView;
}
