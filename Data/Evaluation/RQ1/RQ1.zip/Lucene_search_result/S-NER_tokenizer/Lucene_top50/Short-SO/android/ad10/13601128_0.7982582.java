new Thread() {
    @Override
    public void run() {                     
        // Get root view
        View view = mapView.getRootView();
        view.setDrawingCacheEnabled(true);

        // Create the bitmap to use to draw the screenshot
        final Bitmap bitmap = Bitmap.createBitmap(
                getWindowManager().getDefaultDisplay().getWidth(), getWindowManager().getDefaultDisplay().getHeight(), Bitmap.Config.ARGB_4444);
        final Canvas canvas = new Canvas(bitmap);

        // Get current theme to know which background to use
        final Theme theme = activity.getTheme();
        final TypedArray ta = theme
            .obtainStyledAttributes(new int[] { android.R.attr.windowBackground });
        final int res = ta.getResourceId(0, 0);
        final Drawable background = activity.getResources().getDrawable(res);

        // Draw background
        background.draw(canvas);

        // Draw views
        view.draw(canvas);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();  
        bitmap.compress(Bitmap.CompressFormat.PNG, 90, baos); //bm is the bitmap object   
        byte[] b = baos.toByteArray();  

        Bundle params = new Bundle();
        params.putByteArray("source", b);
        params.putString("message", "genie in a bottle");
        try {
            //String resp =
                    facebook.request("me/photos", params, "POST");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}.start();
