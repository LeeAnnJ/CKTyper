public void setName(String name) {
            String old = this.name;
            this.name = name;

            spcs.firePropertyChange("name", old, name);
        }
@Override
        public void propertyChange(PropertyChangeEvent evt) {
            String propName = evt.getPropertyName();
            Object newVal = evt.getNewValue();

            if("name".equalsIgnoreCase(propName)){
                view.getLblTest().setText((String)newVal);
            }
        }
public class Model {
    private SwingPropertyChangeSupport spcs;

    private String name;

    public Model(){
        spcs = new SwingPropertyChangeSupport(this);
    }

    public void addPropertyChangeListener(PropertyChangeListener listener){
        spcs.addPropertyChangeListener(listener);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        String old = this.name;
        this.name = name;

        spcs.firePropertyChange("name", old, name);
    }
}
public class View {
    private JFrame frame;
    private JPanel panel;
    private JLabel lblTest;
    private JButton btnClickMe;

    public View() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                initialize();
                frame.setVisible(true);
            }
        });
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout(0, 0));
        frame.getContentPane().add(getPanel(), BorderLayout.CENTER);
    }
    public JPanel getPanel() {
        if (panel == null) {
            panel = new JPanel();
            panel.setLayout(new MigLayout("", "[][][][][][][][][]", "[][][]"));
            panel.add(getBtnClickMe(), "cell 6 2");
            panel.add(getLblTest(), "cell 8 2");
        }
        return panel;
    }
    public JLabel getLblTest() {
        if (lblTest == null) {
            lblTest = new JLabel("Test");
        }
        return lblTest;
    }
    public JButton getBtnClickMe() {
        if (btnClickMe == null) {
            btnClickMe = new JButton("Click me");
        }
        return btnClickMe;
    }
}
public class Controller implements PropertyChangeListener{
    private Model model;
    private View view;

    public Controller(Model model, View view){
        this.model = model;
        this.view = view;

        this.model.addPropertyChangeListener(this);

        setUpViewEvents();
    }

    private void setUpViewEvents(){
        view.getBtnClickMe().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.setName("John Smith");
            }
        });
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        String propName = evt.getPropertyName();
        Object newVal = evt.getNewValue();

        if("name".equalsIgnoreCase(propName)){
            view.getLblTest().setText((String)newVal);
        }
    }
}
public class Main {
    public static void main(String[] args) {
        Model model = new Model();
        View view = new View();

        Controller controller = new Controller(model, view);
    }
}
