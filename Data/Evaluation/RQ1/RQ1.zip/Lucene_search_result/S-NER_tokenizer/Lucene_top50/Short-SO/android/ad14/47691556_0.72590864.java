        public static void hideKeyboard(EditText edt) {
            InputMethodManager imm = (InputMethodManager) 
                 edt.getContext().getSystemService(Activity.INPUT_METHOD_SERVICE);              
            imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
        }
           dialogBox.setOnDismissListener(new DialogInterface.OnDismissListener() {
        @Override
        public void onDismiss(DialogInterface dialogInterface) {
                   hideKeyBoard(editText);
            dialogBox.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        }
    });
