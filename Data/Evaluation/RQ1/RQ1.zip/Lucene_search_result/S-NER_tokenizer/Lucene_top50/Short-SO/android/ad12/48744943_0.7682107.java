public class LaunchLogin extends ExecutionerClass {
public static WiniumDriver driver = null;
public static ApplicationPropertiesInitializer applicationProperties = null;
static Properties object,browserLoad = null;
static WebDriverWait wait;
public DesktopOptions options;
public String APP_PATH = "C:\\Windows\\System32\\notepad.exe";
public String WINIUM_PATH = "http://localhost:9999";

public LaunchLogin() {
    if(driver == null)
    {

        applicationProperties = new ApplicationPropertiesInitializer();

        String objectFileName = "src/test/resources/config/object.properties";
        object = loadPropertiesFile(objectFileName);
    }
}
public class LaunchLoginWeb extends ExecutionerClass {
public static WebDriver driver = null;
public static ApplicationPropertiesInitializer applicationProperties = null;
static Properties object,browserLoad = null;
public static WebDriverWait wait;

public LaunchLoginWeb() {
    if(driver == null)
    {
        applicationProperties = new ApplicationPropertiesInitializer();
        initilizeBrowser(applicationProperties.getApplicationPropertiesObject().getProperty("browser"));

        String objectFileName = "src/test/resources/config/object.properties";
        object = loadPropertiesFile(objectFileName);
    }
}
