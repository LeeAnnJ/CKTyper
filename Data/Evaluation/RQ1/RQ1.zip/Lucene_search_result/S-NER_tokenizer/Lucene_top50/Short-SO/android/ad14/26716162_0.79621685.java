public static void hideSoftKeyboard(Context context){
    InputMethodManager inputMethodManager = (InputMethodManager) context
            .getSystemService(Activity.INPUT_METHOD_SERVICE);
    inputMethodManager.hideSoftInputFromWindow(context.getCurrentFocus()
            .getWindowToken(), 0);
}
EditText myEditText = (EditText) findViewById(R.id.myEditText);  
InputMethodManager imm = (InputMethodManager)getSystemService(
      Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(myEditText.getWindowToken(), 0);
EditText myEditText = (EditText) findViewById(R.id.myEditText); 
myEditText.setOnEditorActionListener(onEditorActionListener);

protected OnEditorActionListener onEditorActionListener = new OnEditorActionListener() {
    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            resetTimeout();
            InputMethodManager imm = (InputMethodManager)this.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
            v.clearFocus();
        }

        return false;
    }
};
