  protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText.setFocusable(false);

            findViewById(R.id.layout).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

            editText.setInputType(InputType.TYPE_NULL);

            View view = this.getCurrentFocus();
                if (view != null) {

                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                assert imm != null;
                imm.hideSoftInputFromWindow(view.getWindowToken(), 0);

                }
            }
        });
}
