public class MainActivity extends ListActivity {
    private PackageManager packageManager = null;
    private List&lt;ApplicationInfo&gt; applist = null;
    private ApplicationAdapter listadaptor = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        packageManager = getPackageManager();
        new LoadApplications().execute();
    }

    private List&lt;ApplicationInfo&gt; checkForLaunchIntent(List&lt;ApplicationInfo&gt; list) {
        ArrayList&lt;ApplicationInfo&gt; applist = new ArrayList&lt;ApplicationInfo&gt;();
        for (ApplicationInfo info : list) {
            try {
                if (null != packageManager.getLaunchIntentForPackage(info.packageName)) {
                    applist.add((ApplicationInfo) info);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return applist;
    }
    private class LoadApplications extends AsyncTask&lt;Void, Void, Void&gt; {
        private ProgressDialog progress = null;
        @Override
        protected Void doInBackground(Void... params) {
            applist = checkForLaunchIntent(packageManager.getInstalledApplications(PackageManager.GET_META_DATA));
            listadaptor = new ApplicationAdapter(MainActivity.this, R.layout.row, applist);
            return null;
        }
        @Override
        protected void onCancelled() {
            super.onCancelled();
        }

        @Override
        protected void onPostExecute(Void result) {
            setListAdapter(listadaptor);
            progress.dismiss();
            super.onPostExecute(result);
        }

        @Override
        protected void onPreExecute() {
            progress = ProgressDialog.show(MainActivity.this, null,
                    &quot;Loading application info...&quot;);
            super.onPreExecute();
        }
        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
    }
}
public class ApplicationAdapter extends ArrayAdapter&lt;ApplicationInfo&gt; {

    private List&lt;ApplicationInfo&gt; appsList = null;
    private Context context;
    private PackageManager packageManager;
    private ArrayList&lt;Boolean&gt; checkList = new ArrayList&lt;Boolean&gt;();

    public ApplicationAdapter(Context context, int textViewResourceId, List&lt;ApplicationInfo&gt; appsList) {
        super(context, textViewResourceId, appsList);
        this.context = context;

        this.appsList = appsList;
        packageManager = context.getPackageManager();
            checkList.add(false);
        }


    @Override
    public int getCount() {
        return ((null != appsList) ? appsList.size() : 0);
    }

    @Override
    public ApplicationInfo getItem(int position) {
        return ((null != appsList) ? appsList.get(position) : null);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (null == view) {
            LayoutInflater layoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = layoutInflater.inflate(R.layout.row, null);
        }

        ApplicationInfo data = appsList.get(position);
        if (null != data) {
            TextView appName = (TextView) view.findViewById(R.id.app_name);
            appName.setText(data.loadLabel(packageManager));
        }
        return view;
    }
