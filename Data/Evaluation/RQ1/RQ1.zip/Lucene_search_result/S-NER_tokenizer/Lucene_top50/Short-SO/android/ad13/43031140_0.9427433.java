java.lang.IllegalArgumentException: itemView may not be null
             at android.support.v7.widget.RecyclerView$ViewHolder.&lt;init&gt;(RecyclerView.java:10314)
             at br.com.ufrn.marceloaugusto.tasklist.adapter.ProdutoAdapter$ProdutosViewHolder.&lt;init&gt;(ProdutoAdapter.java:0)
             at br.com.ufrn.marceloaugusto.tasklist.MainActivity.onOptionsItemSelected(MainActivity.java:93)
public class MainActivity extends BaseActivity {

    //private SQLiteDatabase banco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUpToolbar();

        if (savedInstanceState == null) {
            FragmentProdutos frag = new FragmentProdutos();
            getSupportFragmentManager().beginTransaction().add(R.id.container, frag).commit();
        }

        //FAB
        findViewById(R.id.fab).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                snack(view, "Adicionar produto");
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_desmarkAll) {
            RecyclerView recycler = (RecyclerView) findViewById(R.id.recyclerView);
            ProdutoAdapter.ProdutosViewHolder holder = null;
            int id = 0;
            for (int i = 0; i &lt; recycler.getAdapter().getItemCount(); i++) {
                holder = new ProdutoAdapter.ProdutosViewHolder(recycler.getChildAt(i)); **//Line 93**
                if (holder.checkBox.isChecked()) {
                    holder.checkBox.setChecked(false);
                }
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }} 
public class ProdutoAdapter extends RecyclerView.Adapter&lt;ProdutoAdapter.ProdutosViewHolder&gt; {
private final Context context;
private final List&lt;Produto&gt; produtos;
//Interface para expor os eventos de toque na lista
private ProdutoOnClickListener produtoOnClickListener;
private ProdutoOnCheckListener produtoOnCheckListener;

public ProdutoAdapter(Context context, List&lt;Produto&gt; produtos, ProdutoOnClickListener produtoOnClickListener, ProdutoOnCheckListener produtoOnCheckListener) {
    this.context = context;
    this.produtos = produtos;
    this.produtoOnClickListener = produtoOnClickListener;
    this.produtoOnCheckListener = produtoOnCheckListener;
}

@Override
public int getItemCount() {
    return this.produtos != null ? this.produtos.size() : 0;
}

@Override
public ProdutosViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(context).inflate(R.layout.adapter_produto, parent, false);
    ProdutosViewHolder holder = new ProdutosViewHolder(view);
    return holder;
}

@Override
public void onBindViewHolder(final ProdutosViewHolder holder, final int position) {
    Produto p = produtos.get(position);
    holder.tNome.setText(p.getNome());
    //holder.tPreco.setText(String.valueOf(p.getPreco()));
    if (produtoOnClickListener != null) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                produtoOnClickListener.onClickProduto(view, position);
            }
        });
    }
    if (produtoOnCheckListener != null) {
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                produtoOnCheckListener.onCheckProduto(view, position);
            }
        });
    }
}

public interface ProdutoOnClickListener {
    public void onClickProduto(View view, int idx);
}

public interface ProdutoOnCheckListener {
    public void onCheckProduto(View view, int position);
}

public static class ProdutosViewHolder extends RecyclerView.ViewHolder {
    public TextView tNome;
    //public TextView tPreco;
    CardView cardView;
    public CheckBox checkBox;
    public ProdutosViewHolder(View view) {
        super(view);
        tNome = (TextView) view.findViewById(R.id.nomeProduto);
        //tPreco = (TextView) view.findViewById(R.id.precoProduto);
        cardView = (CardView) view.findViewById(R.id.card_view);
        checkBox = (CheckBox) view.findViewById(R.id.checkProduto);
    }
}
