 InputMethodManager imm = (InputMethodManager)
                                 getSystemService(Context.INPUT_METHOD_SERVICE);
if(imm != null){
        imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
    }
 InputMethodManager imm = (InputMethodManager)
                                  getSystemService(Context.INPUT_METHOD_SERVICE);
if(imm != null){
        imm.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY);
    }
    InputMethodManager myKeyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    myKeyboard.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
