/**
 * Toggle keyboard If the keyboard is visible,then hidden it,if it's
 * invisible,then show it
 * 
 * @param context
 */
public static void toggleKeyboard(Context context) {
    InputMethodManager imm = (InputMethodManager) context
            .getSystemService(Context.INPUT_METHOD_SERVICE);
    if (imm.isActive()) {
        imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT,
                InputMethodManager.HIDE_NOT_ALWAYS);
    }
}

/**
 * Hide keyboard
 * 
 * @param context
 */
public static void hideKeyboard(Context context,IBinder token) {
    InputMethodManager imm = (InputMethodManager) context
            .getSystemService(Context.INPUT_METHOD_SERVICE);
    if(imm.isActive()){
        imm.hideSoftInputFromWindow(token,0);
    }
}
