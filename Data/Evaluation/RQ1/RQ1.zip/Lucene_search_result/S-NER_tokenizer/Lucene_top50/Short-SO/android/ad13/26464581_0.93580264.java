private void handleFetchvideoListTask(List&lt;VideoObject&gt; videoObjects){
        LinearLayout videoListProgressBarContainer = (LinearLayout)mActivity.findViewById(R.id.videoListProgressBarContainer);
        LinearLayout videoListViewContainer = (LinearLayout)mActivity.findViewById(R.id.videoListViewContainer);

        videoListProgressBarContainer.setVisibility(View.GONE);
        videoListViewContainer.setVisibility(View.VISIBLE);

        ListView listView = (ListView)videoListViewContainer.findViewById(R.id.videoListView);
        VideoListAdapter adapter = new VideoListAdapter((LayoutInflater) mActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE));
        adapter.setList(videoObjects);
        listView.setAdapter(adapter);
        DownloadThumbnailsTask task = new DownloadThumbnailsTask(videoObjects, adapter);
        task.execute();
    }
public class DownloadThumbnailsTask extends AsyncTask&lt;List&lt;VideoObject&gt;, VideoObject, Void&gt;{

        private List&lt;VideoObject&gt; videoObjectList = null;
        private List&lt;VideoObject&gt; toProcess = null;
        private VideoListAdapter adapter = null;

        public DownloadThumbnailsTask(List&lt;VideoObject&gt; videoObjectList, VideoListAdapter adapter){
            this.videoObjectList = videoObjectList;
            this.toProcess = new ArrayList&lt;VideoObject&gt;(videoObjectList);
            this.adapter = adapter;
        }

        @Override
        protected Void doInBackground(List&lt;VideoObject&gt;... lists) {

            for(int i=0; i&lt;toProcess.size(); i++){
                VideoObject item = videoObjectList.get(i);
                String urldisplay = item.getThumbnailUrl();
                Bitmap mIcon11 = null;
                try {
                    InputStream in = new java.net.URL(urldisplay).openStream();
                    mIcon11 = BitmapFactory.decodeStream(in);
                } catch (Exception e) {
                    Log.e("Error", e.getMessage());
                    e.printStackTrace();
                }
                item.setThumbnail(mIcon11);
                mIcon11 = null;
                publishProgress(item);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(VideoObject... values) {
            if(values != null &amp;&amp; values.length &gt; 0){
                VideoObject item = values[0];
                videoObjectList.remove(item);
                videoObjectList.add(item);
                adapter.setList(videoObjectList);
                adapter.notifyDataSetChanged();
            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            this.toProcess.clear();
            this.toProcess = null;
        }
    }
public class VideoListAdapter extends BaseAdapter {

    private List&lt;VideoObject&gt; list;
    private LayoutInflater layoutInflater;

    public VideoListAdapter(LayoutInflater layoutInflater){
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int i) {
        return list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return list.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if(view == null){
            view = layoutInflater.inflate(R.layout.list_item_video, viewGroup, false);
        }
        ViewHolder viewHolder = new ViewHolder(view);
        view.setTag(viewHolder);
        VideoObject item = getVideoObjectItem(i);
        viewHolder.duration.setText(item.getFormattedDuration());
        viewHolder.title.setText(item.getName());
        if(item.getThumbnail() != null){
            viewHolder.thumbnail.setImageBitmap(item.getThumbnail());
        }
        return view;
    }

    private VideoObject getVideoObjectItem(int position){
        return (VideoObject) getItem(position);
    }

    public List&lt;VideoObject&gt; getList() {
        return list;
    }

    public void setList(List&lt;VideoObject&gt; list) {
        this.list = list;
    }

    public static class ViewHolder {
        public final ImageView thumbnail;
        public final TextView title;
        public final TextView duration;

        public ViewHolder(View view) {
            this.thumbnail = (ImageView)view.findViewById(R.id.imgVideoThumbnail);
            this.title = (TextView)view.findViewById(R.id.txtVideoName);
            this.duration = (TextView)view.findViewById(R.id.txtVideoDuration);
        }
    }
}
InputStream in = new java.net.URL(urldisplay).openStream();
mIcon11 = BitmapFactory.decodeStream(in);    protected Void doInBackground(List&lt;VideoObject&gt;... lists) {
        for(final int i=0; i&lt;toProcess.size(); i++){
            try {
                new Thread(){
                    @Override
                    public void run() {
                        VideoObject item = videoObjectList.get(i);
                        String urldisplay = item.getThumbnailUrl();
                        Bitmap mIcon11 = null;
                        try {
                            InputStream in = new java.net.URL(urldisplay).openStream();
                            mIcon11 = BitmapFactory.decodeStream(in);
                        } catch (Exception e) {
                            Log.e("Error", e.getMessage());
                            e.printStackTrace();
                        }
                        item.setThumbnail(mIcon11);
                        publishProgress(item);
                    }
                }.start();
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
            }
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(VideoObject... values) {
        adapter.notifyDataSetChanged();
    }
    videoObjectList.remove(item);
    videoObjectList.add(item);
@Override
public View getView(int i, View view, ViewGroup viewGroup) {
    ViewHolder viewHolder;
    if(view == null){
        view = layoutInflater.inflate(R.layout.list_item_video, viewGroup, false);
        viewHolder = new ViewHolder(view);
        view.setTag(viewHolder);
    }else{
        viewHolder = view.getTag();
    }
    VideoObject item = getVideoObjectItem(i);
    viewHolder.duration.setText(item.getFormattedDuration());
    viewHolder.title.setText(item.getName());
    if(item.getThumbnail() != null){
        viewHolder.thumbnail.setImageBitmap(item.getThumbnail());
    }
    return view;
}
