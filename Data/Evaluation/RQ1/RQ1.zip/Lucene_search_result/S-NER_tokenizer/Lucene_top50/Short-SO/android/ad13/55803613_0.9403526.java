public class AppAdapter extends ArrayAdapter&lt;String&gt; {


private List&lt;ActivityManager.RunningServiceInfo&gt; applist =null;
private Context context;
private PackageManager packageManager;
private List&lt;String&gt; applist1 = null;

public AppAdapter(@NonNull Context context, int resource, @NonNull List&lt;String&gt; objects) {
    super(context, resource, objects);

    this.context = context;
    this.applist1 = objects;
    packageManager = context.getPackageManager();
}

@Override
public int getCount() {
    return ((applist1 != null) ? applist1.size() : 0);
}


@Override
public String getItem(int position) {
    return ((applist1 != null) ? applist1.get(position) : null);
}

@Override
public long getItemId(int position) {
    return position;

}

@Override
public View getView(int position, View convertView, ViewGroup parent) {
    View view = convertView;
    if (view == null) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = layoutInflater.inflate(R.layout.list_item, null);
    }

    ActivityManager.RunningServiceInfo data = applist.get(position);
    Log.d("Test", "data is  : " + data);

    if (data != null){
        Log.d("Test", "data is not null : " + data);
        TextView appName = view.findViewById(R.id.applabel);
        TextView packageName = view.findViewById(R.id.pname);
        ImageView iconView = view.findViewById(R.id.appicon);

        ComponentName mComponentName = data.service;
        appName.setText(mComponentName.getClassName());
        packageName.setText(mComponentName.getPackageName());

    } else {
        Log.d("Test", "data is null : " + data);

    }
    return view;
}
}
private class LoadApplications extends AsyncTask&lt;Void, Void, Void&gt;{

    private ProgressDialog progressDialog = null;

    @Override
    protected Void doInBackground(Void... voids) {

         applist1 = runningServices();
        listadapter = new AppAdapter(Taskmanager.this, R.layout.list_item, applist1);
        Log.d("Test", "applist1 is : " + applist1);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {

        listView.setAdapter(listadapter);
        progressDialog.dismiss();
        super.onPostExecute(aVoid);
    }

    @Override
    protected void onPreExecute() {
        progressDialog = ProgressDialog.show(Taskmanager.this, null, "Loading..");
        super.onPreExecute();
    }
}
