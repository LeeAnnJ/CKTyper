public class CartAdapter extends BaseAdapter {
    Context context;
    ArrayList&lt;ProductCount&gt; productCounts;
    private LayoutInflater inflater;
    private ImageButton plusButton;
    private ImageButton minusButton;
    private CheckBox selectToDelete;
    private onDeleteCartItem onDeleteCartItem = null;


    public CartAdapter(Context context, ArrayList&lt;ProductCount&gt; productCounts, onDeleteCartItem selectChangeListener) {
        this.context = context;
        this.productCounts = productCounts;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.onDeleteCartItem = selectChangeListener;
    }
    @Override
    public int getCount() {
        if(productCounts!=null)
            return productCounts.size();
        return 0;
    }
    @Override
    public Object getItem(int position) {
        if(productCounts!=null &amp;&amp; position &gt;=0 &amp;&amp; position&lt;getCount())
            return productCounts.get(position);
        return null;
    }
    @Override
    public long getItemId(int position) {
        if(productCounts!=null &amp;&amp; position &gt;=0 &amp;&amp; position&lt;getCount()){
            ProductCount temp = productCounts.get(position);
            return productCounts.indexOf(temp);
        }
        return 0;
    }
    public class ProductsListHolder{
        public ImageView cart_item_img;
        public TextView cart_item_desc;
        public TextView cart_item_count;
        public TextView cart_item_price_tag;
        public TextView cart_item_price;
        public ImageButton cart_item_minus;
        public ImageButton cart_item_plus;


    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
        final ProductsListHolder productsListHolder;
        if(view == null){
            view = inflater.inflate(R.layout.cart_adapter, parent, false);
            productsListHolder = new ProductsListHolder();
            productsListHolder.cart_item_img = (ImageView) view.findViewById(R.id.cart_item_img);
            productsListHolder.cart_item_desc = (TextView) view.findViewById(R.id.cart_item_desc);
            productsListHolder.cart_item_count = (TextView) view.findViewById(R.id.cart_item_count);
            productsListHolder.cart_item_price_tag = (TextView) view.findViewById(R.id.cart_item_price_tag);
            productsListHolder.cart_item_price = (TextView) view.findViewById(R.id.cart_item_price);
            plusButton = (ImageButton) view.findViewById(R.id.cart_item_plus);
            minusButton = (ImageButton) view.findViewById(R.id.cart_item_minus);
            selectToDelete = (CheckBox) view.findViewById(R.id.select_to_delete);
            selectToDelete.setTag(position);
            view.setTag(productsListHolder);
        }
        else{
            productsListHolder = (ProductsListHolder) view.getTag();
        }
        final ProductCount cat = productCounts.get(position);
        selectToDelete.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    if(onDeleteCartItem != null){
                        onDeleteCartItem.onSelectToDelete((Integer)buttonView.getTag(),isChecked);
                    }
                }
            }
        });
        minusButton.setOnClickListener(new View.OnClickListener() {
            int itemcount = 0;
            @Override
            public void onClick(View v) {
                itemcount = productCounts.get(position).getCount();
                productCounts.get(position).setCount(itemcount-1);
                setProduct(position,productsListHolder,cat);
            }
        });
        plusButton.setOnClickListener(new View.OnClickListener() {
            int itemcount = 0;
            @Override
            public void onClick(View v) {
                itemcount = productCounts.get(position).getCount();
                productCounts.get(position).setCount(itemcount+1);
                setProduct(position,productsListHolder,cat);
            }
        });

        setProduct(position,productsListHolder,cat);
        return view;
    }

    private void setProduct(int position, final ProductsListHolder productsListHolder, ProductCount pCount) {
        Picasso.with(context).load(pCount.products.getImageResours()).into(new Target(){
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                productsListHolder.cart_item_img.setBackground(new BitmapDrawable(context.getResources(), bitmap));
            }

            @Override
            public void onBitmapFailed(final Drawable errorDrawable) {
            }
            @Override
            public void onPrepareLoad(final Drawable placeHolderDrawable) {
            }
        });
        productsListHolder.cart_item_desc.setText(pCount.getProducts().getDescription());
        productsListHolder.cart_item_price_tag.setText((String.valueOf(pCount.getCount()).concat(" x Rs. ").concat(String.valueOf((pCount.products.getPrice())))));
        productsListHolder.cart_item_price.setText("Rs. ".concat(String.valueOf(pCount.getCount()* pCount.products.getPrice())));
        productsListHolder.cart_item_count.setText(String.valueOf(pCount.getCount()));
    }
    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
}
