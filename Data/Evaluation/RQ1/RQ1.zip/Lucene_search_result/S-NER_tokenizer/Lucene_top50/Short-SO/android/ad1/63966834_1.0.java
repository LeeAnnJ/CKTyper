public static void hideSoftKeyboard(Activity activity) {

    InputMethodManager inputMethodManager =
            (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);

    View currentFocus = activity.getCurrentFocus();

    if (inputMethodManager != null) {
        IBinder windowToken = activity.getWindow().getDecorView().getRootView().getWindowToken();
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0);
        inputMethodManager.hideSoftInputFromWindow(windowToken, InputMethodManager.HIDE_NOT_ALWAYS);

        if (currentFocus != null) {
            inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

}
boolean hideSuccess = KeyboardUtils.hideKeyboard(activity);

// or
boolean hideSuccess = KeyboardUtils.hideKeyboard(fragment);

// or
boolean hideSuccess = KeyboardUtils.hideKeyboard(editText); // It's recommended
import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

/**
 * @author aminography
 */
public class KeyboardUtils {

    public static boolean hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (imm != null) {
            View focus = activity.getCurrentFocus();
            if (focus == null) focus = new View(activity);
            return imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        } else {
            return false;
        }
    }

    public static boolean hideKeyboard(Fragment fragment) {
        InputMethodManager imm = (InputMethodManager) fragment.requireContext().getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (imm != null) {
            View focus = fragment.requireActivity().getCurrentFocus();
            if (focus == null) focus = new View(fragment.requireContext());
            return imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
        } else {
            return false;
        }
    }

    public static boolean hideKeyboard(EditText editText) {
        InputMethodManager imm = (InputMethodManager) editText.getContext().getSystemService(Activity.INPUT_METHOD_SERVICE);
        if (imm != null) {
            return imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        } else {
            return false;
        }
    }
}
