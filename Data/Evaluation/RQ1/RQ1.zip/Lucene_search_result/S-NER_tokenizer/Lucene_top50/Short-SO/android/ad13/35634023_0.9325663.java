public class MyAdapter extends BaseAdapter {
    // One view to Header
    // One view to filter options ("most helpful first" and "Options")
    // One view to comments
    private final static int VIEW_HEADER = 0;
    private final static int VIEW_OPTIONS = 1;
    private final static int VIEW_COMMENTS = 2;
    private final static int VIEW_TYPE_MAX = 3;

    @Override
    public int getViewTypeCount () {
        // It will return 3 since I have 3 different types of VIEW
        return VIEW_TYPE_MAX;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0)
            return VIEW_HEADER;
        else if (position == 1)
            return VIEW_OPTIONS;
        else
            return VIEW_COMMENTS;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            if(getItemViewType(position) == VIEW_HEADER)
                // Inflate HEADER Layout
            else if (getItemViewType(position) == VIEW_OPTIONS)
                // Inflate Options Layout
            else
                // Inflate comments Layout
        }

        // Fill the view contents according to its type
        ....
        return convertView;
    }
}
private static void setListViewHeightBasedOnChildren(ListView listView) {
    ListAdapter listAdapter = listView.getAdapter();
    if (listAdapter == null)
        return;

    int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
    int totalHeight = 0;
    View view = null;
    for (int i = 0; i &lt; listAdapter.getCount(); i++) {
        view = listAdapter.getView(i, view, listView);
        if (i == 0)
            view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT));

        view.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
        totalHeight += view.getMeasuredHeight();
    }
    ViewGroup.LayoutParams params = listView.getLayoutParams();
    params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
    listView.setLayoutParams(params);
}
