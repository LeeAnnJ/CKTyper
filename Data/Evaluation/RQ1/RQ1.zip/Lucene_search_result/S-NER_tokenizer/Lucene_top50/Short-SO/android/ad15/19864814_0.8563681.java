public class RacePanel extends JPanel  {

private boolean reset = false;
private horse h1, h2, h3;
private int increase;
public RacePanel(){

     h1 = new horse(20,10);
         h2 = new horse(20,55);
            h3 = new horse(20,100);

     new PausableThread(new readySet(){
            public void go(){
                try {

                    Random randomNum = new Random();

                    increase = randomNum.nextInt(10);
                    h1.setPosition(h1.getPosition() + increase);
                        increase = randomNum.nextInt(10);
                        h2.setPosition(h2.getPosition() + increase);
                            increase = randomNum.nextInt(10);
                            h3.setPosition(h3.getPosition() + increase);
                    Thread.sleep(50);

                    if(reset){
                        h1.setPosition(20);
                        h2.setPosition(20);
                        h3.setPosition(20);
                        reset=false;
                    }
                    if(h1.getPosition() &gt;= 415){

                        PausableThread.pause();
                        JOptionPane.showMessageDialog(getRootPane(),"Horse one is the winner", "We Have A Winner!", JOptionPane.PLAIN_MESSAGE);
                        setReset(true);
                    }
                    else if(h2.getPosition() &gt;= 415){

                        PausableThread.pause();
                        JOptionPane.showMessageDialog(getRootPane(),"Horse two is the winner", "We Have A Winner!", JOptionPane.PLAIN_MESSAGE);
                        setReset(true);
                    }
                    else if(h3.getPosition() &gt;= 415){

                        PausableThread.pause();
                        JOptionPane.showMessageDialog(getRootPane(),"Horse three is the winner", "We Have A Winner!", JOptionPane.PLAIN_MESSAGE);
                        setReset(true);
                    }

                    repaint();

                } catch(InterruptedException e) {

                    e.printStackTrace();
                }
            }                   

             });


}

public void setReset(boolean bool){
    reset = bool;
}

@Override
public void paintComponent(Graphics image){
    super.paintComponent(image);
    image.setColor(Color.GRAY);
        image.fillRect(40,20,415,4);
        h1.draw(image);
            image.fillRect(40,65,415,4);
            h2.draw(image);
                image.fillRect(40,110,415,4);
                h3.draw(image); 
}   
public class horse {


private int xPosition, yPosition;
private Image horse;

public horse(int x, int y){

    horse = getImage("mustang.gif");
    xPosition = x;
    yPosition = y;  
}

private Image getImage(String filename) {
     URL url = getClass().getResource( filename ); 
     ImageIcon icon = new ImageIcon( url ); 
     return icon.getImage(); 
}

public void draw(Graphics image){
    image.drawImage(horse, this.xPosition, this.yPosition, null);
}

public void setPosition(int value){
    xPosition = value;
}

public int getPosition(){
    return xPosition;
}

public void drawhorse(Graphics image){
    image.drawImage(horse, xPosition, yPosition, null);
}

}
