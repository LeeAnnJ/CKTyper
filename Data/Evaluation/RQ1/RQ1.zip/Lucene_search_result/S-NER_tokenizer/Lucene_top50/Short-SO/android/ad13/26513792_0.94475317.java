* {
-webkit-tap-highlight-color: rgba(0,0,0,0); /* make transparent link selection, adjust last value opacity 0 to 1.0 */
}

body {
-webkit-touch-callout: none;    /* prevent callout to copy image, etc when tap to hold */
-webkit-text-size-adjust: none; /* prevent webkit from resizing text to fit */
-webkit-user-select: none;      /* prevent copy paste, to allow, change 'none' to 'text' */
}
public class XWalkWebView extends XWalkView {

  public XWalkWebView(Context context, AttributeSet attrs) {
    super(context, attrs);
  }

  private ActionMode.Callback mOriginalCallback;

  @Override
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    try {
        View innerChild = ((ViewGroup) getChildAt(0)).getChildAt(0);
        Field contentViewField = innerChild.getClass().getDeclaredField("mContentView");
        contentViewField.setAccessible(true);
        XWalkContentView xWalkContentView = (XWalkContentView) contentViewField.get(innerChild);
        Field contentViewCoreField = xWalkContentView.getClass().getSuperclass().getDeclaredField("mContentViewCore");
        contentViewCoreField.setAccessible(true);
        ContentViewCore viewCore = (ContentViewCore) contentViewCoreField.get(xWalkContentView);
        viewCore.setContainerView(this);
    } catch (NoSuchFieldException | IllegalAccessException e) {
        e.printStackTrace();
    }
  }

  @Override
  public ActionMode startActionMode(ActionMode.Callback callback) {
    mOriginalCallback = callback;
    ActionMode.Callback c = new // your callback...
    return super.startActionMode(c);
  }

}
public class XWalkWebView extends XWalkView {
    ...
    private Field getFields(Class clazz){
        for(Field field:clazz.getDeclaredFields()){
            if(ContentViewCore.class == field.getType()){
                return field;
            }
        }
        clazz = clazz.getSuperclass();
        if(clazz!=null &amp;&amp; clazz!=Object.class){
            Field field = getFields(clazz);
            if(field!=null)return field;
        }
        return null;
    }
    private void inject(View view){
        Field field = getFields(view.getClass());
        if(field!=null){
            field.setAccessible(true);
            try {
                ContentViewCore viewCore = (ContentViewCore) field.get(view);
                viewCore.setContainerView(this);
                return;
            }catch(Exception e){

            }
        }
        if(view instanceof ViewGroup){
            ViewGroup viewGroup = (ViewGroup)view;
            int count = viewGroup.getChildCount();
            for(int i = 0;i&lt;count;i++){
                inject(viewGroup.getChildAt(i));
            }
        }
    }
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        inject(this);
    }
    ...
@Override
public ActionMode startActionMode(ActionMode.Callback callback) {
    return new ActionMode() {
        @Override
        public void setTitle(CharSequence charSequence) {

        }

        @Override
        public void setTitle(int i) {

        }

        @Override
        public void setSubtitle(CharSequence charSequence) {

        }

        @Override
        public void setSubtitle(int i) {

        }

        @Override
        public void setCustomView(View view) {

        }

        @Override
        public void invalidate() {

        }

        @Override
        public void finish() {

        }

        @Override
        public Menu getMenu() {
            return null;
        }

        @Override
        public CharSequence getTitle() {
            return null;
        }

        @Override
        public CharSequence getSubtitle() {
            return null;
        }

        @Override
        public View getCustomView() {
            return null;
        }

        @Override
        public MenuInflater getMenuInflater() {
            return null;
        }
    };
 }
