&lt;script&gt;
    $.get('@routes.Assets.at("resources/menu.json")');
&lt;/script&gt;
public static Result menuViaControllerJson() {
    InputStream is = Play.application().classloader().getResourceAsStream("resources/menu.json");
    return (is != null)
            ? ok(is)
            : notFound();
}
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

....

Config cfg = ConfigFactory.parseResources(Play.application().classloader(), "ses.conf");
debug("My 'foo' is configured as: " + cfg.getString("foo"));
