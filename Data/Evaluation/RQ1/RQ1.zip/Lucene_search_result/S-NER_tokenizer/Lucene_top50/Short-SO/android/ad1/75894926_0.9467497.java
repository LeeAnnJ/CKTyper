 @Override
    public void onBackPressed()
    {
        if (keyboardIsVisible()) {
            Toast.makeText(getBaseContext(),&quot;hide keyboard now&quot;,Toast.LENGTH_LONG).show();
          //  hideKeyboard(this);
        }
        else {
            Toast.makeText(getBaseContext(),&quot;keyboard is hidden&quot;,Toast.LENGTH_LONG).show();
            //super.onBackPressed();
        }
    }

    private static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        assert imm != null;
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private boolean keyboardIsVisible() {
       // return getRootWindowInsets(getWindow().getDecorView()).isVisible(WindowInsetsCompat.Type.ime());
        return getWindow().getDecorView().getRootWindowInsets().isVisible(WindowInsetsCompat.Type.ime());
    }
