public static Bitmap getBitmapFromView(View view) {
    view.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
    Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(),
            Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
    view.draw(canvas);
    return bitmap;
}
protected Bitmap convertToBitmap(CardView view) {
    int totalHeight = view.getHeight;
    int totalWidth = view.getWidth();
    float percent = 0.7f;//use this value to scale bitmap to specific size

    Bitmap canvasBitmap = Bitmap.createBitmap(totalWidth,totalHeight, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(canvasBitmap);
    canvas.scale(percent, percent);
    view.draw(canvas);

    return canvasBitmap;
}
