/META-INF/resources/

/resources/

/static/

/public/
src/main/resources/META-INF/resources/index.html

src/main/resources/resources/index.html

src/main/resources/static/index.html

src/main/resources/public/index.html
project  
|--build
|  |--dist
|  |--...  
|--node_modules
|--src  
|  |--app  
|  |--assets
|  |--main  
|  |  |--java  
|  |  |--resources
|  |  |  |--config  
|  |  |--webapp
|  |  |  |--WEB-INF  
