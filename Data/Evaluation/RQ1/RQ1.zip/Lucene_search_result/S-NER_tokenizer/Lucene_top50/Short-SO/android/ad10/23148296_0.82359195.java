Display display = getWindowManager().getDefaultDisplay();
@SuppressWarnings("deprecation")
int width = display.getWidth();
int height = "ParentLayoutOFView".getMeasuredHeight();

createImage(height, width, linearLayout, "FileName");
public File createImage(int height, int width, View view, String fileName) {
    Bitmap bitmapCategory = getBitmapFromView(view, height, width);
    return createFile(bitmapCategory, fileName);
}

public File createFile(Bitmap bitmap, String fileName) {

    File externalStorage = Environment.getExternalStorageDirectory();
    String sdcardPath = externalStorage.getAbsolutePath();
    File reportImageFile = new File(sdcardPath + "/YourFolderName" + fileName + ".jpg");
    try {
        if (reportImageFile.isFile()) {
            reportImageFile.delete();
        }
        if (reportImageFile.createNewFile()) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
            FileOutputStream fo = new FileOutputStream(reportImageFile);
            fo.write(bytes.toByteArray());
            bytes.close();
            fo.close();

            return reportImageFile;
        }
    } catch (Exception e) {
        Toast.makeText(ReportsActivity.this, "Unable to create Image.Try again", Toast.LENGTH_SHORT).show();
    }
    return null;
}

public Bitmap getBitmapFromView(View view, int totalHeight, int totalWidth) {

    Bitmap returnedBitmap = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(returnedBitmap);
    Drawable bgDrawable = view.getBackground();
    if (bgDrawable != null)
        bgDrawable.draw(canvas);
    else
        canvas.drawColor(Color.WHITE);

    view.measure(MeasureSpec.makeMeasureSpec(totalWidth, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(totalHeight, MeasureSpec.EXACTLY));
    view.layout(0, 0, totalWidth, totalHeight);
    view.draw(canvas);
    return returnedBitmap;
}
