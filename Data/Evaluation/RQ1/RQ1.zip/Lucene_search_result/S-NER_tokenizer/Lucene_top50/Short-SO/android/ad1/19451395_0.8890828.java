&lt;RelativeLayout android:id="@+id/rootLayout"...

&lt;Textview.../&gt;
&lt;Button../&gt;

....
...

&lt;RelativeLayout/&gt;
&lt;LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/shiptostore_cell"..../&gt;
public static void hideSoftKeyboard(Activity activity) 
    {

        if(activity!= null &amp;&amp; activity.getCurrentFocus() != null &amp;&amp; activity.getCurrentFocus().getWindowToken() != null)
        {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);            
        }
    }
rootLayout.setOnTouchListener(new OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideSoftKeyboard(QuestionTemplateActivity.this);
                return false;
            }
        });
public void onClick(View view) {
        InputMethodManager imm = (InputMethodManager) view.getContext()
                .getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    @Override
public boolean dispatchTouchEvent(MotionEvent event) {

    View v = getCurrentFocus();
    boolean ret = super.dispatchTouchEvent(event);

    if (v instanceof EditText) {
        View w = getCurrentFocus();
        int scrcoords[] = new int[2];
        w.getLocationOnScreen(scrcoords);
        float x = event.getRawX() + w.getLeft() - scrcoords[0];
        float y = event.getRawY() + w.getTop() - scrcoords[1];

        Log.d("Activity",
                "Touch event " + event.getRawX() + "," + event.getRawY()
                        + " " + x + "," + y + " rect " + w.getLeft() + ","
                        + w.getTop() + "," + w.getRight() + ","
                        + w.getBottom() + " coords " + scrcoords[0] + ","
                        + scrcoords[1]);
        if (event.getAction() == MotionEvent.ACTION_UP
                &amp;&amp; (x &lt; w.getLeft() || x &gt;= w.getRight() || y &lt; w.getTop() || y &gt; w
                        .getBottom())) {

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getWindow().getCurrentFocus()
                    .getWindowToken(), 0);
        }
    }
    return ret;
}
@Override
        public boolean dispatchTouchEvent(MotionEvent ev) {
                if (getCurrentFocus() != null) {
                      InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                      imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                    }
            return super.dispatchTouchEvent(ev);
        }
