public class HadoopFileSystem {

    private FileSystem m_fileSystem = null;

    public HadoopFileSystem() {
        Configuration l_configuration = new Configuration();
        l_configuration .set("fs.default.name", "hdfs://localhost:9100");
        l_configuration .set("mapred.job.tracker", "localhost:9101");

        m_fileSystem = FileSystem.get(l_configuration );

    }

    public void close() {
        m_fileSystem.close();
    }

    public void createFile(String a_pathDFS) {
        m_fileSystem.create(new Path(a_pathDFS));
    }

}
HadoopFileSystem h1 = new HadoopFileSystem();
HadoopFileSystem h2 = new HadoopFileSystem();

if(h1 == h2)
    System.out.println("=="); // No print
if(h1.equals(h2))
    System.out.println("equals"); // No print

h2.close();
h1.createFile("test.test"); // ERROR : java.io.IOException: Filesystem closed
h1.close();
