public class GameActivity extends Activity {

    protected GameView view = null;
    protected EditText editText;

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);

        view = new GameView(this);
        setContentView(view);

        editText = new EditText(this);
        editText.setCursorVisible(false);
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
    }

    public boolean showKeyboard()
    {
        JniApp.log("showKeyboard() in Java invoked!!!");

        editText.requestFocus();
        editText.requestFocusFromTouch();

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(editText, InputMethodManager.SHOW_FORCED);
    }
