public BaseActivity extends Activity{

    protected object myVariableForAllActivities;

}

public MyActivity extends BaseActivity{

    myVariableForAllActivies = someValue;

}
class Config {
  private Config singleton;
  private Config() {}
  public static Config getInstance() {
    if (singleton != null) return singleton;
    singleton = new Config();
    return singleton;
  }
}
class SingletonObject{
        private static SingletonObject instance;
        private Object object;
        private SingletonObject(){
            object = new Object();
        }

        public static synchronized SingletonObject getInstance() {
            if (instance == null){
                instance = new SingletonObject();
            }
            return instance;
        }

        public Object getObject() {
            return object;
        }

        public void setObject(Object object) {
            this.object = object;
        }
    }
SingletonObject.getInstance().setObject(new Object());// or existing object

                Object object = SingletonObject.getInstance().getObject();
