@Override
public void init(ServletConfig config) {
    try {
        super.init(config);
        ServletContext context = getServletContext();
        URL resourceUrl = context.getResource(&quot;/WEB-INF/config.properties&quot;);
        if (resourceUrl == null) {
            throw new ConfigurationException(&quot;Unable to find config.properties&quot;);
        }
        Path configFile = Paths.get(resourceUrl.toURI());
public static ODataServlet getServlet() throws MalformedURLException {
    if (servlet == null) {
        servletConfig = new MockServletConfig(); 
        MockServletContext context = new MockServletContext();
        Path path = Paths.get(&quot;src/test/resources/config.properties&quot;);
        when(context.getResource(&quot;/WEB-INF/config.properties&quot;)).thenReturn(path.toUri().toURL());

        servlet = new ODataServlet(){
             /**
             * 
             */
            private static final long serialVersionUID = 1L;

            public ServletContext getServletContext() {
                  return context; // return the mock
                }
        };
        servlet.init(servletConfig);
    }
    return servlet;
}
