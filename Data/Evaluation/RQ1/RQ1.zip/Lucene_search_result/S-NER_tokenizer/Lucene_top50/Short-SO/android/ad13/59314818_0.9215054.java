@Override
        protected Void doInBackground(Void... voids) {
            for (int i = 0; i &lt; 100; i++) {
                mDataContainer.addItem(i);
                publishProgress(i);
            }
            return null;
        }
@Override
        protected void onProgressUpdate(Integer... values) {
            mAdapter.notifyItemInserted(values[0]);
            super.onProgressUpdate(values);
        }
private class MyAdapter extends RecyclerView.Adapter&lt;MyAdapter.MyViewHolder&gt; {
        private List&lt;Item&gt; mItems;
        private int selectedPos = RecyclerView.NO_POSITION;

        private class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            private Item mItem;
            private TextView mNameTextView;
            private TextView mMembersTextView;

            MyViewHolder(View view) {
                super(view);
                itemView.setOnClickListener(this);
                mNameTextView = itemView.findViewById(R.id.item_name);
                mMembersTextView = itemView.findViewById(R.id.item_members);
            }

            @Override
            public void onClick(View view) {
                notifyItemChanged(selectedPos);
                selectedPos = getLayoutPosition();
                notifyItemChanged(selectedPos);
                mOnItemSelectedListener.onItemSelected(mItem);
            }
        }

        MyAdapter(List&lt;Item&gt; items) {
            mItems = items;
        }

        @NonNull
        @Override
        public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(getActivity())
                    .inflate(R.layout.list_item, parent, false);

            return new MyViewHolder(view);
        }

        @Override
        public void onBindViewHolder(MyViewHolder myViewHolder, int position) {
            Item item = mItems.get(position);
            myViewHolder.mItem = item;
            myView.mNameTextView.setText(item.getName());
            myView.mMembersTextView.setText(String.format(Locale.US,"%d/50", item.getMembers()));

            if (!mIsInit) {
                // select item that was selected before orientation change
                if (selectedPos != RecyclerView.NO_POSITION) {
                    Item selectedItem = mItems.get(selectedPos);
                    mOnItemSelectedListener.onItemSelected(selectedItem);
                // else select item 0 as default on landscape mode
                } else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
                    selectedPos = 0;
                    mOnItemSelectedListener.onItemSelected(MyViewHolder.mItem);
                }
                mIsInit = true;
            }

            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                myViewHolder.itemView.setSelected(selectedPos == position);
            }
        }

        @Override
        public int getItemCount() {
            return mItems.size();
        }
    }
        @Override
        protected Void doInBackground(Void... voids) {
            for (int i = 0; i &lt; 100; i++) {
                mDataContainer.addItem(i);
            }
            return null;
        }

     @Override
     protected void onPostExecute(Long result) {
         mAdapter.notifyItemRangeInserted(0, 100);
     }
