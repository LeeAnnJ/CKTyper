package com.org.tre.myth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

@Configuration
public class ExternalPropertyConfig {


@Bean
public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
final PropertySourcesPlaceholderConfigurer properties = new PropertySourcesPlaceholderConfigurer();

Resource[] resources = new Resource[ ] {
        new ClassPathResource(&quot;/myth/app/data/weblogic_configuration/config/conf.properties&quot;), // i want this config used when i deploy it in dev
        new FileSystemResource(&quot;src/main/resources/conf.properties&quot;) // i want this config used when in local test
};

properties.setLocations( resources );
properties.setIgnoreResourceNotFound(true);
properties.setIgnoreUnresolvablePlaceholders(false);
return properties;
 }
}
Resource[] resources = new Resource[ ] {
            new FileSystemResource(&quot;/myth/app/data/weblogic_configuration/config/conf.properties&quot;),
            new FileSystemResource(&quot;src/main/resources/conf.properties&quot;)
    };
