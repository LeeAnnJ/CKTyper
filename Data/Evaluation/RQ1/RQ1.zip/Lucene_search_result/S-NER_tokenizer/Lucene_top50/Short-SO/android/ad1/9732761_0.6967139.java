&lt;application android:icon=&quot;@drawable/icon&quot; android:label=&quot;@string/app_name&quot;&gt;
&lt;activity android:name=&quot;.Main&quot;
          android:label=&quot;@string/app_name&quot;
          android:windowSoftInputMode=&quot;stateHidden&quot;
          &gt;
&lt;activity
        ...
        android:windowSoftInputMode=&quot;stateHidden|adjustPan&quot;
        ...
        &gt;
&lt;style name="MyTheme" parent="Theme"&gt;
    &lt;item name="android:windowSoftInputMode"&gt;stateHidden&lt;/item&gt;
&lt;/style&gt;
&lt;activity
    android:name=&quot;.HomeActivity&quot;
    android:label=&quot;@string/app_name&quot;
    android:windowSoftInputMode=&quot;stateAlwaysHidden&quot; &gt;
//to hide the soft keyboard
InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
public static void hideKeyboard(Activity activity) {
    View view = activity.getCurrentFocus();

    if (view != null) {
        InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
    }
}
&lt;activity
    android:name=".MainActivity"
    android:label="@string/app_name"
    android:theme="@style/AppTheme"
    android:windowSoftInputMode="stateHidden"&gt;
android:focusable="false"
android:focusableInTouchMode="false" 
&lt;activity android:name=".HomeActivity"  android:windowSoftInputMode="stateHidden"&gt;
&lt;/activity&gt;
@Override
public void onResume() {
    this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    super.onResume();
}

@Override
public void onStart() {
    this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    super.onStart();
}
android:focusable="true"
android:focusableInTouchMode="true"
&lt;?xml version="1.0" encoding="utf-8"?&gt;
&lt;LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    ...
    android:focusable="true"
    android:focusableInTouchMode="true" &gt;

    &lt;EditText
        android:id="@+id/myEditText"
        ...
        android:hint="@string/write_here" /&gt;

    &lt;Button
        android:id="@+id/button_ok"
        ...
        android:text="@string/ok" /&gt;
&lt;/LinearLayout&gt;
&lt;?xml version="1.0" encoding="utf-8"?&gt;
&lt;ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    ... &gt;                                            &lt;!--not here--&gt;

    ...    &lt;!--other elements--&gt;

    &lt;LinearLayout
        android:id="@+id/theDirectParent"
        ...
        android:focusable="true"
        android:focusableInTouchMode="true" &gt;        &lt;!--here--&gt;

        &lt;EditText
            android:id="@+id/myEditText"
            ...
            android:hint="@string/write_here" /&gt;

        &lt;Button
            android:id="@+id/button_ok"
            ...
            android:text="@string/ok" /&gt;
    &lt;/LinearLayout&gt;

&lt;/ConstraintLayout&gt;
@Override
public boolean dispatchTouchEvent(MotionEvent ev) {
      if (getCurrentFocus() != null) {
           InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
           imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
      }
      return super.dispatchTouchEvent(ev);
}
override fun onResume() {
  super.onResume()

  window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
}
&lt;activity android:name=".MainActivity"
            android:windowSoftInputMode="stateHidden"&gt;
TextView mtextView = findViewById(R.id.myTextView);
mtextView.setShowSoftInputOnFocus(false);
&lt;activity android:name=&quot;.MainActivity&quot;
  android:windowSoftInputMode=&quot;stateAlwaysHidden&quot;&gt;
   override fun onResume() {
    window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
    super.onResume()
}
