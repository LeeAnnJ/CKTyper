@Test
public void testProviderDetails_ValidFile()        
{

       ClassLoader classLoader = getClass().getClassLoader();

        // Throws null pointer exception here
        File file = new File(classLoader.getResource("services/src/text/resources/config/test.txt").getFile());

        String filePath = file.getAbsolutePath();

}
   File file = new File(classLoader.getResource("c:/dev/Provider_Services/services/src/text/resources/config/test.txt").getFile()); and

    File file = new File(classLoader.getResource("test.txt").getFile());

   File file = new File(classLoader.getResource("config/test.txt").getFile());
