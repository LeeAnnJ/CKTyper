public class DealerProtocolTests {
    
        @Test
        void sendDealerRequest() throws Exception {
            RestAssured.config = RestAssured.config().sslConfig(
                    new SSLConfig()
                            .trustStore(&quot;src/test/resources/certificate/SERVER.p12&quot;, &quot;password&quot;)
                            .keyStore(&quot;src/test/resources/certificate/CLIENT.p12&quot;, &quot;password&quot;));
            
            Response response = null;
             response =
                    given()
                            .config(config)
                            .spec(xmlSpec)
                            .basePath(&quot;/xmlInteface&quot;)
                            .body(&quot;&quot;)
                            .when()
                            .get()
                            .then()
                            .statusCode(200)
                            .log().all()
                            .extract().response();
    
            System.out.println(response.prettyPrint());
        }
    }
