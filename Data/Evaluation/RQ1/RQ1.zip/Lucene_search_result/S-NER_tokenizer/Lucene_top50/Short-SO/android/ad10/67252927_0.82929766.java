private Bitmap getBitmapFromFrontView(View view) {
    //Define a bitmap with the same size as the view
    Bitmap frontReturnedBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
    //Bind a canvas to it
    Canvas frontCanvas = new Canvas(frontReturnedBitmap);
    //Get the view's background
    Drawable frontBGDrawable = view.getBackground();
    if (frontBGDrawable != null) {
        //has background drawable, then draw it on the canvas
        frontBGDrawable.draw(frontCanvas);
    } else {
        //does not have background drawable, then draw white background on the canvas
        frontCanvas.drawColor(Color.WHITE);
    }
    // draw the view on the canvas
    view.draw(frontCanvas);
    //return the bitmap
    return frontReturnedBitmap;
}
ByteArrayOutputStream frontbaos = new ByteArrayOutputStream();
    bitMappedFrontImage.compress(Bitmap.CompressFormat.JPEG, 100, frontbaos);
    byte[] frontImageBytes = frontbaos.toByteArray();
    String base64FrontImage = Base64.encodeToString(frontImageBytes, Base64.DEFAULT);
   System.out.println(&quot;Here is your Base64 String:&quot;+ base64FrontImage);
 ByteArrayOutputStream frontbaos = new ByteArrayOutputStream();
    byte[] frontImageBytes = frontbaos.toByteArray();
    frontImageBytes = Base64.decode(String.valueOf(base64FrontImage), Base64.DEFAULT);
    Bitmap decodedFrontImage = BitmapFactory.decodeByteArray(frontImageBytes, 0, frontImageBytes.length);
    image.setImageBitmap(decodedFrontImage );
