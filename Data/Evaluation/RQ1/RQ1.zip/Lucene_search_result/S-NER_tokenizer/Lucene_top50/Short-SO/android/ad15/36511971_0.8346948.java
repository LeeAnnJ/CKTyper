    final Handler h1 = new Handler();
    final int delay1 = 400;

    h1.postDelayed(new Runnable(){
        public void run(){
            enableRandomButton();
            buttonsInPlay = sumVector(greenButtons);

            if (buttonsInPlay &gt;= 4){

                if (currentScore &gt; highScore){
                    highScore = currentScore;
                }

                // GO TO SCORE SCREEN
                h1.removeCallbacks(this);
                Intent intent = new Intent(Game.this, Main.class);
                Game.this.startActivity(intent);
                Game.this.finish();
            }

            h1.postDelayed(this, delay1);
        }
    }, delay1);
