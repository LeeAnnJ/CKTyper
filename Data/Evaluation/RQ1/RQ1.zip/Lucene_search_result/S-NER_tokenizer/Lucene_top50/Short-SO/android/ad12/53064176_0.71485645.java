  Locale locale = new Locale("en");
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.locale = locale;
        context.getResources().updateConfiguration(config,
                context.getResources().getDisplayMetrics());
SharedPrefUtils.saveLocale(locale); // optional - Helper method to save the selected language to SharedPreferences in case you might need to attach to activity context (you will need to code this)
Resources resources = getResources();
Configuration configuration = resources.getConfiguration();
DisplayMetrics displayMetrics = resources.getDisplayMetrics();
if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.JELLY_BEAN_MR1){
    configuration.setLocale(locale);
} else{
    configuration.locale=locale;
}
if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.N){
    getApplicationContext().createConfigurationContext(configuration);
} else {
    resources.updateConfiguration(configuration,displayMetrics);
}
