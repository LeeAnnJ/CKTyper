public class Config
{
  public String name = &quot;&quot;;
  private SettingsSystem activity;
  public void getSettingsFromServer()
  {
    name = &quot;&quot;;//name received from server
  }

  public void setMyActivity(SettingsSystem activity) 
  {
    this.activity = activity;
  }

  public void applyChanges()
  {
    if (this.activity != null)
    {
      this.activity.ApplySettings();
    }
  }    
}
public void setConfigActivity() 
{
  this.config.setMyActivity(this);
}
public void getSettingsFromServer() {
    name = &quot;&quot;; //name received from server
    // [ADD THIS] Notify to activity that settings are changed, 
    // it should apply new settings
    EventBus.getDefault().postSticky(new SettingsChangedEvent());
}
@Override
protected void onStart() {
    super.onStart();
    // Allow this activity to listen settings changed event
    EventBus.getDefault().register(this);
}

@Override
protected void onStop() {
    // Disallow this activity from listening settings changed event
    EventBus.getDefault().unregister(this);
    super.onStop();
}

@Subscribe(threadMode = ThreadMode.MAIN, sticky = true)
public void onSettingsChangedEvent(SettingsChangedEvent ev) {
    // When settings changed event is notified/posted from Config class, 
    // the code inside this method will be executed.
    SettingsChangedEvent event = EventBus.getDefault().removeStickyEvent(SettingsChangedEvent.class);
    if (event != null) {
        // Apply new settings here
        ApplySettings();
    }
}
