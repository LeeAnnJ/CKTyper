 public static void hideSystemKeyBoard1(Context mcontext) {
  InputMethodManager imm = (InputMethodManager) mcontext
    .getSystemService(Context.INPUT_METHOD_SERVICE);
   if (imm.isActive())  
   imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT,
     InputMethodManager.HIDE_NOT_ALWAYS);
 }


 public static void hideSystemKeyBoard2(Context mcontext,View v) {
  InputMethodManager imm = (InputMethodManager) ((AbstractMmtClientActivity) mcontext)
    .getSystemService(Context.INPUT_METHOD_SERVICE);
  imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
 }
&lt;activity android:name="com.your.package.ActivityName"
      android:windowSoftInputMode="stateHidden"  /&gt;
getWindow().setSoftInputMode(
      WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    enter code here
//  That Code Write in Manifest 
    &lt;activity android:name="com.package.ClassName" android:configChanges="orientation|screenSize" android:windowSoftInputMode="stateHidden"&gt;
            &lt;/activity&gt;

//or other Wise  you Use Below Method

/**
     * Method for hiding soft key board

     * @param activity
     */

    public static void hideSoftKeyboard(Activity activity) {
        try {
            if(activity.getCurrentFocus()!=null) {
                InputMethodManager inputMethodManager = (InputMethodManager)activity. getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
