src
 |-main
 |--java
 |---{project-name}
 |----config
 |----models
 |----screens
 |----services
 |-test
 |--java
 |---{project-name}
 |----helpers
 |----stepDefinitions
 |-----LoginStep.java
 |-----BaseStep.java
 |-----LoginStep.java
 |----RunCucumber.java
 |--resources
 |---feature
 |----Login.feature 
package com.mobile.automation.framework;

import com.google.inject.Guice;
import com.mobile.automation.framework.module.ServiceModules;
import com.mobile.automation.framework.service.AppiumServer;
import com.mobile.automation.framework.config.drivers.DriverFactory;
import com.mobile.automation.framework.module.ScreensModule;
import io.appium.java_client.AppiumDriver;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        monochrome = true,
        glue = "src.test.java.com.mobile.automation.framework.stepDefinition",
        features = "src/test/resources/feature",
        plugin = {"pretty", "html:target/cucumber-report/cucumber.html",
                "json:target/cucumber-report/cucumber.json",
                "junit:target/cucumber-report/cucumber.xml"})
public class RunCucumber {
    public static AppiumDriver driver;

    @Before
    public void setUpDriver() {
        init();
        new AppiumServer().startServer();
        driver = new DriverFactory().getDriver();
    }

    @After
    public void tearDownDriver() {
        if (driver != null) {
            driver.quit();
            new AppiumServer().stopServer();
        }
    }

    private void init() {
        Guice.createInjector(
                new ScreensModule(driver),
                new ServiceModules(driver)
        ).injectMembers(this);
    }
}

Feature: Sign In feature

  Background:
    Given I install application
    And I enable all network activity
    Then I am on Sign Page

  Scenario: Sign In scenario
    Given I am go to the Login Page
    And I fill valid user data using "Config"
    And I click sign in button

    Then I am login in the application

package com.mobile.automation.framework.stepDefinition;

import javax.inject.Inject;

import com.mobile.automation.framework.config.ProjectConfig;
import com.mobile.automation.framework.models.User;
import com.mobile.automation.framework.screens.DashboardScreen;
import com.mobile.automation.framework.screens.SignInScreen;
import io.cucumber.java.ParameterType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

/**
 * @author Tomash Gombosh
 */
public class LoginStep {
    @Inject
    private SignInScreen signInScreen;
    @Inject
    private DashboardScreen dashboardScreen;

    @Given("^I am go to the Login Page$")
    public void iAmGoToTheLoginPage() {
        dashboardScreen.tapLogin();
    }

    @And("I fill valid user data using {string} {string}")
    public void iFillValidUserDataUsing(String userName, String password) {
        signInScreen.fillLogin(userName, password);
    }

    @And("I fill valid user data using {string}")
    @ParameterType("Config")
    public void iFillValidUserDataUsing() {
        signInScreen.fillLogin(new User(data -&gt; {
            data.setEmail(new ProjectConfig().getBaseUser());
            data.setPassword(new ProjectConfig().getBaseUserPassword());
        }));
    }

    @And("I click sign in button")
    public void iClickSignInButton() {
        signInScreen.clickLogin();
    }

    @Then("I am login in the application")
    public void iAmLoginInTheApplication() {
        assertThat(signInScreen.isDisplayed()).isEqualTo(true);
    }

}

