@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View view = inflater.inflate(R.layout.fragment_marker_info, container, false);

        //trying to get the View needed to convert to image
        View inflatedView = getLayoutInflater().inflate(R.layout.share_event_layout, null);

        //the two textviews on the layout
        TextView organizerName = inflatedView.findViewById(R.id.organizerShareName);
        TextView organizerAddress = inflatedView.findViewById(R.id.organizerShareAddress);

        Button shareButton = view.findViewById(R.id.shareEventBtn);
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //change their values
                organizerName.setText(getArguments().get(&quot;name&quot;).toString());
                organizerAddress.setText(getArguments().get(&quot;address&quot;).toString());

                //converting to image and share
                Bitmap icon = getBitmapFromView(inflatedView);
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType(&quot;image/jpeg&quot;);
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                icon.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
                String path = MediaStore.Images.Media.insertImage(getContext().getContentResolver(), icon, &quot;Title&quot;, null);
                Uri imageUri =  Uri.parse(path);
                share.putExtra(Intent.EXTRA_STREAM, imageUri);
                startActivity(Intent.createChooser(share, &quot;Select&quot;));
            }
        });
        return view;
    }



private Bitmap getBitmapFromView(View view) {
        //Define a bitmap with the same size as the view
        Bitmap returnedBitmap = Bitmap.createBitmap(1080, 900,Bitmap.Config.ARGB_8888);
        //Bind a canvas to it
        Canvas canvas = new Canvas(returnedBitmap);
        //Get the view's background
        Drawable bgDrawable =view.getBackground();
        if (bgDrawable!=null) {
            //has background drawable, then draw it on the canvas
            bgDrawable.draw(canvas);
        }   else{
            //does not have background drawable, then draw white background on the canvas
            canvas.drawColor(Color.WHITE);
        }
        // draw the view on the canvas
        view.draw(canvas);
        //return the bitmap
        return returnedBitmap;
    }
