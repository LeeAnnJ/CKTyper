View setButton2 = view.findViewById(R.id.savetosd);
    setButton2.setOnClickListener(new OnClickListener() {
        public void onClick(View v) {
            int i = gallery.getSelectedItemPosition();
            String s = (new StringBuilder(String.valueOf(getResources().getStringArray(R.array.wallpapers)[i]))).append(".jpg").toString();
            String s1 (new saveToSDCard(.getImage(gallery.getSelectedItemPosition()), s);
            startMediaScanner(s1);
            Toast.makeText(getActivity().getApplicationContext(), "Saved to SD Card", Toast.LENGTH_SHORT).show();
private static final String SD = Environment.getExternalStorageDirectory().getAbsolutePath();
private boolean mEmbedded;
private Bitmap mBitmap = null;
private ArrayList&lt;Integer&gt; mThumbs;
private ArrayList&lt;Integer&gt; mImages;
private WallpaperLoader mLoader;
private WallpaperDrawable mWallpaperDrawable = new WallpaperDrawable();
...

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
    findWallpapers();

    if (mEmbedded) {
        View view = inflater.inflate(R.layout.wallpaper_chooser, container, false);
        view.setBackground(mWallpaperDrawable);

        final Gallery gallery = (Gallery) view.findViewById(R.id.gallery);
        gallery.setCallbackDuringFling(false);
        gallery.setOnItemSelectedListener(this);
        gallery.setAdapter(new ImageAdapter(getActivity()));

        View setButton = view.findViewById(R.id.set);
        setButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                selectWallpaper(gallery.getSelectedItemPosition());
            }
        });
        View setButton2 = view.findViewById(R.id.savetosd);
        setButton2.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                //selectWallpaper(gallery.getSelectedItemPosition());
                int i = gallery.getSelectedItemPosition();
                String s = (new StringBuilder(String.valueOf(getResources().getStringArray(R.array.wallpapers)[i]))).append(".jpg").toString();
                String s1 (new saveToSDCard(.getImage(gallery.getSelectedItemPosition()), s);
                startMediaScanner(s1);
                Toast.makeText(getActivity().getApplicationContext(), "Saved to SD Card", Toast.LENGTH_SHORT).show();

            }
        });
        return view;
    }
    return null;
}

private void selectWallpaper(int position) {
    try {
        WallpaperManager wpm = (WallpaperManager) getActivity().getSystemService(
                Context.WALLPAPER_SERVICE);
        wpm.setResource(mImages.get(position));
        Activity activity = getActivity();
        activity.setResult(Activity.RESULT_OK);
        activity.finish();
    } catch (IOException e) {
        Log.e(TAG, "Failed to set wallpaper: " + e);
    }
}

public void onItemClick(AdapterView&lt;?&gt; parent, View view, int position, long id) {
    selectWallpaper(position);
}

public void onItemSelected(AdapterView&lt;?&gt; parent, View view, int position, long id) {
    if (mLoader != null &amp;&amp; mLoader.getStatus() != WallpaperLoader.Status.FINISHED) {
        mLoader.cancel();
    }
    mLoader = (WallpaperLoader) new WallpaperLoader().execute(position);
}

public void onNothingSelected(AdapterView&lt;?&gt; parent) {
}

private void addWallpapers(Resources resources, String packageName, int list) {
    final String[] extras = resources.getStringArray(list);
    for (String extra : extras) {
        int res = resources.getIdentifier(extra, "drawable", packageName);
        if (res != 0) {
            final int thumbRes = resources.getIdentifier(extra + "_thumb",
                    "drawable", packageName);

            if (thumbRes != 0) {
                mThumbs.add(thumbRes);
                mImages.add(res);
                // Log.d(TAG, "add: [" + packageName + "]: " + extra + " (" + res + ")");
            }
        }
    }    
}

private class ImageAdapter extends BaseAdapter implements ListAdapter, SpinnerAdapter {
    private LayoutInflater mLayoutInflater;

    ImageAdapter(Activity activity) {
        mLayoutInflater = activity.getLayoutInflater();
    }

    public int getCount() {
        return mThumbs.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View view;

        if (convertView == null) {
            view = mLayoutInflater.inflate(R.layout.wallpaper_item, parent, false);
        } else {
            view = convertView;
        }

        ImageView image = (ImageView) view.findViewById(R.id.wallpaper_image);

        int thumbRes = mThumbs.get(position);
        image.setImageResource(thumbRes);
        Drawable thumbDrawable = image.getDrawable();
        if (thumbDrawable != null) {
            thumbDrawable.setDither(true);
        } else {
            Log.e(TAG, "Error decoding thumbnail resId=" + thumbRes + " for wallpaper #"
                    + position);
        }
        return view;
    }
}

class WallpaperLoader extends AsyncTask&lt;Integer, Void, Bitmap&gt; {
    BitmapFactory.Options mOptions;

    WallpaperLoader() {
        mOptions = new BitmapFactory.Options();
        mOptions.inDither = false;
        mOptions.inPreferredConfig = Bitmap.Config.ARGB_8888;
    }
    @Override
    protected Bitmap doInBackground(Integer... params) {
        if (isCancelled()) return null;
        try {
            return BitmapFactory.decodeResource(getResources(),
                    mImages.get(params[0]), mOptions);
        } catch (OutOfMemoryError e) {
            return null;
        }
    }
    @Override
    protected void onPostExecute(Bitmap b) {
        if (b == null) return;

        if (!isCancelled() &amp;&amp; !mOptions.mCancel) {
            // Help the GC
            if (mBitmap != null) {
                mBitmap.recycle();
            }

            View v = getView();
            if (v != null) {
                mBitmap = b;
                mWallpaperDrawable.setBitmap(b);
                v.postInvalidate();
            } else {
                mBitmap = null;
                mWallpaperDrawable.setBitmap(null);
            }
            mLoader = null;
        } else {
           b.recycle();
        }
    }
    void cancel() {
        mOptions.requestCancelDecode();
        super.cancel(true);
    }
}
 private String saveToSDCard(Bitmap bitmap, String s)
 {
    StringBuffer stringbuffer = new StringBuffer();
    File file = new File ((new StringBuilder(String.valueOf(SD))).append("/JaisonBrooks|Development/GalaxyS3Wallpapers/").toString());
    if(!file.exists())
        file.mkdirs();
    File file1 = new File(file, s);
    if(file1.exists())
        file1.delete();
    ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
    bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 100, bytearrayoutputstream);
    byte abtye0[] = bytearrayoutputstream.toByteArray();
    try { 
        file1.createNewFile();
        FileOutputStream fileoutputstream = new FileOutputStream(file1);
        fileoutputstream.write(abtye0);
        fileoutputstream.flush();
        fileoutputstream.close();
        stringbuffer.append(file1.getAbsolutePath());
    }
    catch (IOException ioexception)
    {
        ioexception.printStackTrace();
    }
    return stringbuffer.toString();

    }
