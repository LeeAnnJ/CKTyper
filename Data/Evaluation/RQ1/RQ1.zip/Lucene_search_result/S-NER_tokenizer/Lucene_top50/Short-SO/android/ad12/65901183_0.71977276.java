&lt;build&gt;
        &lt;resources&gt;
            &lt;resource&gt;
                &lt;directory&gt;src/main/resources/&lt;/directory&gt;
                &lt;filtering&gt;true&lt;/filtering&gt;
            &lt;/resource&gt;
        &lt;/resources&gt;
&lt;/build&gt;
/**
 * loads default config from internal source
 *
 * @return true/false upon success/failure of loading config
 */
private static boolean loadDefault() {

    if (null != properties) return false;

    try (InputStream resourceStream = Config.class.getClassLoader().getResourceAsStream(&quot;config.properties&quot;)) {
        properties = new Properties();
        properties.load(resourceStream);
        return true;

    } catch (NullPointerException | IOException exception) {

        String detail = ExceptionHandler.format(exception, &quot;Could not load default config&quot;);
        log.error(detail);

        properties = null;
        return false;
    }
}
