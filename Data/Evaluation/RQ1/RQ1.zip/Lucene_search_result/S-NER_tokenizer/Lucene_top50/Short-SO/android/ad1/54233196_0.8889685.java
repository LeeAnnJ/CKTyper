@Override
public void onPageStarted(WebView view, String url, Bitmap favicon) {

    super.onPageStarted(view, url, favicon);

    Log.d("WebView", "your current url when webpage loading.." + url);

    if(url.equals("https://********/index.php?show=kontrolle&amp;step=4")) {
        this.activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        Log.d("WebView", "should hide now!");
        //view = activity.findViewById(android.R.id.content);
        //InputMethodManager imm =(InputMethodManager) this.activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        //imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        //this.activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        //this.activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

    }

}
&lt;activity
        android:name=".activity.MainActivity"
        android:windowSoftInputMode="stateHidden" /&gt;
InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//hide keboard:
imm.hideSoftInputFromWindow(myEditText.getWindowToken(), 0);
//and for show keyboard
imm.showSoftInput(myEditText, InputMethodManager.SHOW_IMPLICIT);
WebView webview = new WebView(context);
webview.setWebViewClient(new WebViewClient()
        {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);

            Log.d("WebView", "your current url when webpage loading.." + url);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            Log.d("WebView", "your current url when webpage loading.. finish" + url);
            super.onPageFinished(view, url);
        }

        @Override
        public void onLoadResource(WebView view, String url) {
            // TODO Auto-generated method stub
            super.onLoadResource(view, url);
        }
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            System.out.println("when you click on any interlink on webview that time you got url :-" + url);
//compare here your URL and hide keyboard
            return super.shouldOverrideUrlLoading(view, url);
        }
    });
public static void hideSoftKeyboard(Activity activity) {
    if (activity != null &amp;&amp; activity.getCurrentFocus() != null) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);

    }

}
public static void forceHideKeyboard(Activity activity, EditText editText) {
    try {

        if (editText == null) return;

        if (activity.getCurrentFocus() == null
                || !(activity.getCurrentFocus() instanceof EditText)) {
            editText.requestFocus();
        }

        InputMethodManager imm = (InputMethodManager) activity
                .getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        activity.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);


    } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
}
