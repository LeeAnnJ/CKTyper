secondText.setInputType(InputType.TYPE_NULL);
InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
imm.hideSoftInputFromWindow(secondText.getWindowToken(), InputMethodManager.HIDE_IMPLICIT_ONLY);
 OnTouchListener otl = new OnTouchListener() {
      @Override
      public boolean onTouch(View v, MotionEvent event) {
          switch (event.getAction()) {
          case MotionEvent.ACTION_DOWN:
              Layout layout = ((EditText) v).getLayout();
              float x = event.getX() + secondText.getScrollX();
              int offset = layout.getOffsetForHorizontal(0, x);
              if(offset&gt;0)
                  if(x&gt;layout.getLineMax(0))
                      secondText.setSelection(offset);     // touch was at end of text
                  else
                      secondText.setSelection(offset - 1);
              break;
              }
          return true;
          }
      };
      secondText.setOnTouchListener(otl);
 public static void hide_keyboard(Activity activity) {
    InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
    View view = activity.getCurrentFocus();
    if (view == null) 
        view = new View(activity);
    inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
}
