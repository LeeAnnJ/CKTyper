public class hell extends View{


public static int width= aktivita.width;    
public static int koeficient = 5;

final Paint mPaint;

public static int t;
public boolean filter = true;
static ArrayList&lt;Circle&gt; mCircles;


private static boolean Kontroler = true;





public void draw(Canvas canvas) {

     Paint p = new Paint();

     p.setColor(Color.RED);


            kres(canvas);


            invalidate();
        }
    }




public krouzky(Context context, AttributeSet atrs) {
    super(context, atrs);

    mMalovani = new Paint();
    mMalovani.setColor(Color.RED);
    mMalovani.setAntiAlias(true);

        createCircles();

}
public static void Prid() {

     int ran = aktivita.width/8;

    mCircles.add(new Circle(80, 200, ran));

}
private static void createCircles() { if (mCircles == null) { mCircles = new ArrayList&lt;Circle&gt;(); }

 int r = aktivita.width/8;
mCircles.add(new Circle(80, 200, r));

}
        for (Circle c : mCircles) {
            // 
            canvas.drawCircle(c.getCurrentX(), c.getCurrentY(), c.getRadius(),
                    mPaint);


        }
        }
 public static Bitmap loadBitmapFromView(View view) {

        // width measure spec 
        int widthSpec = View.MeasureSpec.makeMeasureSpec(
                view.getMeasuredWidth(), View.MeasureSpec.AT_MOST);
        // height measure spec 
        int heightSpec = View.MeasureSpec.makeMeasureSpec(
                view.getMeasuredHeight(), View.MeasureSpec.AT_MOST);
        // measure the view 
        view.measure(widthSpec, heightSpec);
        // set the layout sizes 
        view.layout(view.getLeft(), view.getTop(), view.getMeasuredWidth() + view.getLeft(), view.getMeasuredHeight() + view.getTop());
        // create the bitmap
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        // create a canvas used to get the view's image and draw it on the bitmap 
        Canvas c = new Canvas(bitmap);
        // position the image inside the canvas 
        c.translate(-view.getScrollX(), -view.getScrollY());
        // get the canvas
        view.draw(c);

        return bitmap;
}

    public void save(){
 String fileName = String.valueOf(Calendar.getInstance().getTimeInMillis());
// generate the image path 
String imagePath = Environment.getExternalStorageDirectory().toString() + File.separator +  fileName + ".png";

 try {

     // save the image as png 
    FileOutputStream out = new FileOutputStream(imagePath);
    View view = null;
    // compress the image to png and pass it to the output stream 
    loadBitmapFromView(view).compress(Bitmap.CompressFormat.PNG, 90, out);

   // save the image 
   out.flush();
   out.close();

} catch (Exception error) {
      Log.e("Error saving image", error.getMessage());
}

    }
public static Bitmap getBitmapFromView(View view) {
    Bitmap returnedBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(),Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(returnedBitmap);
    Drawable bgDrawable =view.getBackground();
    if (bgDrawable!=null) 
        bgDrawable.draw(canvas);
    else 
        canvas.drawColor(Color.WHITE);
    view.draw(canvas);
    return returnedBitmap;
}
public void saveImage(Bitmap b)
{
    String path = Environment.getExternalStorageDirectory().toString();
    OutputStream fOut = null;

    File file = new File(path, "XXXXXXXXXXX.jpg");
    fOut = new FileOutputStream(file);

    b.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
    fOut.flush();
    fOut.close();
    MediaStore.Images.Media.insertImage(getContentResolver(),file.getAbsolutePath(),file.getName(),file.getName());
}
public void saveImage(Bitmap b)
{
    String path = Environment.getExternalStorageDirectory().toString();
    OutputStream fOut = null;

    File file = new File(path, "XXXXXXXXXXX.jpg");
    Log.d("saveImage", "File to save: " + file.getAbsolutePath());

    try {
        FileOutputStream fOut = new FileOutputStream(file);
    }
    catch(FileNotFoundException e) {
        Log.d("saveImage", "Couldn't open file: " + e.getMessage());
    }

    if(fOut != null) {
        b.compress(Bitmap.CompressFormat.JPEG, 85, fOut);
        fOut.flush();
        fOut.close();
        MediaStore.Images.Media.insertImage(getContentResolver(),file.getAbsolutePath(),file.getName(),file.getName());
    }
}
