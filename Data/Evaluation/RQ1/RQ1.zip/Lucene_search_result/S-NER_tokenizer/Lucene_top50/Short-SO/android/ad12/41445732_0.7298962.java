public class Controller extends Activity {

private String TAG = Controller.class.getSimpleName();
private String http;
CustomAdapter adapter;
public Controller con = null;
private ListView lv;
private static String url;
ArrayList&lt;Selfservice&gt; linkList = new ArrayList&lt;Selfservice&gt;();

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main_view);
    con = this;
    http = this.getString(R.string.http);
    url = this.getString(R.string.path1);

    new GetLinks().execute();

    lv = (ListView)findViewById(R.id.list);

    //Resources res = getResources();
    //adapter = new CustomAdapter(con, linkList, res);
    //lv.setAdapter(adapter);
}

private class GetLinks extends AsyncTask&lt;Void, Void, List&lt;Selfservice&gt;&gt; {

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }

    @Override
    protected List&lt;Selfservice&gt; doInBackground(Void... arg0) {
                Document doc;
                Elements links;
                List&lt;Selfservice&gt; returnList = null;
                try {
                    doc = Jsoup.connect(url).timeout(0).get();
                    links = doc.getElementsByClass("processlink");
                    returnList = ParseHTML(links);
                } catch (IOException e) {
                    e.printStackTrace();
                }

        return returnList;
    }

    @Override
    protected void onPostExecute(final List&lt;Selfservice&gt; result) {
        super.onPostExecute(result);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
                //setSupportActionBar(toolbar);
                //getSupportActionBar().setDisplayShowTitleEnabled(false);
                toolbar.setTitle("");
                toolbar.setSubtitle("");
                Resources res = getResources();
                Log.e(TAG, linkList.toString());
                linkList = (ArrayList&lt;Selfservice&gt;) result;
                adapter = new CustomAdapter(con, result, res);
                adapter.notifyDataSetChanged();
                lv.setAdapter(adapter);
            }
        });

    }

}
public class CustomAdapter extends BaseAdapter implements OnClickListener {
private String TAG = CustomAdapter.class.getSimpleName();
Context context;
List&lt;Selfservice&gt; data;
private Activity activity;
public Resources res;
Selfservice self = null;
private static LayoutInflater inflater;
int layoutResourceId = 0;

public CustomAdapter(Activity act, List&lt;Selfservice&gt; dataList, Resources resources) {

    res = resources;
    activity = act;
    data = dataList;

}

private class Holder {
    TextView title;
    TextView link;
}

@Override
public int getCount() {

    return data.size();
}

@Override
public Object getItem(int pos) {
    return pos;
}

@Override
public long getItemId(int pos) {
    return pos;
}

@Override
public View getView(int position, View convertView, ViewGroup parent) {

    LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    View rowView = convertView;
    Holder holder;

    if(rowView == null){


        rowView = inflater.inflate(R.layout.list_item, null);
        holder = new Holder();
        holder.title = (TextView) rowView.findViewById(R.id.title);
        holder.link = (TextView) rowView.findViewById(R.id.link);

        rowView.setTag(holder);


    }else{
        holder = (Holder)rowView.getTag();
    }
    if(data.size()&lt;=0){
        holder.title.setText("did not work");
    }else{
        self = null;
        self = (Selfservice) data.get(position);
        holder.title.setText(self.getTitle());
        holder.link.setText(self.getLink());
        Log.i(TAG, "adapter");
        rowView.setOnClickListener(new OnItemClickListener(position));
    }

    return rowView;
    }
@Override
public void onClick(View v){
    Log.v("CustomAdapter", "row clicked");
}

private class OnItemClickListener implements OnClickListener{
    private int mPos;

    OnItemClickListener(int position){
        mPos = position;
    }
    @Override
    public void onClick(View arg0){
        Controller con = (Controller)activity;
        con.onItemClick(mPos);
    }
    }
}
