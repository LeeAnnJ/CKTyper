import android.os.Parcel;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;


public class FieldData implements Parcelable {
private Integer id;
private String value;
private Integer job_transaction_id;
private Integer field_attribute_master_id;
private Boolean required;
private View view;
private String viewType;

public Integer getId() {
    return id;
}

public void setId(Integer id) {
    this.id = id;
}

public String getValue() {
    return value;
}

public void setValue(String value) {
    this.value = value;
}

public Integer getJob_transaction_id() {
    return job_transaction_id;
}

public void setJob_transaction_id(Integer job_transaction_id) {
    this.job_transaction_id = job_transaction_id;
}

public Integer getField_attribute_master_id() {
    return field_attribute_master_id;
}

public void setField_attribute_master_id(Integer field_attribute_master_id) {
    this.field_attribute_master_id = field_attribute_master_id;
}

public Boolean getRequired() {
    return required;
}

public void setRequired(Boolean required) {
    this.required = required;
}

public View getView() {
    return view;
}

public void setView(View view) {
    this.view = view;
}

public String getViewType() {
    return viewType;
}

public void setViewType(String viewType) {
    this.viewType = viewType;
}



protected FieldData(Parcel in) {
    id = in.readByte() == 0x00 ? null : in.readInt();
    value = in.readString();
    job_transaction_id = in.readByte() == 0x00 ? null : in.readInt();
    field_attribute_master_id = in.readByte() == 0x00 ? null : in.readInt();
    byte requiredVal = in.readByte();
    required = requiredVal == 0x02 ? null : requiredVal != 0x00;
    view = (View) in.readValue(View.class.getClassLoader());
    viewType = in.readString();
}

public FieldData() {
    // TODO Auto-generated constructor stub
}

@Override
public int describeContents() {
    return 0;
}

@Override
public void writeToParcel(Parcel dest, int flags) {
    if (id == null) {
        dest.writeByte((byte) (0x00));
    } else {
        dest.writeByte((byte) (0x01));
        dest.writeInt(id);
    }
    dest.writeString(value);
    if (job_transaction_id == null) {
        dest.writeByte((byte) (0x00));
    } else {
        dest.writeByte((byte) (0x01));
        dest.writeInt(job_transaction_id);
    }
    if (field_attribute_master_id == null) {
        dest.writeByte((byte) (0x00));
    } else {
        dest.writeByte((byte) (0x01));
        dest.writeInt(field_attribute_master_id);
    }
    if (required == null) {
        dest.writeByte((byte) (0x02));
    } else {
        dest.writeByte((byte) (required ? 0x01 : 0x00));
    }
    **dest.writeValue(view);**//Error at this line
    dest.writeString(viewType);
}

@SuppressWarnings("unused")
public static final Parcelable.Creator&lt;FieldData&gt; CREATOR = new Parcelable.Creator&lt;FieldData&gt;()      {
    @Override
    public FieldData createFromParcel(Parcel in) {
        return new FieldData(in);
    }

    @Override
    public FieldData[] newArray(int size) {
        return new FieldData[size];
    }
};
