public static void showSoftKeyboard(Context context, View view) {
    final InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);        
    imm.showSoftInputFromInputMethod(view.getWindowToken(), 0);
}
