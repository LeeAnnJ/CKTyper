public static double calcPathLength(List&lt;Vector3D&gt; path){
    double length = 0d;
    for (int i=0; i&lt; path.size()-1; i++){
        length += path.get(i).distance(path.get(i+1));
    }
    return length;
}
class DistanceHelper {
    private double sum = 0;
    private Vector3D first = null;
    private Vector3D last = null;

    public void add(Vector3D vector3d) {
        if (first == null)
            first = vector3d;
        if (last != null)
            sum += vector3d.distance(last);
        last = vector3d;
    }

    public void combine(DistanceHelper otherHelper) {
        //add distance of path from current thread with distance of path
        //from other thread
        sum += otherHelper.sum;
        //also add distance between paths handled by separate threads like
        // when path of Thread1 is A-&gt;B and Thread2 is C-&gt;D then we need to 
        // include path from `B` to `C`
        if (this.last!=null &amp;&amp; otherHelper.first!=null)
            sum += this.last.distance(otherHelper.first);
        this.last = otherHelper.last;
    }

    public double getSum() {
        return sum;
    }
}
double sum = list
        .stream()//or parallelStream()
        .collect(DistanceHelper::new, DistanceHelper::add,
                DistanceHelper::combine).getSum();
public class Distance implements Collector&lt;Vector3D, Distance.Helper, Double&gt; {

    public static final Distance COLLECTOR = new Distance();

    static final class Helper {
        private double sum = 0;
        private Vector3D first = null, previous = null;
    }
    public Set&lt;Characteristics&gt; characteristics() {
        return Collections.emptySet();
    }
    public Supplier&lt;Helper&gt; supplier() {
        return Helper::new;
    }
    public BiConsumer&lt;Helper, Vector3D&gt; accumulator() {
        return (helper,vector3d)-&gt; {
            if (helper.previous != null)
                helper.sum += vector3d.distance(helper.previous);
            else helper.first = vector3d;
            helper.previous = vector3d;
        };
    }
    public BinaryOperator&lt;Helper&gt; combiner() {
        return (h1,h2)-&gt; {
            h2.sum += h1.sum;
            if(h1.previous!=null &amp;&amp; h2.first!=null) {
                h2.sum += h1.previous.distance(h2.first);
                h2.first=h1.first;
            }
            return h2;
        };
    }
    public Function&lt;Helper, Double&gt; finisher() {
        return helper -&gt; helper.sum;
    }
}
List&lt;Vector3D&gt; list;
//…
double distance=list.stream().collect(Distance.COLLECTOR);
