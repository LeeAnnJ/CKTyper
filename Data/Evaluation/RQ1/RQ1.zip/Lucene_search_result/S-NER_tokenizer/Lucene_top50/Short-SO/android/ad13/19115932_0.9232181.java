private static final String[] PRIMARY_PROJECTION = new String[] {
        CategoryPrimary.Columns._ID, CategoryPrimary.Columns.VALUE,
        CategoryPrimary.Columns.KEY };
private static final String[] SUBCATEGORY_PROJECTION = new String[] {
        CategorySub.Columns._ID, CategorySub.Columns.VALUE,
        CategorySub.Columns.KEY, CategorySub.Columns.STATUS };
mAdapter = new MyExpandableListAdapter(
            mActivity,
            R.layout.category_group,
            R.layout.category_items,
            new String[] { CategoryPrimary.Columns.VALUE }, // Name for
                                                            // group layouts
            new int[] { R.id.lblListHeader },
            new String[] { CategorySub.Columns.VALUE }, // Number for child
                                                        // layouts
            new int[] { R.id.lblListItem });
R.layout.category_group,
R.layout.category_items,
     public class CategoryFragment extends Fragment implements OnGroupClickListener,
    OnGroupExpandListener, OnGroupCollapseListener, OnChildClickListener {

private static final String[] PRIMARY_PROJECTION = new String[] {
        CategoryPrimary.Columns._ID, CategoryPrimary.Columns.VALUE,
        CategoryPrimary.Columns.KEY };
// private static final int GROUP_ID_COLUMN_INDEX = 0;

private static final String[] SUBCATEGORY_PROJECTION = new String[] {
        CategorySub.Columns._ID, CategorySub.Columns.VALUE,
        CategorySub.Columns.KEY, CategorySub.Columns.STATUS };
private static final int TOKEN_GROUP = 0;
private static final int TOKEN_CHILD = 1;
private QueryHandler mQueryHandler;
private CursorTreeAdapter mAdapter;
private ExpandableListView expandableListView;
private SocialEyePlusActivity mActivity;
DealFragment dealFragment;

private static final class QueryHandler extends AsyncQueryHandler {

    private CursorTreeAdapter mAdapter;

    public QueryHandler(Context context, CursorTreeAdapter adapter) {
        super(context.getContentResolver());
        this.mAdapter = adapter;
    }

    @Override
    protected void onQueryComplete(int token, Object cookie, Cursor cursor) {
        switch (token) {
        case TOKEN_GROUP:
            mAdapter.setGroupCursor(cursor);
            break;

        case TOKEN_CHILD:
            int groupPosition = (Integer) cookie;
            mAdapter.setChildrenCursor(groupPosition, cursor);
            break;
        }
    }
}

public class MyExpandableListAdapter extends SimpleCursorTreeAdapter {

    public MyExpandableListAdapter(Context context, int groupLayout,
            int childLayout, String[] groupFrom, int[] groupTo,
            String[] childrenFrom, int[] childrenTo) {

        super(context, null, groupLayout, groupFrom, groupTo, childLayout,
                childrenFrom, childrenTo);
    }

    @Override
    protected Cursor getChildrenCursor(Cursor groupCursor) {
        String primaryValue = groupCursor.getString(groupCursor
                .getColumnIndex(CategoryPrimary.Columns.VALUE));
        final String selection = CategorySub.Columns.PRIMARYCATEGORY
                + " ='" + primaryValue + "'";
        mQueryHandler.startQuery(TOKEN_CHILD, groupCursor.getPosition(),
                CategorySub.CONTENT_URI, SUBCATEGORY_PROJECTION, selection,
                null, null);

        return null;
    }

    @Override
    protected void bindGroupView(View view, Context context, Cursor cursor,
            boolean isExpanded) {
        super.bindGroupView(view, context, cursor, isExpanded);
        TextView lblListHeader = (TextView) view
                .findViewById(R.id.lblListHeader);
        lblListHeader.setTypeface(null, Typeface.BOLD);
        if (cursor.getPosition() % 2 != 0) {
            lblListHeader
                    .setBackgroundResource(R.drawable.group_normal_first);

        } else {
            lblListHeader
                    .setBackgroundResource(R.drawable.group_normal_second);
        }
    }

    @Override
    public View getChildView(int groupPosition, int childPosition,
            boolean isLastChild, View convertView, ViewGroup parent) {
        TextView txtListChild = (TextView) super.getChildView(
                groupPosition, childPosition, isLastChild, convertView,
                parent);

        if (groupPosition % 2 == 0) {
            if (childPosition == 0) {
                txtListChild
                        .setBackgroundResource(R.drawable.group_child_button_red);
            } else {
                txtListChild
                        .setBackgroundResource(R.drawable.group_childbutton);
            }
        } else {

            if (childPosition == 0) {
                txtListChild
                        .setBackgroundResource(R.drawable.group_child_button_blue);
            } else {
                txtListChild
                        .setBackgroundResource(R.drawable.group_childbutton);
            }
        }
        return txtListChild;
    }

}

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    dealFragment = (DealFragment)getParentFragment();
}

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
    View view = inflater.inflate(R.layout.fragment_category, container,
            false);
    expandableListView = (ExpandableListView) view
            .findViewById(R.id.category_listview);
    expandableListView.setOnGroupClickListener(this);
    expandableListView.setOnGroupExpandListener(this);
    expandableListView.setOnGroupCollapseListener(this);
    expandableListView.setOnChildClickListener(this);

    mAdapter = new MyExpandableListAdapter(
            mActivity,
            R.layout.category_group,
            R.layout.category_items,
            new String[] { CategoryPrimary.Columns.VALUE }, // Name for
                                                            // group layouts
            new int[] { R.id.lblListHeader },
            new String[] { CategorySub.Columns.VALUE }, // Number for child
                                                        // layouts
            new int[] { R.id.lblListItem });
    expandableListView.setDividerHeight(0);
    expandableListView.setAdapter(mAdapter);
    mQueryHandler = new QueryHandler(mActivity, mAdapter);
    mQueryHandler.startQuery(TOKEN_GROUP, null,
            CategoryPrimary.CONTENT_URI, PRIMARY_PROJECTION, null, null,
            null);
    return view;
}

@Override
public void onAttach(Activity activity) {
    super.onAttach(activity);
    if (mActivity == null) {
        mActivity = (SocialEyePlusActivity) activity;
    }
}

@Override
public boolean onChildClick(ExpandableListView parent, View v,
        int groupPosition, int childPosition, long id) {
    Log.d("OnCliekd is Clicked", ""+groupPosition);
    Log.d("OnCliekd is Clicked", ""+childPosition);
    DealSubCatgFragment dealsSubListFragment = DealSubCatgFragment.newInstance("1","109");
    dealFragment.containerFragment.replaceFragment(dealsSubListFragment, true, true);

    return false;
}

@Override
public void onGroupCollapse(int arg0) {

}

@Override
public void onGroupExpand(int arg0) {

}

@Override
public boolean onGroupClick(ExpandableListView arg0, View view, int arg2,
        long arg3) {

    return false;
}

}
