protected void bindHttpService(HttpService httpService) 
{
        httpService.registerResources("/testServer/resources", "/resources", null);
        httpService.registerResources("/testServer/pictures", "C:\\mypath\\config\\", null);
