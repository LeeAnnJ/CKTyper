    LayoutInflater inflater = (LayoutInflater) getApplicationContext()
            .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    marker=inflater.inflate(R.layout.custom_marker_layout,null, false);

     numTxt = (TextView) marker.findViewById(R.id.num_txt);

        for(int i=0;i&lt;locations.size();i++){

            numTxt.setText(count.get(i).toString());

            numTxt.setTextColor(Color.GREEN);

            if(Integer.parseInt(count.get(i).toString())&lt;=5){
                numTxt.setTextColor(Color.RED);
            }

            String title=locations.get(i).toString()+"count"+count.get(i);

            Currnt=mMap.addMarker(new MarkerOptions()
            .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(BasicMapActivity2.this, marker))).
            position(new LatLng(Double.parseDouble(latitudes.get(i).toString()), Double.parseDouble(longitudes.get(i).toString())))
            .title(title)
            .snippet(address.get(i)));
            markers.add(Currnt);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(Double.parseDouble(latitudes.get(i).toString()), Double.parseDouble(longitudes.get(i).toString())), 12.0f));        
        }
// Convert a view to bitmap
    public static Bitmap createDrawableFromView(Context context, View view) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((BasicMapActivity2)context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        view.setLayoutParams(new LayoutParams(200,65));
        view.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.buildDrawingCache();
        view.buildDrawingCache(true);

        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmap);

        view.draw(canvas);

        return bitmap;
    }
&lt;?xml version="1.0" encoding="utf-8"?&gt;
&lt;FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:gravity="center_vertical|center_horizontal" &gt;

&lt;ImageView
    android:id="@+id/img"
    android:layout_width="55dp"
    android:layout_height="65dp"
    android:src="@drawable/custom_marker" /&gt;

&lt;TextView
    android:id="@+id/num_txt"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:text="9"
    android:textColor="#008000"
    android:textSize="18dp"
    android:textStyle="bold" /&gt;

&lt;/FrameLayout&gt;
