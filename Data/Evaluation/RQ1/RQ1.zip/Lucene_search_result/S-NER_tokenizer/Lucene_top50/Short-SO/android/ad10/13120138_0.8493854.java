Bitmap screenshot;                  
screenshot = Bitmap.createBitmap(view.getWidth(), view.getContentHeight(), Bitmap.Config.ARGB_8888);
final Canvas c =new Canvas(screenshot);
view.draw(c);
    webview.setDrawingCacheEnabled(true);
    Bitmap bitmap = Bitmap.createBitmap(webview.getDrawingCache());
    webview.setDrawingCacheEnabled(false);
web.setPictureListener(new WebView.PictureListener() {

        public void onNewPicture(WebView view, Picture picture) {
            float temp = (float) view.getHeight();
            height = view.getContentHeight() * a;
        }

    });
