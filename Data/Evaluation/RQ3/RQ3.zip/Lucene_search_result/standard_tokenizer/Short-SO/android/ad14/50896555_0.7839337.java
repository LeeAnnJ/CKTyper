InputMethodManager imm = (InputMethodManager) getActivity(mContext).getSystemService(Context.INPUT_METHOD_SERVICE);
if (imm.isActive()){ 
imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0); // hide
} else {
imm.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY); // show
}
