private int resource; 

public ToDoItemAdapter(Context context, int resource, ArrayList&lt;ToDoItem&gt; objects) { 

    super(context, resource, objects); // TODO Auto-generated constructor stub 
    this.resource = resource;
} 

@Override 
public View getView(int position, View convertView, ViewGroup parent) { 
    // TODO Auto-generated method stub 

    LinearLayout todoView; 
    ToDoItem todo = getItem(position); 
    String taskString = todo.getTask(); 
    String dateString = todo.getDeadline(); 
    String priorityString = todo.getPriority(); 

    if (convertView == null) 
    { 
        todoView = new LinearLayout(getContext()); 
        String inflater = Context.LAYOUT_INFLATER_SERVICE; 
        LayoutInflater li; 
        li = (LayoutInflater)getContext().getSystemService(inflater); 
        li.inflate(resource, todoView, true); 
    } 
    else 
    { 
        todoView = (LinearLayout) convertView; 
    } 

    TextView taskView = (TextView) todoView.findViewById(R.id.edit_text_task2); 
    TextView dateView = (TextView) todoView.findViewById(R.id.EditText02); 
    TextView priorityView = (TextView) todoView.findViewById(R.id.priority_spinner2); 
    taskView.setText(taskString); 
    dateView.setText(dateString); 
    priorityView.setText(priorityString); 
    return todoView; 
} 
