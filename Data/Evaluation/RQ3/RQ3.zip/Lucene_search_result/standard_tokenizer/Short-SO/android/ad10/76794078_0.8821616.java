private void generatePdfFromView(View view) {

    Bitmap bitmap = getBitmapFromView(view);
    document = new PdfDocument();

    PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(view.getWidth(),view.getHeight(),1).create();
    PdfDocument.Page myPage = document.startPage(myPageInfo);
    Canvas canvas = myPage.getCanvas();
    canvas.drawBitmap(bitmap,0,0,null);

    document.finishPage(myPage);

    PdfDocument.PageInfo myPageInfo1 = new PdfDocument.PageInfo.Builder(view.getWidth(),view.getHeight(),2).create();
    PdfDocument.Page myPage1 = document.startPage(myPageInfo1);
    Canvas canvas1 = myPage1.getCanvas();
    canvas1.drawBitmap(bitmap,0,0,null);
    document.finishPage(myPage1);
    createFile();
}
    
    
private Bitmap getBitmapFromView(View view) {

    Bitmap returnedBitmap = Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(returnedBitmap);

    Drawable bgDrawable = view.getBackground();
    if (bgDrawable != null){
        bgDrawable.draw(canvas);
    } else {
        canvas.drawColor(Color.WHITE);
    }
    view.draw(canvas);

    return returnedBitmap;
}
