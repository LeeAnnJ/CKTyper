InputMethodManager mgr = (InputMethodManager) view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
mgr.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
