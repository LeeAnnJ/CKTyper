public static void hideSoftKeyboard(Context context){
    InputMethodManager inputMethodManager = (InputMethodManager) context
            .getSystemService(Activity.INPUT_METHOD_SERVICE);
    inputMethodManager.hideSoftInputFromWindow(context.getCurrentFocus()
            .getWindowToken(), 0);
}
