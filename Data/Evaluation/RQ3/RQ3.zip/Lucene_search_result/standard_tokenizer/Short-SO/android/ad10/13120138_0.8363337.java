Bitmap screenshot;                  
screenshot = Bitmap.createBitmap(view.getWidth(), view.getContentHeight(), Bitmap.Config.ARGB_8888);
final Canvas c =new Canvas(screenshot);
view.draw(c);
