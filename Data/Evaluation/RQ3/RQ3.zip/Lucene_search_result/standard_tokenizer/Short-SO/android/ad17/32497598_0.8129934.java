  public class ListAdapter extends ArrayAdapter&lt;ParseUser&gt; {
private  Context context;
public ListAdapter(Context context, int resource, List&lt;ParseUser&gt; user1) {
    super(context, resource, user1);
}

@Override
public View getView(int position, View convertView, ViewGroup parent) {
    View v = convertView;
    if (v == null) {
        LayoutInflater vi;
        vi = LayoutInflater.from(getContext());
        v = vi.inflate(R.layout.list_item_layout, null);
    }

    final ParseUser p = (ParseUser) getItem(position);

    if(p!=null){
        TextView username = (TextView)v.findViewById(R.id.username);
        TextView bloodType = (TextView)v.findViewById(R.id.bloodtype);
        //TextView longitude = (TextView)v.findViewById(R.id.longitude);
        //TextView latitude = (TextView)v.findViewById(R.id.latitude);
        //TextView mobile = (TextView)v.findViewById(R.id.mobile);
        Button msgButton = (Button)v.findViewById(R.id.message_me);
        final String number = p.getString("Mobile");

        if(username!=null){
            username.setText(p.getString("Name"));
        }
        if(bloodType!=null){
            bloodType.setText(p.getString("Bloodtype"));
        }

        msgButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a = new Intent(getContext(),SmsActivity.class);
                a.putExtra("number",number);
                context.startActivity(a);

            }
        });
    }



    return v;
}
}
