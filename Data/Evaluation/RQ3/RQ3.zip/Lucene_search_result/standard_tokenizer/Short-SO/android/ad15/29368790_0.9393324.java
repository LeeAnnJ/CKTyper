public class Calculated extends Activity {

TextView mTextview;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.calculated);

       mTextview = (TextView)findViewById(R.id.textView1);

       mTextview.setText(getIntent().getStringExtra("mytext"));
}
