@OnClick(R.id.root_view)
public void onRootViewClick() {
    if (mInput != null) {
        mInput.setFocusableInTouchMode(true);
        mInput.requestFocus();
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        if(inputMethodManager != null)
        inputMethodManager.showSoftInput(mInput, InputMethodManager.SHOW_IMPLICIT);
    }
}
