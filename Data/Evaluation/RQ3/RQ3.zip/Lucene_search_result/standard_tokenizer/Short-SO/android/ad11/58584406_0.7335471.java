StringBuilder buf = new StringBuilder();
for (String s : input)
    buf.append(s);
String joined = buf.toString();
