public void openWindowOnButtonClick() {
    view = (TextureView) findViewById(R.id.textureView);
    view.setSurfaceTexture(new SurfaceTexture(GLES20.GL_ACTIVE_TEXTURE));
    view.getSurfaceTexture().detachFromGLContext();
    FloatingActionButton fb = (FloatingActionButton) findViewById(R.id.floatingActionButton);
    final InputMethodManager keyboard = (InputMethodManager) getSystemService(getBaseContext().INPUT_METHOD_SERVICE);
    fb.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // check if the Overlay should be visible. If this value is true, it is not shown -&gt; show it.
            if (view.getVisibility() == View.INVISIBLE) {
                view.setVisibility(View.VISIBLE);
                view.bringToFront();
                view.getParent().requestLayout();
                ((View)view.getParent()).invalidate();
                keyboard.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
            } else {
                view.setVisibility(View.INVISIBLE);
                keyboard.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY);
            }
        }
    });
}
