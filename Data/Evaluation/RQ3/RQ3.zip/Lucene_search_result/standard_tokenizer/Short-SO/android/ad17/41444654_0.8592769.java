public class Niveauview extends RelativeLayout {

public TextView musiqueView = new TextView(getContext()), artisteView = new TextView(getContext());
public ImageView coverView = new ImageView(getContext()), carapaceView = new ImageView(getContext());

public Niveauview(Context context){
    super(context);
}

public void init(int cover, int musique,int artiste){

    coverView = (ImageView)findViewById(R.id.cover);
    coverView.setImageResource(cover);

    musiqueView = (TextView)findViewById(R.id.musique);
    musiqueView.setText(musique);


    artisteView = (TextView)findViewById(R.id.artiste);
    artisteView.setText(artiste);

    carapaceView = (ImageView) findViewById(R.id.carapace);
    carapaceView.setImageResource(R.drawable.carapacevide);
}}
