showToast(this, "your message");

public static void showToast(Activity activity, String msg)
{
    try
    {
        Toast toast = Toast.makeText(activity, msg, Toast.LENGTH_LONG);
        toast.getView().setBackgroundColor(activity.getResources().getColor(R.color.purple_dark));
        toast.show();
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }
}
