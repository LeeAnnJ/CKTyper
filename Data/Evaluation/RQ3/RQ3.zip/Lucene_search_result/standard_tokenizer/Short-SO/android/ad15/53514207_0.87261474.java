private TextView mTextView= (TextView) findViewById(R.id.WelText);


@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    mTextView = (TextView) findViewById(R.id.text);

    // Enables Always-on
    setAmbientEnabled();

    final TextView textView=(TextView) findViewById(R.id.WelText);

    Thread t = new Thread(){
        @Override
        public void run(){
            boolean processing = true;
            int number_processed=0;
            do {
                mTextView.setText("Text 1");
                try {
                    Thread.sleep(500);
                    if (++number_processed&gt;6)
                        processing=false;
                } catch (InterruptedException e) {
                    e.printStackTrace( );
                } finally {
                    mTextView.setText("Text 2");
                }
            } while(processing);
            mTextView.setText("Text3");

            }

    };


    };
}
