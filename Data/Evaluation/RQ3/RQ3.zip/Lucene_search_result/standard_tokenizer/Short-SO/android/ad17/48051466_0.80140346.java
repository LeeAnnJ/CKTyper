public class SyAdapter extends ArrayAdapter&lt;ArrayList&gt; {
Typeface bahn = Typeface.createFromAsset(getContext().getAssets(), "fonts/bahnschrift.ttf");
Typeface ih = Typeface.createFromAsset(getContext().getAssets(), "fonts/corbel.ttf");

private static class ViewHolder {
    TextView Merkmal;
    TextView Inhalt;
}

ArrayList MerkmaleArr;
ArrayList InhalteArr;
public SyAdapter (Context context, ArrayList Merkmale, ArrayList Inhalte) {
    super(context, R.layout.listanzeige, R.id.MerkmalT, Merkmale);
    this.MerkmaleArr = Merkmale;
    this.InhalteArr = Inhalte;
}
@NonNull
@Override
public View getView(int position, View convertView, ViewGroup parent) {
    ViewHolder viewHolder;
    if (convertView == null) {

        viewHolder = new ViewHolder();
        LayoutInflater inflater = LayoutInflater.from(getContext());
        convertView = inflater.inflate(R.layout.listanzeige, parent, false);

        viewHolder.Merkmal = (TextView) convertView.findViewById(R.id.MerkmalT);
        viewHolder.Merkmal.setTypeface(bahn);
        viewHolder.Inhalt = (TextView) convertView.findViewById(R.id.InhaltT);
        viewHolder.Inhalt.setTypeface(ih);

        convertView.setTag(viewHolder);
    } else {
        viewHolder = (ViewHolder) convertView.getTag();
    }
    System.out.println("Aktuelle Position: " + position);
    viewHolder.Inhalt.setText(InhalteArr.get(position).toString());
    viewHolder.Merkmal.setText(MerkmaleArr.get(position).toString());
    return convertView;
}}
