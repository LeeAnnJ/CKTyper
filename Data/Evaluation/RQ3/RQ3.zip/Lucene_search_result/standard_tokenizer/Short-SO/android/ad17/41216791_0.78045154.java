 public class WordsAdapter extends RecyclerView.Adapter&lt;WordsAdapter.ViewHolder&gt; {

        private ArrayList&lt;Words&gt; mWords;
        private Context mContext;

        public WordsAdapter(Context context , ArrayList&lt;Words&gt; words)
        {
            mWords = words;
            mContext = context;
        }
        private Context getContext(){return  mContext;}

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            Context context = parent.getContext();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            View view = inflater.inflate(R.layout.list_item , parent ,false);
            ViewHolder viewHolder = new ViewHolder(view);

            return viewHolder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            Words word = mWords.get(position);

            TextView title = holder.title;
            title.setText(word.getTitle());

            TextView subtitle = holder.subtitle;
            subtitle.setText(word.getSubtitle());

        }

        @Override
        public int getItemCount() {
            return mWords.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder{

            public TextView  title , subtitle;

            public ViewHolder(View itemView) {
                super(itemView);
                title = (TextView) itemView.findViewById(R.id.title);
                subtitle = (TextView) itemView.findViewById(R.id.subtitle);
            }
        }
   }
