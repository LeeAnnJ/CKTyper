public static void showSoftKeyboard(Activity activity) {
    View view = activity.getCurrentFocus();
    InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
    inputManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
}
