private TextView textView;


@Override
protected void onCreate(Bundle savedInstanceState) {
.
.
.
.

textView = (TextView) findViewById(R.id.textView);
Typeface mTextView = Typeface.createFromAsset(getAssets(),"fonts/your_font_style.ttf");
textView.setTypeface(mTextView);
