public class DetailActivity extends AppCompatActivity {
    ImageView mImageView;
    TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        mImageView = (ImageView) findViewById(R.id.imageViewDetail);
        mTextView = (TextView) findViewById(R.id.textViewDetail);
        Bundle mBundle = getIntent().getExtras();
        if (mBundle != null) {
            mImageView.setImageResource(mBundle.getInt("pic"));
            mTextView.setText(mBundle.getString("description"));
        }
    }
}
