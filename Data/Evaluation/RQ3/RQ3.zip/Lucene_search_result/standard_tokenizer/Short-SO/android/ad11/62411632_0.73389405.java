StringBuilder buf = new StringBuilder();
list.forEach(c -&gt; buf.append(c));
String result = buf.toString();
