SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
searchManager.setOnDismissListener(new OnDismissListener() {

    @Override
    public void onDismiss() {
        final InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, 0);
    }
});
