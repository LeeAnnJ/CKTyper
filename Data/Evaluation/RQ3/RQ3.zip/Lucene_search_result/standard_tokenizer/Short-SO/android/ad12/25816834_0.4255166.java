public class TestBackgroundActivity extends Activity {

    public static String LOG_TAG = "[TestBG]";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        resources = new Resources(getApplicationContext());
        LinearLayout mainLayout = (LinearLayout)findViewById(R.id.mainLayout);
        mainLayout.setBackgroundDrawable(resources.getImage(R.drawable.ui));
    }

    @Override
    protected void onDestroy(){
        resources.disposeAll();

        super.onDestroy();
    }

    private Resources resources;
}
