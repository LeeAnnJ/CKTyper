    Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), ARGB_8888);        
    Canvas canvas = new Canvas(bitmap);
    Paint p = new Paint();
    p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DARKEN));
    activity.getWindow().getDecorView().draw(canvas);
    canvas.drawRect(rect,p);
    canvas.save();
