public class ScreenshotTaker {

    private static final String TAG = ScreenshotTaker.class.getSimpleName();

    /**
     * Takes screenshot of given view and saves it in external storage
     * @param view outer most ViewGroup that you want a screenshot of
     * @return File object of saved screenshot in storage
     */
    public static File captureScreenshot(View view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),
                view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        return saveBitmap(view.getContext(),bitmap);
    }

    public interface screenshotFile{
        void onComplete(File file);
    }

    public static void getScreenShotFromView(View view, Window window, screenshotFile callback ) {
        Bitmap bitmap;
        // PixelCopy is available since API 24 but doesn't seem to work 100% until API 29.
        // The build version statement can be adjusted according to how well PixelCopy
        // works in your environment before &quot;P&quot;.
        if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.P) {
            int[] locationOfView = new int[2];
            view.getLocationInWindow(locationOfView);
            Rect rect = new Rect(locationOfView[0], locationOfView[1],
                    locationOfView[0] + view.getWidth(), locationOfView[1] + view.getHeight());

            bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
            try {
                PixelCopy.request(window, rect, bitmap, new PixelCopy.OnPixelCopyFinishedListener() {
                    @Override
                    public void onPixelCopyFinished(int copyResult) {
                        if (copyResult == PixelCopy.SUCCESS) {

                            callback.onComplete(saveBitmap(view.getContext(),bitmap));
                        }
                    }
                }, new Handler()
                );
            }catch (Exception ignored){ }
        }
    }

}
