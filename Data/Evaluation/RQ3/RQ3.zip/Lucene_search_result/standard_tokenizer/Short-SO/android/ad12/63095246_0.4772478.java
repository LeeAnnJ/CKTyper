    Resources resources=getResources();
    DisplayMetrics dm=resources.getDisplayMetrics();
    Configuration conf=resources.getConfiguration();
    conf.setLocale(new Locale(language/*e.g: en for english, ar for arabic ....etc*/));
    resources.updateConfiguration(conf,dm);
