Resources resources = getResources();
Locale locale = resources.getConfiguration().locale;
Configuration config = resources.getConfiguration();
config.locale = locale;
if (Build.VERSION.SDK_INT &gt;= 17) {
    config.setLayoutDirection(locale);
}
resources.updateConfiguration(config, resources.getDisplayMetrics());
