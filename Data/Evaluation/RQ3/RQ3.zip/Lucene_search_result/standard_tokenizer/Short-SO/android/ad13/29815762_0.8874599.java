public void open_keyboard(View view)
{
    message.msg_l(this, "keyboard clicked");
    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
}
