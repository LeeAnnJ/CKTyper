public class LanguageManager {
    private final Context context;
    private final SharedPreferences sharedPreferences;

public LanguageManager(Context context) {
    this.context = context;
    sharedPreferences = context.getSharedPreferences(&quot;LANG&quot;, Context.MODE_PRIVATE);
  }

public void updateResources(String code) {
    Locale locale = new Locale(code);
    Locale.setDefault(locale);
    Resources resources = context.getResources();
    Configuration configuration = resources.getConfiguration();
    configuration.locale = locale;
     resources.updateConfiguration(configuration, resources.getDisplayMetrics());
    setLanguage(code);
   }

public void setLanguage(String code) {
    SharedPreferences.Editor editor = sharedPreferences.edit();
    editor.putString(&quot;lang&quot;, code);
    editor.apply();
    }

public String getLang() {
    return sharedPreferences.getString(&quot;lang&quot;, &quot;en&quot;);
   }
}
