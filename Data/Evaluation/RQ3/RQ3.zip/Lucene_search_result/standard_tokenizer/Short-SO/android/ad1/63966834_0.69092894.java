if(activity != null){
            View view = activity.getCurrentFocus();
            if (view != null){
                InputMethodManager inputManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                if(inputManager != null){
                    inputManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
            }
        }
