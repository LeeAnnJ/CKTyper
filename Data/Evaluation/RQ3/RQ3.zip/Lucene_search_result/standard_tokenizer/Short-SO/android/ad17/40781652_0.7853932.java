private List&lt;VacancyModel&gt; vacancyModelList;
    private LayoutInflater inflater;
    private SQLHelper sqlHelper;

    private static final int TYPE_SEPARATOR = 1;
    private static final int TYPE_ITEM = 0;
    private int rowType;

    public static String saveLastDate;
    private int newRecs = 0;

    public SuitableAdapter(Context context, int resource, List&lt;VacancyModel&gt; objects) {
        super(context, resource, objects);
        vacancyModelList = objects;

        sqlHelper = new SQLHelper(getContext());

        inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @NonNull
    @Override
    public View getView(final int position, View convertView, @NonNull final ViewGroup parent) {
        ViewHolder holder = null;

        rowType = getItemViewType(position);

        if (convertView == null) {
            holder = new ViewHolder();

            switch (rowType) {
                case TYPE_SEPARATOR:
                    convertView = inflater.inflate(R.layout.suitable_separator_layout, null);
                    holder.headerTv = (TextView) convertView.findViewById(R.id.section_header);

                    break;

                case TYPE_ITEM:
                    convertView = inflater.inflate(R.layout.row_layout, null);
                    holder.tvProfession = (TextView) convertView.findViewById(R.id.tvProfession);
                    holder.tvHeader = (TextView) convertView.findViewById(R.id.tvHeader);
                    holder.tvSalary = (TextView) convertView.findViewById(R.id.tvSalary);
                    holder.tvDate = (TextView) convertView.findViewById(R.id.tvPostCr);
                    break;
            }

            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        if (getItemViewType(position) == TYPE_SEPARATOR) {

            holder.headerTv = (TextView) convertView.findViewById(R.id.section_header);

            if (newRecs == 1) {
                holder.headerTv.setText("Новые вакансии");
                newRecs = 0;
            } else {
                holder.headerTv.setText("Ранее просмотренные");
            }
        }

        if (getItemViewType(position) == TYPE_ITEM) {

            final VacancyModel model = vacancyModelList.get(position);

            holder.tvProfession.setText(model.getProfession());
            holder.tvHeader.setText(model.getHeader());
            holder.tvSalary.setText(model.getSalary());
            holder.tvDate.setText(model.getDate());

            Date date;
            try {
                if (saveLastDate == null) {
                    saveLastDate = model.getDate();
                } else {
                    date = stringToDate(saveLastDate);
                    if (date.before(stringToDate(model.getDate()))) {
                        saveLastDate = model.getDate();
                    }
                }

            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return convertView;
    }

    @Override
    public int getItemViewType(int position) {
        if (GlobalData.LoadDate(getContext()) == null) {
            return TYPE_ITEM;
        } else {
            VacancyModel model = getItem(position);

            if (model != null) {
                String newString = model.getDate();
                String lastString = GlobalData.LoadDate(getContext());

                Date newDate = null;
                Date lastDate = null;

                try {
                    newDate = stringToDate(newString);
                    lastDate = stringToDate(lastString);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                assert newDate != null;

                if (newDate.equals(lastDate)) {
                    return TYPE_SEPARATOR;
                } else if (position == 0 &amp;&amp; newDate.after(lastDate)) {
                    newRecs = 1;
                    return TYPE_SEPARATOR;
                } else {
                    return TYPE_ITEM;
                }
            } else {
                return TYPE_ITEM;
            }
        }
    }

    @Override
    public int getViewTypeCount() {
        return 3;
    }

    @Override
    public int getCount() {
        return vacancyModelList.size();
    }

    private Date stringToDate(String string) throws ParseException {
        return new SimpleDateFormat(("yyyy-MM-dd HH:mm:ss"), Locale.getDefault()).parse(string);
    }

    private static class ViewHolder {
        private TextView tvProfession;
        private TextView tvHeader;
        private TextView tvSalary;
        private TextView tvDate;

        private TextView headerTv;
    }
