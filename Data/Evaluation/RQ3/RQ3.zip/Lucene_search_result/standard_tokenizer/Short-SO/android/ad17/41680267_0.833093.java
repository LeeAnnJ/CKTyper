public class MethodTypesAdapter extends ArrayAdapter&lt;PaymentMethod&gt; {
public MethodTypesAdapter(Context context, int resource, ArrayList&lt;PaymentMethod&gt; objects) {
    super(context, 0, objects);
}

@NonNull
@Override
public View getView(int position, View convertView, ViewGroup parent) {
    PaymentMethod paymentMethod = getItem(position);
    Utils utils = new Utils(null);

    if (paymentMethod.getType() == -1) {
        convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_1, null, false);
        TextView name = (TextView) convertView.findViewById(android.R.id.text1);
        name.setText(getContext().getResources().getString(R.string.chooseAMethod));
    } else {

        convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_with_pic, null, false);
        TextView name = (TextView) convertView.findViewById(R.id.itemsName);
        name.setText(paymentMethod.getName());
        ImageView icon = (ImageView) convertView.findViewById(R.id.itemsIcon);
        icon.setImageResource(utils.methodTypeIcons()[position]);
    }


    return convertView;
}
}
