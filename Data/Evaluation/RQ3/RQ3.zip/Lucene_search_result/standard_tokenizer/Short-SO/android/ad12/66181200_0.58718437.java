public void setLocale(String language) {
    Locale locale = new Locale(language);
    Locale.setDefault(locale); // changes the languages
    Resources resources = getBaseContext().getResources();
    Configuration config = resources.getConfiguration();
    config.setLocale(locale);
    resources.updateConfiguration(config, resources.getDisplayMetrics());
    this.recreate(); // re-launches the app
}
