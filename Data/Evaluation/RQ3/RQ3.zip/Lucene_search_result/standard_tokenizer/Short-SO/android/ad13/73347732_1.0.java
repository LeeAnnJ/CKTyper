public void toggleSoftInput() {
        InputMethodManager imm = (InputMethodManager) getAndroidContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, InputMethodManager.HIDE_IMPLICIT_ONLY);
        keyboardOpened = !keyboardOpened;
}
