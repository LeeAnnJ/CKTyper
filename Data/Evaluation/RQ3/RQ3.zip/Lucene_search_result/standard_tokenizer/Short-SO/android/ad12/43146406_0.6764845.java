public static Resources getResourcesBasedOnLanguage(Activity activity) {
    Configuration confTmp =new Configuration(activity.getResources().getConfiguration());
    confTmp.locale = new Locale("EN");
    DisplayMetrics metrics = new DisplayMetrics();
    activity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
    return new Resources(activity.getAssets(), metrics, confTmp);
}
