InputMethodManager im = (InputMethodManager)
                                 getSystemService(Context.INPUT_METHOD_SERVICE);
if(im null){
        im.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT, 0);
    }
