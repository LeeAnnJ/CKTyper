Bitmap bitmap = Bitmap.createBitmap(view.getWidth(),
        view.getHeight(), Config.ARGB_8888);
Canvas canvas = new Canvas(bitmap);
view.draw(canvas);
