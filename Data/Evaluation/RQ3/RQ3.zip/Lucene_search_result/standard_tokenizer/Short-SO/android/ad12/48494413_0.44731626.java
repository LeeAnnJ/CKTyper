public class LanguageHelper {
    /**
     * Change locale.
     *
     * @param res    the res
     * @param locale the locale
     */
    public static void changeLocale(Resources res, String locale) {

        Configuration config;
        config = new Configuration(res.getConfiguration());


        switch (locale) {
            case "yourlanguageid":
                config.locale = new Locale("yourlanguageid");
                break;
            case "en":
                config.locale = Locale.ENGLISH;
                break;
        }
        res.updateConfiguration(config, res.getDisplayMetrics());
    }

    public static Locale getLocale(Resources res) {
        Configuration config;
        config = new Configuration(res.getConfiguration());
        return config.locale;
    }
}
