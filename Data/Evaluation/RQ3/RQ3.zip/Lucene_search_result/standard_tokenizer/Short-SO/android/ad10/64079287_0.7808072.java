  val view: View = this.activity.getWindow().getDecorView().getRootView()

        val bitmap = Bitmap.createBitmap(
            view.width,
            view.height,
            Bitmap.Config.ARGB_8888
        ) // Bitmap()


        val canvas = Canvas(bitmap)
        view.draw(canvas) // trace brings me here
