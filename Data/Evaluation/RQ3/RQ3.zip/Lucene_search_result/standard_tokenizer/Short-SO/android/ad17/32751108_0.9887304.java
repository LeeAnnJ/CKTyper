    public View getView(int position, View convertView, final ViewGroup parent) {
    final View vi = inflater.inflate(layoutResource, parent, false);
    TextView tv = (TextView) vi.findViewById(R.id.card_one_line);
    flowLayout = (FlowLayout) vi.findViewById(R.id.flow_container);

    final TextView typeTag = new TextView(getContext());
    final TextView typeTag2 = new TextView(getContext());
    TextView addTag = (TextView) vi.findViewById(R.id.addTag);


    typeTag.setText(lines.get(position).getType());

    typeTag.setBackgroundColor(getContext().getResources().getColor(R.color.nice_blue));
    typeTag.setTextColor(getContext().getResources().getColor(R.color.lightening_yellow));
    typeTag.setTextSize(25);
    typeTag.setPadding(5, 5, 5, 5);


    flowLayout.addView(typeTag);


    addTag.setOnClickListener(new View.OnClickListener() {
        int i = 0;
        @Override
        public void onClick(View v) {
            TextView tv = new TextView(getContext());
            tv.setBackgroundColor(getContext().getResources().getColor(R.color.nice_blue));
            tv.setTextColor(getContext().getResources().getColor(R.color.lightening_yellow));
            String text = "Goofy"+i++;
            tv.setText(text);
            tv.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
            flowLayout.addView(tv);
            parent.invalidate();
            parent.requestLayout();
            Toast.makeText(getContext(), "heyheyhey", Toast.LENGTH_SHORT).show();

        }
    });


    tv.setText((lines.get(position).getLine()));
    return vi;
}
