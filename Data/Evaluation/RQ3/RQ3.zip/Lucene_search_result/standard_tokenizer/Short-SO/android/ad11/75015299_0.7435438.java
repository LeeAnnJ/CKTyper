public static String maskNumbers(String str) {
    StringBuilder buf = new StringBuilder(str.length());

    for (int i = 0; i &lt; str.length(); i++) {
        char ch = str.charAt(i);
        buf.append(Character.isDigit(ch) ? '0' : ch);
    }

    return buf.toString();
}
