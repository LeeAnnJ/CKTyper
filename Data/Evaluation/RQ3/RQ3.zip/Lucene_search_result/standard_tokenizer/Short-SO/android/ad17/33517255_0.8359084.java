TextView tv = (TextView) (mSnackBar.getView()).findViewById(android.support.design.R.id.snackbar_text);
Typeface font = Typeface.createFromAsset(getContext().getAssets(), &quot;fonts/font_file.ttf&quot;);
tv.setTypeface(font);
