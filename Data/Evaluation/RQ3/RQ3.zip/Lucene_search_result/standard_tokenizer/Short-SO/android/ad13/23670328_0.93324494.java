    EditText ed = (EditText)findViewById(R.id.editText1);

    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);  
    imm.hideSoftInputFromWindow(ed.getWindowToken(), 0);  

    ed.setOnClickListener(new OnClickListener() {

        public void onClick(View v) {
            // TODO Auto-generated method stub
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);  
            imm.showSoftInput(ed, InputMethodManager.SHOW_IMPLICIT);  

        }
    });
