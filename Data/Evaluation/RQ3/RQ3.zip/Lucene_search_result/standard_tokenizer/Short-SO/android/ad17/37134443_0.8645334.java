TableLayout serviceLineLayout = new TableLayout(getContext());
        serviceLineLayout.setLayoutParams(new TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.MATCH_PARENT));

TableRow firstTableRow = getFirstTableRow(getContext());
        serviceLineLayout.addView(firstTableRow);

private TableRow getFirstTableRow(Context context) {
        TableRow tableRow = new TableRow(context);

        tableRow.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.MATCH_PARENT));


        TextView typeHeader = new TextView(context);
        typeHeader.setId(0);
        typeHeader.setText("Type");
        typeHeader.setTextSize(20);
        tableRow.addView(typeHeader);

        TextView numberHeader = new TextView(context);
        numberHeader.setId(0);
        numberHeader.setText("Number");
        numberHeader.setTextSize(20);
        numberHeader.setGravity(Gravity.RIGHT);
        tableRow.addView(numberHeader);

        return tableRow;
    }
