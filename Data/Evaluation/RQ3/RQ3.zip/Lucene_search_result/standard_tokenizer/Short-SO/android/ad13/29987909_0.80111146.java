private void fKeyboardClose()
    {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService( Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow( this.getCurrentFocus().getWindowToken(), 0);
    }
