protected Bitmap convertToBitmap(CardView view) {
    int totalHeight = view.getHeight;
    int totalWidth = view.getWidth();
    float percent = 0.7f;//use this value to scale bitmap to specific size

    Bitmap canvasBitmap = Bitmap.createBitmap(totalWidth,totalHeight, Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(canvasBitmap);
    canvas.scale(percent, percent);
    view.draw(canvas);

    return canvasBitmap;
}
