public static void hideSoftKeyboard (Activity activity, View view) {
 InputMethodManager imm =(InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE);
 imm.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);}
