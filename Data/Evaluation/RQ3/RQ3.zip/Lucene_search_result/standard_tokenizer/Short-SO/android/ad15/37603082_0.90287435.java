public class MainActivity extends AppCompatActivity {
private Button mButton;
private TextView mTextView;
private Deck mNewDeck;


@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    mTextView = (TextView) findViewById(R.id.textView);
    mButton = (Button) findViewById(R.id.button);

    View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String text = "";
            text = mNewDeck.setText();
            mTextView.setText(text);

        }
    };
    mButton.setOnClickListener(listener);
}
