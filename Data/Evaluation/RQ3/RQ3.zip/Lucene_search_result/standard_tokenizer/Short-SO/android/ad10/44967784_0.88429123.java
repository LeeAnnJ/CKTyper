public Bitmap captureScreenShot(View view) {
/*
 * Creating a Bitmap of view with ARGB_4444.
 * */
    Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_4444);
    Canvas canvas = new Canvas(bitmap);
    Drawable backgroundDrawable = view.getBackground();
    if (backgroundDrawable != null) {
        backgroundDrawable.draw(canvas);
    } else {
        canvas.drawColor(Color.parseColor("#80000000"));
    }
    view.draw(canvas);
    return bitmap;
}
