public CustomAdapter(Context context, Activity act, List&lt;Selfservice&gt; dataList, Resources resources) {

    res = resources;
    activity = act;
    data = dataList;
    this.context = context;

} 
