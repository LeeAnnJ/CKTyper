 public void onCreate() {
        super.onCreate();
        //init WindowManager
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        getWindowManagerDefaultDisplay();
        //Init LayoutInflater
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        addRemoveView(inflater);
        addFloatingWidgetView(inflater);
        implementClickListeners();
        implementTouchListenerToFloatingWidgetView();
        System.out.println(&quot;mFloatingWidgetView&quot; +mFloatingWidgetView);
        expandedView = mFloatingWidgetView.findViewById(R.id.expanded_container);
        expandedView.setVisibility(View.VISIBLE);//set large view open
        edittext1 = mFloatingWidgetView.findViewById(R.id.floating_widget_title_label);
        edittext1.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInputFromInputMethod(edittext1.getApplicationWindowToken(), 1);
        imm.showSoftInput(edittext1, InputMethodManager.SHOW_IMPLICIT);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

