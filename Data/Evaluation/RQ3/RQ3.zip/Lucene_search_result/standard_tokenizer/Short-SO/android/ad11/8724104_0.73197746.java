public void Data(String s) {
    System.out.print("Analysis" + "\n" + s);
    jTextArea1.setText(s);
    StringBuilder buf = new StringBuilder();
    for (int i = 0; i &lt; s.length(); i++) {
        if (!Character.isWhitespace(s.charAt(i))) {
            buf.append(s.charAt(i));
        } else if (Character.isWhitespace(s.charAt(i)) &amp;&amp;   !Character.isWhitespace(s.charAt(i + 1))) {
            buf.append(s.charAt(i));
        }
    }
    System.out.println(buf.toString() + "\n" + "from buf");
    jTextArea1.setText(buf.toString());
}
