public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        Spinner spinner = root.findViewById(R.id.spinner);
        ImageView flags = (ImageView) root.findViewById(R.id.flag);

        spinner.setAdapter(new ArrayAdapter&lt;String&gt;(this.getContext(),android.R.layout.simple_spinner_dropdown_item,
                CountryData.countryNames));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView&lt;?&gt; parent, View view, int position, long id) {
                flags.setImageResource(CountryData.countryFlag[spinner.getSelectedItemPosition()]);
                String selectedLang = parent.getItemAtPosition(position).toString();
                if(selectedLang.equals(&quot;GR&quot;)){
                    setLocal(HomeFragment.this,&quot;el&quot;); //app always reloads 
                }else {
                    setLocal(HomeFragment.this,&quot;en&quot;); //app always reloads 

                }


            }

            @Override
            public void onNothingSelected(AdapterView&lt;?&gt; parent) {

            }
        });
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    public void setLocal(HomeFragment activity , String langCode){
      Locale locale = new Locale(langCode);
      locale.setDefault(locale);
      Resources resources = activity.getResources();
      Configuration config = resources.getConfiguration();
      config.setLocale(locale);
      resources.updateConfiguration(config,resources.getDisplayMetrics());
      getActivity().recreate(); //app reloads 
    }


}
