public void showKeyboard(View view) {
    InputMethodManager myKeyboard = (InputMethodManager) getSystemService(Context
            .INPUT_METHOD_SERVICE);
    myKeyboard.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

}

public void hideKeyboard() {
    InputMethodManager myKeyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    myKeyboard.hideSoftInputFromWindow(EditText1.getWindowToken(), 0);
}
