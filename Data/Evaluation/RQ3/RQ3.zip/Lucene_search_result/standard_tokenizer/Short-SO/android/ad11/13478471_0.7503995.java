 static public String formatMillis(long val) {
    StringBuilder                       buf=new StringBuilder(20);
    String                              sgn="";

    if(val&lt;0) { sgn="-"; val=Math.abs(val); }

    append(buf,sgn,0,( val/3600000));
    append(buf,":",2,((val%3600000)/60000));
    append(buf,":",2,((val %60000)/1000));
    //append(buf,".",3,( val%1000));
    return buf.toString();
 }
