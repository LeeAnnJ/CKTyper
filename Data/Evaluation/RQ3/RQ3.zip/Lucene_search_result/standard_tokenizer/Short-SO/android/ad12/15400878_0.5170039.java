public class Native_xxxxxxx implements FREFunction {

    private Resources res;

    public FREObject call(FREContext arg0, FREObject[] arg1) {

        try {

            Activity activity = arg0.getActivity();

            res = activity.getResources();

            return FREObject.newObject(res.getString(arg0.getResourceId("string.app_name ")));

            //return FREObject.newObject(res.getString(arg0.getResourceId("string.test"))) ;

            //return FREObject.newObject(res.getString(R.string.test));

        } catch ( Exception ex ) {

        }
        return null;

    }

}
