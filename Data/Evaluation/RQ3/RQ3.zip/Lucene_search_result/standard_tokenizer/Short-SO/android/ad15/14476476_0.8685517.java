public class MainActivity extends Activity{
protected static final long TIME_DELAY = 5000;
//the default update interval for your text, this is in your hand , just run this sample
TextView mTextView;
Handler handler=new Handler();  
int count =0;
@Override
protected void onCreate(Bundle savedInstanceState){
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    mTextView=(TextView)findViewById(R.id.textview);
    handler.post(updateTextRunnable);
}


Runnable updateTextRunnable=new Runnable(){  
  public void run() {  
      count++;
      mTextView.setText("getting called " +count);
      handler.postDelayed(this, TIME_DELAY);  
     }  
 };  
}
