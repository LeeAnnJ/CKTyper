void hideKeyboard(Activity activity) {
   View view = activity.getCurrentFocus();
   InputMethodManager manager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
   assert manager != null &amp;&amp; view != null;
   manager.hideSoftInputFromWindow(view.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
}