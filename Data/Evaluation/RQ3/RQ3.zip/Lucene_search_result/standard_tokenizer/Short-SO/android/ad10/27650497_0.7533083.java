//View v is the root view/parent of your layout, for example LinearLayout or RelativeLayout (layout where you have placed content of which you want to take screenshot)
private Bitmap getBitmapFromView(View v) {
    Bitmap bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas (bitmap);
    v.draw(canvas);
    // Returns screenshot
    return bitmap;
}
