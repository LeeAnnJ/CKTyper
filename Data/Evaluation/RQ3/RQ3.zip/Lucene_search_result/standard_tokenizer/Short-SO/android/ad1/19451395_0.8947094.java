public static void hideSoftKeyboard(Activity activity) 
    {

        if(activity!= null &amp;&amp; activity.getCurrentFocus() != null &amp;&amp; activity.getCurrentFocus().getWindowToken() != null)
        {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);            
        }
    }
