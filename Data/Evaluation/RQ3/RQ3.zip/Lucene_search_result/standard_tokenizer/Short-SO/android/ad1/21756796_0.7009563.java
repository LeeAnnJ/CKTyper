public class Activity1 extends Activity implements OnFocusChangeListener
{
    protected void onCreate( Bundle b )
    {
         .....
        txtX = (EditText) findViewById(R.id.text_x);
        txtX.setOnFocusChangeListener(this);
    }

    public void hideKeyboard(View view)
    {
        InputMethodManager inputMethodManager =(InputMethodManager)context.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
    @Override
    public void onFocusChange(View view, boolean arg1)
    {
        if(! view.hasFocus())
            hideKeyboard(view);
    }
}
