setLocale(Locale.ENGLISH);


public void setLocale(Locale locale){
    Resources resources = getApplicationContext().getResources();
    Configuration configuration = resources.getConfiguration();
    Locale.setDefault(locale);
    configuration.setLocale(locale);
    getApplicationContext().getResources().updateConfiguration(configuration,
            resources.getDisplayMetrics());
}
