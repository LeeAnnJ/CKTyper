public class CustomAdapter extends ArrayAdapter&lt;String&gt; {

public CustomAdapter(Context context, ArrayList&lt;String&gt; names) {
    super(context, R.layout.custom_layout, names);

}

@NonNull
@Override
public View getView(int position, View convertView, ViewGroup parent) {

    LayoutInflater inflater = LayoutInflater.from(getContext());
    View customView = inflater.inflate(R.layout.custom_layout, parent, false);
    String singleName = getItem(position);
    TextView tv = (TextView) customView.findViewById(R.id.sNametv);
    tv.setText(singleName);

    return customView;
}
}
