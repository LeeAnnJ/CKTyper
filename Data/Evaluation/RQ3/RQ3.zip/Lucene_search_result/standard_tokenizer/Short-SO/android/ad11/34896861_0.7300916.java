BufferedReader reader=new BufferedReader(new InputStreamReader(c.getInputStream()));
StringBuilder buf = new StringBuilder();
String line;

while ((line=reader.readLine()) != null) {
  buf.append(line);
}
return(buf.toString());
