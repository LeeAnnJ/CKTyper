    editTextNumber = (EditText) view.findViewById(R.id.editTextPhone);

    editTextNumber.addTextChangedListener(new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if (s.length() == 10){
                hideSoftKeyboard(requireActivity());
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    });


public void hideSoftKeyboard(Activity activity) {

    InputMethodManager inputMethodManager =
            (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);

    View currentFocus = activity.getCurrentFocus();

    if (inputMethodManager != null) {
        IBinder windowToken = activity.getWindow().getDecorView().getRootView().getWindowToken();
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0);
        inputMethodManager.hideSoftInputFromWindow(windowToken, InputMethodManager.HIDE_NOT_ALWAYS);

        if (currentFocus != null) {
            inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

}
