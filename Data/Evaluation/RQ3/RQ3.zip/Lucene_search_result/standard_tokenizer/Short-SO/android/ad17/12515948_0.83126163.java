public class FastAssesmentListAdapter extends ArrayAdapter&lt;Data&gt; {

    private static int LAYOUT_ID = R.layout.list_adapter_with_checkbox_three_column;
private final Data[] assesments;
private final Context context;
LinearLayout listHeader;

static class ViewHolder {
    protected TextView column1;
    protected TextView column2;
    protected TextView column3;
    protected CheckBox checkbox;
}

public FastAssesmentListAdapter(Context context, Data[] assesments) {
    super(context, LAYOUT_ID, assesments);
    this.context = context;
    this.assesments = assesments;
}

//ListFragment and array adapter will automatically call this over and over to auto populate the list
@Override
public View getView(int position, View convertView, ViewGroup parent) {
    final Data item = getItem(position);

    // Formulate row view (create if it does not exist yet)
    View view = convertView;
    if(view == null) {
        LayoutInflater inflater = ((Activity) getContext()).getLayoutInflater();
        view = inflater.inflate(LAYOUT_ID, null);
        final ViewHolder viewHolder = new ViewHolder();
        viewHolder.column1 = (TextView) view.findViewById(R.id.adapter_textview_column1);
        viewHolder.column2 = (TextView) view.findViewById(R.id.adapter_textview_column2);
        viewHolder.column3 = (TextView) view.findViewById(R.id.adapter_textview_column3);
        viewHolder.checkbox = (CheckBox) view.findViewById(R.id.check_box);
        view.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getContext(), "Clicked",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), FacilityActivity.class);
                getContext().startActivity(intent);
            }
        });
            if(viewHolder.checkbox != null) {
                viewHolder.checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView,
                        boolean isChecked) {
                      if(isChecked) {
                          item.setSelected(isChecked);
                          Toast.makeText(getContext(), "Checked",
                                  Toast.LENGTH_SHORT).show();
                      }

                    }
                  });
            }
        view.setTag(viewHolder);
        viewHolder.checkbox.setTag(position);
    }
    ViewHolder viewHolder = (ViewHolder) view.getTag();
    viewHolder.checkbox.setTag(position);
    viewHolder.column1.setText(item.getColumn1());
    viewHolder.column2.setText(item.getColumn2());
    viewHolder.column3.setText(item.getColumn3());
    viewHolder.checkbox.setChecked(item.isSelected());
return view;
}
 }
