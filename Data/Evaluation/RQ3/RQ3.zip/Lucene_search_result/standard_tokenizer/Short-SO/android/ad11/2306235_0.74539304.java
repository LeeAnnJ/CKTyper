StringBuilder buf = new StringBuilder(aantal);
while (aantal-- &gt; 0)
  buf.append('!');
return buf.toString();
