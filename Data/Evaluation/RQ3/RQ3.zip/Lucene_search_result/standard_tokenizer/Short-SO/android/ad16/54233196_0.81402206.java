public static void forceHideKeyboard(Activity activity, EditText editText) {
    try {

        if (editText == null) return;

        if (activity.getCurrentFocus() == null
                || !(activity.getCurrentFocus() instanceof EditText)) {
            editText.requestFocus();
        }

        InputMethodManager imm = (InputMethodManager) activity
                .getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        activity.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);


    } catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
}
