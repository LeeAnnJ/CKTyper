Resources resources = getResources();
        Configuration configuration = resources.getConfiguration();
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        configuration.setLocale(locale);

        resources.updateConfiguration(configuration,displayMetrics);
        getApplicationContext().createConfigurationContext(configuration);
