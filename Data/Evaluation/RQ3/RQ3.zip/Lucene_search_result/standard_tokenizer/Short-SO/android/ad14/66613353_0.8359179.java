InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
if (imm != null) {
  imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
}
