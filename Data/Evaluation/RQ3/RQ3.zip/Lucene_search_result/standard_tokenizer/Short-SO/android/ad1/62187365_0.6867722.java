 autoCompleteCliente.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {             

    esconderTeclado(getActivity());

     return true;
        }
    });

    public void esconderTeclado(Activity activity){
            View view = activity.getCurrentFocus();
            if(view != null){
                InputMethodManager manager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
                manager.hideSoftInputFromWindow(view.getWindowToken(), 0 );
            }
        }
