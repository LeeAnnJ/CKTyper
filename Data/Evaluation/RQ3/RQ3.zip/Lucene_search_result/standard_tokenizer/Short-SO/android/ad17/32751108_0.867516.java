 addTag.setClickable(true);
 addTag.setOnClickListener(new View.OnClickListener() {
    int i = 0;
    @Override
    public void onClick(View v) {
        TextView tv = new TextView(getContext());
        tv.setBackgroundColor(getContext().getResources().getColor(R.color.nice_blue));
        tv.setTextColor(getContext().getResources().getColor(R.color.lightening_yellow));
        String text = "Goofy"+i++;
        tv.setText(text);
        tv.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        ((ViewGroup)v.getParent()).addView(tv)
        parent.invalidate();// do you know this "parent" guy?
        //i feel it is suppose to be flowlayout
        parent.requestLayout();
        Toast.makeText(getContext(), "heyheyhey", Toast.LENGTH_SHORT).show();

    }
});
