 public static void hideSystemKeyBoard1(Context mcontext) {
  InputMethodManager imm = (InputMethodManager) mcontext
    .getSystemService(Context.INPUT_METHOD_SERVICE);
   if (imm.isActive())  
   imm.toggleSoftInput(InputMethodManager.SHOW_IMPLICIT,
     InputMethodManager.HIDE_NOT_ALWAYS);
 }


 public static void hideSystemKeyBoard2(Context mcontext,View v) {
  InputMethodManager imm = (InputMethodManager) ((AbstractMmtClientActivity) mcontext)
    .getSystemService(Context.INPUT_METHOD_SERVICE);
  imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
 }
