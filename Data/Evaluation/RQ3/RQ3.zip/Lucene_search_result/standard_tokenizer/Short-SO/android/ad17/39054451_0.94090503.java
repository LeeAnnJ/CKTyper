public class CustomAdapter extends ArrayAdapter&lt;String&gt; {

 private int hidingItemIndex;

 public CustomAdapter(Context context, int textViewResourceId, String[] objects, int hidingItemIndex) {
     super(context, textViewResourceId, objects);
     this.hidingItemIndex = hidingItemIndex;
 }

 @Override
 public View getDropDownView(int position, View convertView, ViewGroup parent) {
     View v = null;
     if (position == hidingItemIndex) {
         TextView tv = new TextView(getContext());
         tv.setVisibility(View.GONE);
         v = tv;
     } else {
         v = super.getDropDownView(position, null, parent);
     }
     return v;
 }
 }
