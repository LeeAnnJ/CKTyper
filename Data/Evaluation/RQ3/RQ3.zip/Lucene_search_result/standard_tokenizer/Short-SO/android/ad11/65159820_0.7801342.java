public static String makeSequence(int N) {
    StringBuilder buf = new StringBuilder();

    while (N &gt; 0) {
        buf.append(String.valueOf(N).repeat(N));
        N--;
    }

    return buf.toString();
}
