    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.toggleSoftInput(txtBuscar.getId(), InputMethodManager.SHOW_FORCED);
