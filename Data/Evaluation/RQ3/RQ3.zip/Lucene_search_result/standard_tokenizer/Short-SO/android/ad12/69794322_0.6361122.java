@Override
public Resources getResources() {
    Resources resources = super.getResources();
    Configuration config = resources.getConfiguration();
    config.setToDefaults();
    return createConfigurationContext(config).getResources();
}

@Override
protected void attachBaseContext(Context newBase) {
    Configuration config = newBase.getResources().getConfiguration();
    config.fontScale=1;
    Context context=newBase.createConfigurationContext(config);
    super.attachBaseContext(context);
}
