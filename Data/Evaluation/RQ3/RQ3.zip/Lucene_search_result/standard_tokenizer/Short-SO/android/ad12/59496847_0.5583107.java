public static void setApplicationLanguage(Context context, Locale locale) {

    Resources resources = context.getApplicationContext().getResources();
    DisplayMetrics dm = resources.getDisplayMetrics();
    Configuration config = resources.getConfiguration();
    config.locale = locale;
    if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.N) {
        LocaleList localeList = new LocaleList(locale);
        LocaleList.setDefault(localeList);
        config.setLocales(localeList);
        context.getApplicationContext().createConfigurationContext(config);
        Locale.setDefault(locale);
    }
    resources.updateConfiguration(config, dm);

    Intent intent = new Intent(context, HomeActivity.class);
    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
    finishAffinity();
    context.startActivity(intent);
}
