public String toString() {
    StringBuilder buf = new StringBuilder( "The Complete Deck consists of: \n" );
    for ( Card card : getCards() ) {
      buf.append( card.toString()).append( "\n" );
    }
    return buf.toString();
}
