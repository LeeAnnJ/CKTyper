    public static void hideSoftKeyboard(Activity activity) {
    InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
    inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
}


@Override
public boolean dispatchTouchEvent(MotionEvent ev) {
    if (ev.getAction() == MotionEvent.ACTION_DOWN) {
        View view = getCurrentFocus();

        if (view != null &amp;&amp; view instanceof EditText) {
            Rect r = new Rect();
            view.getGlobalVisibleRect(r);
            int rawX = (int) ev.getRawX();
            int rawY = (int) ev.getRawY();
            if (!r.contains(rawX, rawY)) {
                hideSoftKeyboard(MainActivity.this);
            }
        }
    }
    return super.dispatchTouchEvent(ev);
}
