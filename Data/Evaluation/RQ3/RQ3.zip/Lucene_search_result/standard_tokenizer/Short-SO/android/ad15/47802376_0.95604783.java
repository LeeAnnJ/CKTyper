TextView mTextView;
TextView mTextView2;
TextView mTextView3;
TextView mTextView4;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_second);

    mTextView = (TextView) findViewById(R.id.textView2);
    mTextView2 = (TextView) findViewById(R.id.textView3);
    mTextView3 = (TextView) findViewById(R.id.tTitulo);
    mTextView4 = (TextView) findViewById(R.id.tSubtitulo);
    button = (ImageButton) findViewById(R.id.imageButton);


    Bundle bundle = getIntent().getExtras();
    if (bundle != null) {
        mTextView3.setText(bundle.getString("Titulo"));
