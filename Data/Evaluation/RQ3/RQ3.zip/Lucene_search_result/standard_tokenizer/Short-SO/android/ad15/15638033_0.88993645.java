public class MainActivity extends Activity implements OnLongClickListener, OnClickListener {

TextView mTextView;
RelativeLayout mTopLayout;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    mTextView = (TextView) findViewById(R.id.mTextView);
    mTopLayout = (RelativeLayout) findViewById(R.id.mTopLayout);

    mTextView.setOnLongClickListener(this);
    mTopLayout.setOnClickListener(this);
    mTextView.setOnClickListener(this);
}

@Override
public void onClick(View v) {
    Toast.makeText(this, v.getClass().getName() + " clicked!", Toast.LENGTH_SHORT).show();
    if (v.getId() == R.id.mTextView) {
        ((View) v.getParent()).performClick();
    }
}

...
}
