public static void ToEnglishLocale(this Activity activity)
{
    Locale locale = new Locale("en-US");
    Configuration config = new Configuration();
    config.SetLocale(locale);
    activity.BaseContext.Resources.UpdateConfiguration(config, activity.BaseContext.Resources.DisplayMetrics);
}
