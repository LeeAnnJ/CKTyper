private static DateTimeFormatter monthDayFormatter = DateTimeFormatter.ofPattern("MMdd");
private static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("uuuuMMdd");

private static int reverseStringToInt(String s) {
    StringBuilder buf = new StringBuilder(s);
    buf.reverse();
    return Integer.parseInt(buf.toString());
}
