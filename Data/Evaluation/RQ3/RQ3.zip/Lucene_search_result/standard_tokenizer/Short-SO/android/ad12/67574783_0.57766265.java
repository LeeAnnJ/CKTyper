       Resources resources = getResources();
        DisplayMetrics dm = resources.getDisplayMetrics();
        Configuration config = resources.getConfiguration();
        if (Build.VERSION.SDK_INT &lt; 17){ config.locale = new Locale(localecode.toLowerCase()); }
        else { config.setLocale(new Locale(localecode.toLowerCase())); }
        resources.updateConfiguration(config, dm);
