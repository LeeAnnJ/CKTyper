public class MainActivity extends AppCompatActivity {
TextView mTextView;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    mTextView = findViewById(R.id.textView);
    AsyncExample asyncExample = new AsyncExample(this,mTextView);
    asyncExample.execute();
  }
}
