 MainActivity{
 description.addTextChangedListener(watcher);


       hide_keyboard(PostActivity.this);
       add.setOnClickListener(new View.OnClickListener() {

           @Override
           public void onClick(View view) {
               description.clearFocus();

               PostFragment fragment = PostFragment.newInstance();
               fragment.show(getSupportFragmentManager(), "dialog");

           }
       });[enter image description here][1]void hide_keyboard(Activity activity) {
       InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
       //Find the currently focused view, so we can grab the correct window token from it.
       View view = activity.getCurrentFocus();
       //If no view currently has focus, create a new one, just so we can grab a window token from it
       if(view == null) {
           view = new View(activity);
       }
       inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
       inputMethodManager.toggleSoftInput(0, InputMethodManager.HIDE_IMPLICIT_ONLY);
   }
