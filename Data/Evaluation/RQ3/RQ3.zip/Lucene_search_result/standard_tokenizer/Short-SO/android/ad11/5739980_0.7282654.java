@GET  
@Produces{"text/plain"}  
public String listHeaderNames(@Context HttpHeaders headers) {  
  StringBuilder buf = new StringBuilder();  
  for (String header: headers.getRequestHeaders().keySet()) {  
    buf.append(header);  
    buf.append("\n");  
  }  
  return buf.toString();  
}
