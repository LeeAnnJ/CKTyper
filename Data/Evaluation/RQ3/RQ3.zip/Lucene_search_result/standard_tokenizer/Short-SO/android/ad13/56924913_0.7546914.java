button.setOnClickListener(new View.OnClickListener() {
        private Object URL;

        @Override
        public void onClick(View view) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);

            if (webView == (WebView) URL); {
                webView.loadUrl(String.valueOf(editText.getText()));
                editText.setText("");
            }

            if (webView == editText.setText(""); {
                webView.loadUrl("https://www.google.com/#q=" + editText.getText());
            }





        }
    });
