public static void JNI_keyboardShow() {
    InputMethodManager imm = (InputMethodManager)Main.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    imm.showSoftInput(m_window.getDecorView(), InputMethodManager.SHOW_IMPLICIT);
}
