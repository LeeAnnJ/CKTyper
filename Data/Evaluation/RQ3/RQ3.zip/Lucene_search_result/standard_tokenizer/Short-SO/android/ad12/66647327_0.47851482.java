    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Locale locale = new Locale(&quot;tr&quot;); // get this value from shared pref
        Locale.setDefault(locale);
        Resources resources = activity.getResources();
        Configuration config = resources.getConfiguration();
        config.setLocale(locale);
        resources.updateConfiguration(config, resources.getDisplayMetrics());

        setContentView(R.layout.activity_ui_settings);

        currentLanguage = getIntent().getStringExtra(currentLang);
        spinner = (Spinner) findViewById(R.id.spinner);

        final List&lt;String&gt; list = new ArrayList&lt;String&gt;();
        list.add(getString(R.string.selectlang));
        list.add(&quot;Türkçe&quot;);
        list.add(&quot;English&quot;);
        list.add(&quot;Pусский&quot;);
        final CustomAdapter adapter = new CustomAdapter(getApplicationContext(),flags, (ArrayList&lt;String&gt;) list);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView&lt;?&gt; adapterView, View view, int position, long l) {
                switch (position) {

                    case 1:
                        setLocale(&quot;tr&quot;);
                        break;
                    case 2:
                        setLocale(&quot;en&quot;);
                        break;
                    case 3:
                        setLocale(&quot;ru&quot;);
                        break;

                }
            }
            @Override
            public void onNothingSelected(AdapterView&lt;?&gt; adapterView) {
            }
        });
    }
