private void showKeyboard(View view) {
    InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
    keyboard.showSoftInput(view, 0);
}

private void hideKeyboard() {
    InputMethodManager inputMethodManager = (InputMethodManager) this
            .getSystemService(Context.INPUT_METHOD_SERVICE);
    inputMethodManager.hideSoftInputFromWindow(this.getCurrentFocus()
            .getWindowToken(), 0);
}
