public class ResultsAdapter extends DataBufferAdapter&lt;Metadata&gt; {


    public ResultsAdapter(Context context) {
        super(context, android.R.layout.simple_list_item_1);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(getContext(),
                    android.R.layout.simple_list_item_1, null);
        }
        Metadata metadata = getItem(position);

        String resultat = metadata.getAlternateLink();
        String S1 = resultat.substring(32,60);
        TextView titleTextView =
                (TextView) convertView.findViewById(android.R.id.text1);
        titleTextView.setText(S1);
        Intent intent = new Intent(getContext(), EditContentsActivity.class);
        intent.putExtra("file", S1);



        getContext().startActivity(intent);


        return convertView;
    }

}
