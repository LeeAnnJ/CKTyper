public static String expandTabs(String s, int tabSize) {
    if (s == null) return null;
    StringBuilder buf = new StringBuilder();
    int col = 0;
    for (int i = 0; i &lt; s.length(); i++) {
        char c = s.charAt(i);
        switch (c) {
            case '\n' :
                col = 0;
                buf.append(c);
                break;
            case '\t' :
                buf.append(spaces(tabSize - col % tabSize));
                col += tabSize - col % tabSize;
                break;
            default :
                col++;
                buf.append(c);
                break;
        }
    }
    return buf.toString();
}

public static String spaces(int n) {
    StringBuilder buf = new StringBuilder();
    for (int sp = 0; sp &lt; n; sp++) buf.append(" ");
    return buf.toString();
}
