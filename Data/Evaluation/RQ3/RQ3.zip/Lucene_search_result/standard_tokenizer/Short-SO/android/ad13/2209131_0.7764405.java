View.OnLongClickListener mLongClickListener = new View.OnLongClickListener()
    {

        @Override
        public boolean onLongClick(View v)
        {

            Configuration config = RouteMapActivity.this.getResources()
                    .getConfiguration();
            if (config.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES)
            {
                InputMethodManager imm = (InputMethodManager) RouteMapActivity.this
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.showSoftInput(mapView, InputMethodManager.SHOW_IMPLICIT); // .SHOW_FORCED);
            }
            return false;
        }

    };
