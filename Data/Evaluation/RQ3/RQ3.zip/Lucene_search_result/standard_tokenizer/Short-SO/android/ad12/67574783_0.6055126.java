Locale locale = new Locale(language);
Locale.setDefault(locale);

Resources resources = context.getResources();
Configuration config = resources.getConfiguration();
config.setLocale(locale);

return context.createConfigurationContext(config);
