List&lt;TextView&gt; textviews = new ArrayList&lt;&gt;();
Resources res = getResources();

for (int i = 1; i &lt;=272; i++) {

    int id = res.getIdentifier("resul" + i, "id", getContext().getPackageName());
    TextView tv = (TextView) findViewById(id);
    textviews.add(tv);
}
