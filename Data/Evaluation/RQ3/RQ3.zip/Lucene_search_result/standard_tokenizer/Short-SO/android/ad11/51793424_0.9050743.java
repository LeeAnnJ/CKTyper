public static void main(String[] args) {
    final String commandHeader = "HED&gt;";
    final String command = "0123456789ABCDEF";
    short commandLength = (short) (commandHeader.length() + command.length());
    char[] array;

    if( commandLength &lt; 124 )
    {
        final ByteBuffer bb = ByteBuffer.allocate(2).putShort(commandLength);
        array = new String( bb.array() ).toCharArray();
    }
    else
    {
        final ByteBuffer bb = ByteBuffer.allocate(2).putShort(commandLength);
        array = convertToHex(bb.array());
    }

    final String command = new String(array) + commandHeader + command;
    System.out.println( command );
}

private static char[] convertToHex(byte[] data) {
    final StringBuilder buf = new StringBuilder();
    for (byte b : data) {
        int halfByte = (b &gt;&gt;&gt; 4) &amp; 0x0F;
        int twoHalves = 0;
        do {
            if ((0 &lt;= halfByte) &amp;&amp; (halfByte &lt;= 9))
                buf.append((char) ( '0' + halfByte));
            halfByte = b &amp; 0x0F;
        } while (twoHalves++ &lt; 1);
    }
    return buf.toString().toCharArray();
}
