package com.example.androidsimpledbapp1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {

    TextView mTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Grabs the TextView 
        mTextView = (TextView)findViewById(R.id.dbname);
        mTextView.setText(getIntent().getStringExtra("mytext"));
    }

    //Changing Activity
    public void editBtnPressed(View v){
        Intent intent = new Intent(MainActivity.this, EditScreen.class);
        startActivity(intent);
    }
}
