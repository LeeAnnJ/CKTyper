 private void setLocale(String lang) {
 if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.JELLY_BEAN_MR1) {
    Locale locale = new Locale(lang);
    Locale.setDefault(locale);
    Configuration config = 
    getBaseContext().getResources().getConfiguration();
    config.locale = locale;
    getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

} else {
    Resources resources = getBaseContext().getResources();
    Configuration configuration = resources.getConfiguration();
    configuration.setLocale(new Locale(lang));
    getBaseContext().getApplicationContext().createConfigurationContext(configuration);
}

// shared pref.
SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
editor.putString("My_Lang", lang);
editor.apply();

}
