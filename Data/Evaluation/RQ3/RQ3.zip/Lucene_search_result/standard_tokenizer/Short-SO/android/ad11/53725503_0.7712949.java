@Override
public String toString() {
    StringBuilder buf = new StringBuilder();

    for (Planet planet : list) {
        buf.append(planet);
    }

    return buf.toString();
}
