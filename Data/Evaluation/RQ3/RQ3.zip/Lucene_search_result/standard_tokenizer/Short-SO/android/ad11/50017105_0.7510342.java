public static List&lt;String&gt; split(String str) {
    List&lt;String&gt; res = new ArrayList&lt;&gt;();
    StringBuilder buf = null;

    for (int i = 0; i &lt; str.length(); i++) {
        char ch = str.charAt(i);

        if (ch &gt;= '0' &amp;&amp; ch &lt;= '9') {
            if (buf == null)
                buf = new StringBuilder();
            buf.append(ch);
        } else {
            if (buf != null) {
                res.add(buf.toString());
                buf = null;
            }
            res.add(String.valueOf(ch));
        }
    }

    if (buf != null)
        res.add(buf.toString());

    return Collections.unmodifiableList(res);
}
