public class NoteAdapter extends ArrayAdapter&lt;Note&gt; {

public NoteAdapter(Context context, int resource, ArrayList&lt;Note&gt; notes) {
    super(context, resource, notes);


}

@Override
public View getView(int position, View convertView, @NonNull ViewGroup parent) {
    //return super.getView(position, convertView, parent);

    if(convertView == null) {
        convertView = LayoutInflater.from(getContext())
                .inflate(R.layout.item_note, null);
    }

    Note note = getItem(position);

    if(note != null) {
        TextView title = (TextView) convertView.findViewById(R.id.list_note_title);
        TextView content = (TextView) convertView.findViewById(R.id.list_note_content);
        TextView date = (TextView) convertView.findViewById(R.id.list_note_date);

        Typeface music_font = Typeface.createFromAsset(getContext().getAssets(), &quot;fonts/melodymakernotesonly.ttf&quot;);
        Typeface scribble_card = Typeface.createFromAsset(getContext().getAssets(), &quot;fonts/the unseen.ttf&quot;);
        title.setTypeface(music_font);
        content.setTypeface(scribble_card);

        title.setText(note.getTitle());
        date.setText(note.getDateTimeFormatted(getContext()));

        if(note.getContent().length() &gt; 25) {
            content.setText(note.getContent().substring(0,25) + &quot;...&quot;);
        } else {
            content.setText(note.getContent());
        }

        if(note.getContent().length() &lt;= 0) {
            content.setText(&quot;(Empty Note..)&quot;);
        } else {
            content.setText(note.getContent());
        }

        if (note.getTitle().length() &lt;= 0) {
            title.setText(&quot;(Untitled)&quot;);
        } else {
            title.setText(note.getTitle());
        }
    }

    return convertView;
}
