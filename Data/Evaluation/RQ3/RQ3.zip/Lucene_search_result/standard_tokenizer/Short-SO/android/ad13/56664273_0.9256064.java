cardProblem.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {    
        //request focus                      
        etProblem.requestFocus();
        //display keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(etProblem, InputMethodManager.SHOW_IMPLICIT);
    }
});
