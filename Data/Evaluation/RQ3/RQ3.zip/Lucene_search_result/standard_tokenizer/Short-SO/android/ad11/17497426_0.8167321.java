StringBuilder buf = new StringBuilder();
for (byte b : x) 
  buf.append(String.format("%02X", b));
String teste = buf.toString();
