RadioGroup rg = new RadioGroup(getContext());

RadioButton rb1 = new RadioButton(getContext());
RadioButton rb2 = new RadioButton(getContext());
TextView tv = new TextView(getContext());

rg.addView(rb1);
rg.addView(rb2);
rg.addView(tv);
