public static void hideSoftKeyboard(Activity activity) {

    InputMethodManager inputMethodManager =
            (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);

    View currentFocus = activity.getCurrentFocus();

    if (inputMethodManager != null) {
        IBinder windowToken = activity.getWindow().getDecorView().getRootView().getWindowToken();
        inputMethodManager.hideSoftInputFromWindow(windowToken, 0);
        inputMethodManager.hideSoftInputFromWindow(windowToken, InputMethodManager.HIDE_NOT_ALWAYS);

        if (currentFocus != null) {
            inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
        }
    }

}
