 public void actionEN(View view) {

        Locale locale = new Locale("en");
        Locale.setDefault(locale);

        Resources resources = getBaseContext().getResources();

        Configuration configuration = resources.getConfiguration();

        if (Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            configuration.setLocale(locale);
        } else {
            configuration.locale = locale;
        }

        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
        recreate();
    }
