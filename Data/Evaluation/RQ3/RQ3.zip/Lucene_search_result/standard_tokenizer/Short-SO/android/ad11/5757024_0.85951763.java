private static String convertToHex(byte[] data) {
    StringBuilder sb = new StringBuilder(data.length * 2);

    Formatter fmt = new Formatter(sb);
    for (byte b : data) {
        fmt.format("%02x", b);
    }

    return sb.toString();
}
