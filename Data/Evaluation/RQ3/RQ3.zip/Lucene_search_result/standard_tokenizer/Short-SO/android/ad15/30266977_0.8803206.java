public class MainActivity extends Activity implements MessageApi.MessageListener, GoogleApiClient.ConnectionCallbacks {

private TextView mTextView;
private static final String WEAR_MESSAGE_PATH = "/start_activity";
GoogleApiClient mApiClient;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    final WatchViewStub stub = (WatchViewStub) findViewById(R.id.watch_view_stub);
    stub.setOnLayoutInflatedListener(new WatchViewStub.OnLayoutInflatedListener() {
        @Override
        public void onLayoutInflated(WatchViewStub stub) {
            mTextView = (TextView) stub.findViewById(R.id.textView);
        }
    });

    mApiClient = new GoogleApiClient.Builder(this)
            .addApi(Wearable.API)
            .addConnectionCallbacks(this)
            .build();

    mApiClient.connect();
}

@Override
public void onConnected(Bundle bundle) {
    Wearable.MessageApi.addListener(mApiClient, this);
}

@Override
public void onConnectionSuspended(int i) {
}

@Override
public void onMessageReceived( final MessageEvent messageEvent ) {
    runOnUiThread( new Runnable() {
        @Override
        public void run() {
            if( messageEvent.getPath().equalsIgnoreCase( WEAR_MESSAGE_PATH ) ) {
                mTextView.setText( new String( messageEvent.getData() ));
            }
        }
    });
}
