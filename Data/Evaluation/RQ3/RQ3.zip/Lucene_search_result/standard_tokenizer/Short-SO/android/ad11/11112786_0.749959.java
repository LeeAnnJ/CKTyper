class StringBuilder
{
    StringBuffer buf = null;
    public StringBuilder()
    {
        buf = new StringBuffer();
    }
    public StringBuilder append(StringBuilder other)
    {
        buf.append(other.buf);
        return this;
    }
    public StringBuilder append(String s)
    {
        buf.append(s);
        return this;
    }
    public StringBuilder append(Object o)
    {
        buf.append(o.toString());
        return this;
    }
    public StringBuilder append(int i)
    {
        buf.append(i);
        return this;
    }
    /* SNIP: append() methods for every other primitive type */
    public String toString()
    {
        return buf.toString();
    }
}
