TextView mTextView;

@Override
protected void onCreate(Bundle savedInstanceState) {
mTextView=findViewById(R.id.textView);
super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    SwipeRefreshLayout pullToRefresh = findViewById(R.id.pullToRefresh);
    pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
        @Override
        public void onRefresh() {
            mTextView.setText("My new text") // update here
            pullToRefresh.setRefreshing(false);
        }
    });
}
