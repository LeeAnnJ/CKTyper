private TextView mtextview;
private EditText medittext;
private Button mbutton;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

     mtextview = (TextView) findViewById(R.id.textView);
     medittext=(EditText)findViewById(R.id.editText);
    mbutton=(Button)findViewById(R.id.button);

    mbutton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String name =medittext.getText().toString();
            startStory(name);
        }

        private void startStory(String name) {
            Intent intent = new Intent(MainActivity.this,AnotherActivity.class);
            intent.putExtra("name",name);
            startActivity(intent);
        }
    });


}
