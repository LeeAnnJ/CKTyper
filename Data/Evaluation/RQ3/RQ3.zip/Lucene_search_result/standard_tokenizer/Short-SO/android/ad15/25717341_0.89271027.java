public class MyActivity extends Activity {

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.round_activity_my);

    TextView mTextView = (TextView)findViewById(R.id.text);

    myAsyncTask mTask = new myAsyncTask();
    mTask.execute("http://ephemeraltech.com/demo/android_tutorial20.php");


    /* final WatchViewStub stub = (WatchViewStub) findViewById(R.id.watch_view_stub);
    stub.setOnLayoutInflatedListener(new WatchViewStub.OnLayoutInflatedListener() {
        @Override
        public void onLayoutInflated(WatchViewStub stub) {
            mTextView = (TextView) stub.findViewById(R.id.text);
        }
    }); */
}
