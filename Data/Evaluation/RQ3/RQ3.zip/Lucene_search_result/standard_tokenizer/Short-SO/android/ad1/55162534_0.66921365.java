final NumberPicker numberPicker = (NumberPicker) dialog.findViewById(R.id.npWeight);
    final EditText editText = (EditText) dialog.findViewById(R.id.edWeight);

    numberPicker.setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View view) {
            if (numberPicker.getVisibility() == View.VISIBLE) {
                editText.setVisibility(View.VISIBLE);
                numberPicker.setVisibility(View.GONE);
                editText.setFocusableInTouchMode(true);
                editText.requestFocus();
                showKeyboard(MyApplication.mainActivity);
            }

            return true;
        }
    });

    editText.setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View view) {
                editText.setVisibility(View.GONE);
                numberPicker.setVisibility(View.VISIBLE);
         //       hideKeyboard(MyApplication.mainActivity);
            return true;
        }
    });


private static void showKeyboard(Activity activity) {
        View view = activity.getCurrentFocus();
        InputMethodManager methodManager = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
        assert methodManager != null &amp;&amp; view != null;
        methodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);
    }
