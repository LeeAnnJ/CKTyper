private static String convertToHex(byte[] data) {
    StringBuilder buf = new StringBuilder();
    for (byte b : data) {
        int halfbyte = (b &gt;&gt;&gt; 4) &amp; 0x0F;
        int two_halfs = 0;
        do {
            buf.append((0 &lt;= halfbyte) &amp;&amp; (halfbyte &lt;= 9) ? (char) ('0' + halfbyte) : (char) ('a' + (halfbyte - 10)));
            halfbyte = b &amp; 0x0F;
        } while (two_halfs++ &lt; 1);
    }
    return buf.toString();
}

public static String SHA1(String text) throws NoSuchAlgorithmException, UnsupportedEncodingException {
    MessageDigest md = MessageDigest.getInstance("SHA-1");
    byte[] textBytes = text.getBytes("iso-8859-1");
    md.update(textBytes, 0, textBytes.length);
    byte[] sha1hash = md.digest();
    return convertToHex(sha1hash);
}
SHA1("test"); //a94a8fe5ccb19ba61c4c0873d391e987982fbbd3
