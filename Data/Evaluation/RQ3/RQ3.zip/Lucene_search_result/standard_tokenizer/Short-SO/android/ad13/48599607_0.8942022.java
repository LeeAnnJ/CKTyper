public void showKeyboard(View view) {
    InputMethodManager myKeyboard = (InputMethodManager)getSystemService(Context
        .INPUT_METHOD_SERVICE);
    myKeyboard.showSoftInput(PN_input,InputMethodManager.SHOW_IMPLICIT);
}
