public static TextView mTextView;



   @Override
     public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
      View  view = inflater.inflate(R.layout.fragment_home, container, false);

     mTextView=(TextView)view.findviewById(R.id.name);

    return view;
    }
