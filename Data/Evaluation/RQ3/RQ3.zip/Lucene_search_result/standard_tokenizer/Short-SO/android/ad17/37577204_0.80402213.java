class CustomAdapter extends ArrayAdapter {

List&lt;String&gt; names;
LayoutInflater inflater;
Context context;
public CustomAdapter(Context context,  List&lt;String&gt; names) {
    super(context,R.layout.custom_row ,names);
   this.names=names;
    this.context=context;
}


@Override
public View getView(int position, View convertView, ViewGroup parent) {


   inflater=LayoutInflater.from(getContext());
    View customview=inflater.inflate(R.layout.custom_row,parent,false);
    String data=names.get(position);
   //String data1=names.get(position+1);
    TextView tv=(TextView)customview.findViewById(R.id.TeamA);
    tv.setText(data);
   //TextView tv1=(TextView)customview.findViewById(R.id.TeamB);
    //tv1.setText(data1);
    return customview;
}
