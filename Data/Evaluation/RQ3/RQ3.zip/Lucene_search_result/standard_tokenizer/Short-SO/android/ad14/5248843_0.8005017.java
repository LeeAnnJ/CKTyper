    InputMethodManager imm = (InputMethodManager) Main.mainClassInstance
.getSystemService(Main.mainClassInstance.INPUT_METHOD_SERVICE);

   imm.toggleSoftInput(InputMethodManager.SHOW_FORCED,0);
