public Bitmap viewToBitmap(View view) {
    Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
    Canvas canvas = new Canvas(bitmap);
    view.draw(canvas);
    try {
        FileOutputStream output = new FileOutputStream(Environment.getExternalStorageDirectory() + "/file.png");
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
        output.close();
    } catch (FileNotFoundException e) {
        e.printStackTrace();
    } catch (IOException e) {
        e.printStackTrace();
    }
    return bitmap;
}
