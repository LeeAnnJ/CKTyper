Resources resources = getResources();
Configuration configuration = resources.getConfiguration();
configuration.locale = new Locale("irn"); // or "off"
resources.updateConfiguration(configuration, resources.getDisplayMetrics());
