public static class StringUtil
{
  public static String limit(String value, int length)
  {
    StringBuilder buf = new StringBuilder(value);
    if (buf.length() &gt; length)
    {
      buf.setLength(length);
      buf.append("…");
    }

    return buf.toString();
  }
}
