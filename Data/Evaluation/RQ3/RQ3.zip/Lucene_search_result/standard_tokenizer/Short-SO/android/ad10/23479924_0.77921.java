CustomView view = (CustomView) findViewById(R.id.customViewId);
Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), 
view.getMeasuredHeight(), Bitmap.Config.ARGB_8888); 
Canvas bitmapHolder = new Canvas(bitmap); 
view.draw(bitmapHolder);
