package com.stoertje.countertje;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;

public class Opteller extends Activity {

public int counter = 0;
TextView mTextview;

public void Countup(){

    counter++;
}


@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_opteller);


    mTextview = (TextView)findViewById(R.id.counterdisplay); 
    mTextview.setText(counter); //If i remove this part the app doesnt crash

}

}
