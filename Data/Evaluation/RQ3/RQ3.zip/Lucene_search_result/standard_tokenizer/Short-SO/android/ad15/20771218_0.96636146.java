private LayoutInflater inflater;
private LinearLayout someLayout;
private TextView mTextView;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    mTextView = (TextView) findViewById( R.id.state2 );
    mTextView.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            // do something here
        }
    });
}
