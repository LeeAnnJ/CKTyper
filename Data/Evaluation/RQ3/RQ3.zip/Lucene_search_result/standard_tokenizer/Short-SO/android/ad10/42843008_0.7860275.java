//change the orientation of activity  
mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);  

// draw it on the canvas 
View view = activity.getWindow().getDecorView();
Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), ARGB_8888);
Canvas canvas = new Canvas(bitmap); 
activity.getWindow().getDecorView().draw(canvas);
