 btnsearch.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String mSearch = search.getText().toString().trim();
            if (mSearch.equals(&quot;&quot;)) {
                //Put Some Error like**
                Toast.makeText(context, &quot;Please Input City Name*&quot;, Toast.LENGTH_SHORT).show();
            } else {
                InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getCurrentFocus().getRootView().getWindowToken(), 0);
                api_key(String.valueOf(search.getText()));
            }
        }
    });
