public class NoteAdapter extends ArrayAdapter&lt;Note&gt;{

Context ctx;
MainActivity mainActivity;
public static CheckBox checkBox;

public NoteAdapter(Context context, int resource, ArrayList&lt;Note&gt; notes) {
    super(context, resource, notes);

    this.ctx = context;

}

@Override
public View getView(int position, View convertView, @NonNull ViewGroup parent) {
    //return super.getView(position, convertView, parent);



    if(convertView == null) {
        convertView = LayoutInflater.from(getContext())
                .inflate(R.layout.item_note, null);
    }


    mainActivity = (MainActivity) ctx;
    Note note = getItem(position);

    if(note != null) {
        TextView title = (TextView) convertView.findViewById(R.id.list_note_title);
        TextView content = (TextView) convertView.findViewById(R.id.list_note_content);
        TextView date = (TextView) convertView.findViewById(R.id.list_note_date);
        checkBox = (CheckBox) convertView.findViewById(R.id.checkBoxTest);



        Typeface music_font = Typeface.createFromAsset(getContext().getAssets(), "fonts/melodymakernotesonly.ttf");
        Typeface scribble_card = Typeface.createFromAsset(getContext().getAssets(), "fonts/the unseen.ttf");

        if (getThemeCountInt() == 0) {
            title.setTypeface(music_font);
        } else if (getThemeCountInt() == 1) {
            title.setTypeface(scribble_card);
        }

        content.setTypeface(scribble_card);

        title.setText(note.getTitle());
        date.setText(note.getDateTimeFormatted(getContext()));

        if(note.getContent().length() &gt; 25) {
            content.setText(note.getContent().substring(0,25) + "...");
        } else {
            content.setText(note.getContent());
        }

        if(note.getContent().length() &lt;= 0) {
            content.setText("(Empty Note..)");
        } else {
            content.setText(note.getContent());
        }

        if (note.getTitle().length() &lt;= 0) {
            title.setText("(Untitled)");
        } else {
            title.setText(note.getTitle());
        }

    }

    return convertView;
}

private int getThemeCountInt() {
    SharedPreferences mSharedPreferences = this.getContext().getSharedPreferences("theme", MODE_PRIVATE);
    int selectedTheme = mSharedPreferences.getInt("theme", 0);
    return selectedTheme;

}
