:androidAnsatTerminal:compileDebugJava
C:\...\src\main\java\de\ansat\terminal\activity\widgets\druckAssistent\FahrkartenArtSelector.java:131: warning: [deprecation] getDrawable(int) in Resources has been deprecated
                return activity.getResources().getDrawable(R.drawable.separator_gradient);
                                               ^
