emojIcon.setKeyboardListener(new EmojIconActions.KeyboardListener() {
    @Override
    public void onKeyboardOpen() {
        Log.e("Keyboard","open");
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onKeyboardClose() {
        Log.e("Keyboard","close");
        //maybe re-appear the input keyboard if you have to on emojikeyboardclose
        //InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        //imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }
});
