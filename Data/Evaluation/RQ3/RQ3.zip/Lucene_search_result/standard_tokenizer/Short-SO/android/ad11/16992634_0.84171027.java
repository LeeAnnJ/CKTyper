public String toString(){
    StringBuilder buf = new StringBuilder();

    buf.append(timeStamp); str.append(',');
    // ...
    // append all the other data

    return buf.toString();
}
