private MediaPlayer mediaPlayer;
TextView mTextView;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_security_system);
    mTextView = (TextView) findViewById(R.id.textView3);
