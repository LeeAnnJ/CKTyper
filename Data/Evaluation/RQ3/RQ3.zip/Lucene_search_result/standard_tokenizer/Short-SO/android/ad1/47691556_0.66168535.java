        public static void hideKeyboard(EditText edt) {
            InputMethodManager imm = (InputMethodManager) 
                 edt.getContext().getSystemService(Activity.INPUT_METHOD_SERVICE);              
            imm.hideSoftInputFromWindow(et.getWindowToken(), 0);
        }
