InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
imm.showSoftInput(mText, InputMethodManager.SHOW_IMPLICIT);
