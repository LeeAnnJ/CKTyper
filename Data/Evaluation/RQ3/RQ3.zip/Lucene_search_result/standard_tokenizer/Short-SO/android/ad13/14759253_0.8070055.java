@Override
public void onResume() {
   super.onResume();
   final View v = getDialog().findViewById(R.id.edit_text_id);
   v.post(new Runnable() {
      @Override
      public void run() {
        v.requestFocus();
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(v, InputMethodManager.SHOW_IMPLICIT);
      }
   });
 }
