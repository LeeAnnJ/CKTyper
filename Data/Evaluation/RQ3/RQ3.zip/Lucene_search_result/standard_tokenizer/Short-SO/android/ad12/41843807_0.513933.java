   public class LocaleLanguage {

    private static Locale mLocale;

    public static void setLocale(Locale locale) {
        mLocale = locale;
        if(mLocale != null) {
            Locale.setDefault(mLocale);
        }
    }

    public static void updateConfig(ContextThemeWrapper wrapper) {
        if(mLocale != null &amp;&amp; Build.VERSION.SDK_INT &gt;= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            Configuration configuration = new Configuration();
            configuration.setLocale(mLocale);
            wrapper.applyOverrideConfiguration(configuration);
        }
    }

    public static void updateConfig(Application app, Configuration configuration) {
        if(mLocale != null &amp;&amp; Build.VERSION.SDK_INT &lt; Build.VERSION_CODES.JELLY_BEAN_MR1) {
            //Wrapping the configuration to avoid Activity endless loop
            Configuration config = new Configuration(configuration);
            config.locale = mLocale;
            Resources res = app.getBaseContext().getResources();
            res.updateConfiguration(config, res.getDisplayMetrics());
        }
    }
}
