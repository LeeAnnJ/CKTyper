public class ArticleAdapter extends BaseAdapter {

    public ArrayList&lt;Article&gt; getItems_producte() {
        return items_producte;
    }

    private Activity activity;
    private ArrayList&lt;Article&gt; items_producte;

    public ArticleAdapter(Activity activity, ArrayList&lt;Article&gt; items_producte){
        this.activity = activity;
        this.items_producte= items_producte;
    }

        @Override
    public int getCount() {
        if(items_producte==null){
            return 0;
        }
        else{
            return items_producte.size();
        }   }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return items_producte.get(position);
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(int position, View contentView, ViewGroup Parent) {
        // TODO Auto-generated method stub
        View view = contentView;

        if(view==null){
            LayoutInflater inflate =(LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflate.inflate(R.layout.info_product, null,false);
        }

        Article item_producte = items_producte.get(position);

        TextView id = (TextView)view.findViewById(R.id.list_product_id);
        TextView fabricant = (TextView)view.findViewById(R.id.list_product_fabricant);
        TextView nom = (TextView)view.findViewById(R.id.list_product_nom);
        TextView preu = (TextView)view.findViewById(R.id.list_product_preu);
        TextView stock = (TextView)view.findViewById(R.id.list_product_stock);

        id.setText(Integer.toString(item_producte.getId()));
        fabricant.setText(item_producte.getFabricante());
        nom.setText(item_producte.getNom());
        preu.setText(Float.toString(item_producte.getPreu()));
        stock.setText(Integer.toString(item_producte.getStock()));

        fabricant.setTextColor(activity.getResources().getColor(R.color.fabricant));
        nom.setTextColor(activity.getResources().getColor(R.color.fabricant));
        preu.setTextColor(activity.getResources().getColor(R.color.fabricant));
        stock.setTextColor(activity.getResources().getColor(R.color.fabricant));

        if(position%2==0){
            view.setBackgroundColor(activity.getResources().getColor(R.color.files_parelles));

        }
        else{
            view.setBackgroundColor(activity.getResources().getColor(R.color.files_imparelles));
        }

        /*STOCK COLOR*/
        if(item_producte.getStock()&lt;=0){
            view.setBackgroundColor(activity.getResources().getColor(R.color.stock_null_bg));

            fabricant.setTextColor(activity.getResources().getColor(R.color.stock_null_tx));
            nom.setTextColor(activity.getResources().getColor(R.color.stock_null_tx));
            preu.setTextColor(activity.getResources().getColor(R.color.stock_null_tx));
            stock.setTextColor(activity.getResources().getColor(R.color.stock_null_tx));

        }

        return view;
    }


    public void setItems_producte(ArrayList&lt;Article&gt; items_producte) {
        this.items_producte = items_producte;
        this.notifyDataSetChanged();
    }

}
