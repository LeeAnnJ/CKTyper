public class LanguageManager {
    private Context ctx;
    private SharedPreferences sharedPreferences;
    public LanguageManager(Context ctx) {
        this.ctx = ctx;
        sharedPreferences=ctx.getSharedPreferences(&quot;LANG&quot;,Context.MODE_PRIVATE);
    }
    public void updateLang(String code)
    {
        Locale locale = new Locale(code);
        Locale.setDefault(locale);
        Resources resources = ctx.getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.locale=locale;
        resources.updateConfiguration(configuration,resources.getDisplayMetrics());
        setLang(code);
    }


    public String getLang()
    {
        return sharedPreferences.getString(&quot;lang&quot;,&quot;en&quot;);
    }
    public void setLang(String code)
    {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(&quot;lang&quot;,code);
        editor.commit();
    }
}
