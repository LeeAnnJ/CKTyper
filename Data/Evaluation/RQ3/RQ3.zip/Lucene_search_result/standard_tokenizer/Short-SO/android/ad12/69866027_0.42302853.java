@Override
protected void attachBaseContext(Context context) {
    sharedPreferences = context.getSharedPreferences(&quot;prefs&quot;, MODE_PRIVATE); // adjust the name of the SharedPreference to yours
    String language = sharedPreferences.getString(&quot;Language&quot;, &quot;en&quot;);
    super.attachBaseContext(MyContextWrapper.wrap(context, language));
    Locale locale = new Locale(language);
    Resources resources = getBaseContext().getResources();
    Configuration conf = resources.getConfiguration();
    conf.locale = locale;
    resources.updateConfiguration(conf, resources.getDisplayMetrics());
}
