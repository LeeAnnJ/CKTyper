public static void hideKeypad(Activity context) {
    View view = context.getCurrentFocus();
    if (view != null) {
      InputMethodManager imm =
      (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
      imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
   }
}
