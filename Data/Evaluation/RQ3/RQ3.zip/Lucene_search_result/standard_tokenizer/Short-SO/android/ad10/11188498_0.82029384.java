private Bitmap getViewBitmap ( String textString ) {
    View view = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.your_layout, null);
    TextView txt = (TextView)view.findViewById(R.id.txtId);
    txt.setText(textString);

    int spec = MeasureSpec.makeMeasureSpec(187, 187);
    view.measure(spec,spec);
    view.layout(0, 0, 187, 187);

    Bitmap cache = Bitmap.createBitmap(
            view.getWidth(), view.getHeight(),
            Bitmap.Config.ARGB_8888);

    Canvas canvas = new Canvas(cache);
    view.draw(canvas);

    return cache;
}
