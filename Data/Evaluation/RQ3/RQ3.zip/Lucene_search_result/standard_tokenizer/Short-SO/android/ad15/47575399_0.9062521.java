public class MainActivity extends AppCompatActivity {
TextView mTextView;    //declare mTextView outside the onCreate() method as a Global String variable.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTextView = findViewById(R.id.textView);
        AsyncExample asyncExample = new AsyncExample();
        asyncExample.execute();
    }
}
