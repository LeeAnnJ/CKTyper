public class NewtworkActivity extends AppCompatActivity {
    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = (TextView) findViewById(R.id.text_view);
        ....
    }

    private class MySyncTask extends AsyncTask {
        ....
        @Override
        protected Object doInBackground(Object[] objects) {
            ....
            while (true) {
                while ((lineFromServer = mFromServer.readLine()) != null) {
                    Object object[] = { lineFromServer };
                    publishProgress(object);
                }
             }
        }

        ....

        @Override
        protected void onProgressUpdate(Object[] values) {
            super.onProgressUpdate(values);
            if (values.length &gt; 0) {
                mTextView.append(values[0]+System.getProperty("line.separator"));
        }
    }
}
