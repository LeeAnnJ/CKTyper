private Element generatePdfFromView(View view) {
        Bitmap bitmap = getBitmapFromView(view);
        document = new PdfDocument();


        PdfDocument.PageInfo myPageInfo = new PdfDocument.PageInfo.Builder(595,842,1).create();
        PdfDocument.Page myPage = document.startPage(myPageInfo);
        
        Canvas canvas = myPage.getCanvas();
        canvas.drawBitmap(bitmap,0,0,null);
        document.finishPage(myPage);

        createFile();

        return null;
    }





private Bitmap getBitmapFromView(View view) {

        Bitmap ImgBitmap= Bitmap.createBitmap(view.getWidth(),view.getHeight(),Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(ImgBitmap);



        Drawable drawable = view.getBackground();
        if (drawable != null){
            drawable.draw(canvas);
        } else {
            canvas.drawColor(Color.WHITE);
        }
        view.draw(canvas);

        return ImgBitmap;


    }


