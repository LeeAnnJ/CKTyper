public class Case extends RelativeLayout {
    private TextView ta;
    private TextView tb;
    private TextView tc;
    private TextView td;
    public Case(Context context) {
        super(context);
        // TODO Auto-generated constructor stub
        init();
    }

    public Case(Context context, AttributeSet attrs) {
        super(context);
        // TODO Auto-generated constructor stub
        init();
    }

    private void init() {
        // TODO Auto-generated method stub
        int wrap = LayoutParams.WRAP_CONTENT;
        LayoutParams top = new RelativeLayout.LayoutParams(wrap, wrap);
        LayoutParams right = new RelativeLayout.LayoutParams(wrap, wrap);
        LayoutParams bottom = new RelativeLayout.LayoutParams(wrap, wrap);
        LayoutParams left = new RelativeLayout.LayoutParams(wrap, wrap);
        top.addRule(RelativeLayout.CENTER_HORIZONTAL);
        top.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        right.addRule(RelativeLayout.CENTER_VERTICAL);
        right.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        bottom.addRule(RelativeLayout.CENTER_HORIZONTAL);
        bottom.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        left.addRule(RelativeLayout.CENTER_VERTICAL);
        left.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        ta = new TextView(getContext());
        tb = new TextView(getContext());
        tc = new TextView(getContext());
        td = new TextView(getContext());
        ta.setText("a");
        tb.setText("b");
        tc.setText("c");
        td.setText("d");
        this.addView(ta,top);
        this.addView(tb,right);
        this.addView(tc,bottom);
        this.addView(td,left);
    }

     void setNumbers(String a, String b, String c, String d){
        ta.setText(a);
        tb.setText(b);
        tc.setText(c);
        td.setText(d);
    }
}
