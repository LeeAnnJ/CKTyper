public static void showSettingGuide(AppCompatActivity activity, Preference... view){
        new TapTargetSequence(activity)
                .targets(
                        TapTarget.forView(activity.findViewById(view[0].getLayoutResource()),activity.getResources().getString(R.string.night_mode),activity.getResources().getString(R.string.NightModeGuide))
                .cancelable(false),
                        TapTarget.forView(activity.findViewById(view[1].getLayoutResource()),activity.getResources().getString(R.string.automatic_night_text),activity.getResources().getString(R.string.AutoNightModeGuide))
                .cancelable(false),
                        TapTarget.forView(activity.findViewById(view[2].getLayoutResource()),activity.getResources().getString(R.string.keepScreenOn),activity.getResources().getString(R.string.keepScreenGuide))
                .cancelable(false),
                        TapTarget.forView(activity.findViewById(view[3].getLayoutResource()),activity.getResources().getString(R.string.appState),activity.getResources().getString(R.string.appStateGuide)))
                .listener(new TapTargetSequence.Listener() {
                    @Override
                    public void onSequenceFinish() {
                        activity.getSharedPreferences(Constants.GuidePrefs,Context.MODE_PRIVATE).edit().putBoolean(Constants.setting_guide_prefs,true).apply();
                    }

                    @Override
                    public void onSequenceStep(TapTarget lastTarget, boolean targetClicked) {}

                    @Override
                    public void onSequenceCanceled(TapTarget lastTarget) {
                        activity.getSharedPreferences(Constants.GuidePrefs,Context.MODE_PRIVATE).edit().putBoolean(Constants.setting_guide_prefs,true).apply();
                    }
                })
                .start();
    }
