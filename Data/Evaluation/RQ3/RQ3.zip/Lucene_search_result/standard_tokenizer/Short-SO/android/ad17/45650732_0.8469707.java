Typeface hero = Typeface.createFromAsset(getContext().getAssets(),"fonts/Hero Light.otf");

    for (int i = 0; i &lt; tabLayout.getTabCount(); i++) {
        //noinspection ConstantConditions
   TextView tv=
  (TextView)LayoutInflater.from(this).inflate(R.layout.item_tab,null);
        tv.setTypeface(hero);
        tabLayout.getTabAt(i).setCustomView(tv);

    }
