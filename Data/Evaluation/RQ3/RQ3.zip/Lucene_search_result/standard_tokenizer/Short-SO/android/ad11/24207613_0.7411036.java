public String exportAsCsv(CqlQuery query) {
    Iterator&lt;String&gt; result = queryService.execute(.....);
    StringBuilder buf = new StringBuilder();
    for (String nextLine : result) {
       buf.append(nextLine);
    }
    return buf.toString();
}
