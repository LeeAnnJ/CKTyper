public static String toString(int[] arr) {
    StringBuilder buf = new StringBuilder();
    for (int i = 0, n = arr.length; i &lt; n; i++) {
        if (i &gt; 0) {
            buf.append(&quot;, &quot;);
        }
        buf.append(arr[i]);
    }
    return buf.toString();
}
