public class GetConvo extends Activity {

public static String getqn(Activity activity) {
int newqn=activity.getResources().getIdentifier("a", "string","com.kings.englishforretail");
String opt1 = activity.getString(newqn);
return opt1;
}
