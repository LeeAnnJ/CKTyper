public class MainActivity extends ActionBarActivity {

RequestQueue queue = Volley.newRequestQueue(this);
String url = "http://www.google.com";

//dont mean to do that...
//final TextView mTextView = (TextView)findViewById(R.id.text);
TextView mTextView;

@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.activity_main);
mTextView = (TextView)findViewById(R.id.text);

StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
    new Response.Listener&lt;String&gt;() {
@Override
public void onResponse(String response) {
    mTextView.setText("Response is: " + response.substring(0, 500));
}
}, new Response.ErrorListener() {
@Override
public void onErrorResponse(VolleyError error) {
    mTextView.setText("That didnt work!");
}
});

queue.add(stringRequest);
}


}
