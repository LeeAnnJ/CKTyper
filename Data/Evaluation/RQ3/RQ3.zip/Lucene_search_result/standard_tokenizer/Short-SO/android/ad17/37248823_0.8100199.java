private void getAddressKeyValueFile()
    {
        Context context = getContext().getApplicationContext();

        String fileName = getResources.getString(R.string.filename);
        SharedPreferences sharedPreferences = context.getSharedPreferences(fileName,Context.MODE_PRIVATE);

        String key = getResources.getString(R.string.address);
        String existingAddress = sharedPreferences.getString(key,null);

        if(existingAddress != null)
        {
            TextView textView = (TextView) getActivity().findViewById(R.id.textView);
            textView.setText(existingAddress);
        }

    }
