   public LikedListAdapter(Context context, int resource, String[] restID, String[] restName, String[] restAddr1, String[] restAddr2, String[] restImgPath) {
    super(context, resource);

    this.context = context;
    this.resource = resource;

    this.restID = restID;
    this.restName = restName;
    this.restAddr1 = restAddr1;
    this.restAddr2 = restAddr2;
    this.restImgPath = restImgPath;
}

@Override
public View getView(int position, View convertView, ViewGroup parent)
{
    LinearLayout likedItemsView;


    if(convertView==null) {
        likedItemsView = new LinearLayout(getContext());
        String inflater = Context.LAYOUT_INFLATER_SERVICE;
        LayoutInflater vi;
        vi = (LayoutInflater)getContext().getSystemService(inflater);
        vi.inflate(resource, likedItemsView, true);
    }
    else {
        likedItemsView = (LinearLayout) convertView;
    }

    ImageView restaurantImg = (ImageView)likedItemsView.findViewById(R.id.listItemThumbImg);
    TextView restaurantName =(TextView)likedItemsView.findViewById(R.id.listItemTitle);
    TextView restaurantDesc = (TextView)likedItemsView.findViewById(R.id.listItemSubText);

    restaurantName.setText(restName[position]);
    restaurantDesc.setText(restAddr1[position] + ", " + restAddr2[position]);

    Picasso
            .with(getContext())
            .load(restImgPath[position])
            .into(restaurantImg);

    return likedItemsView;
}
