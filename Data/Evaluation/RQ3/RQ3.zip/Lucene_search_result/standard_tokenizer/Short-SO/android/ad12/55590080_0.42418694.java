public class ViewHolder extends RecyclerView.ViewHolder {
    private TextView textViewView;
    private ImageView imageView;

    public ViewHolder(View itemView) {
        super(itemView);

        textViewView = (TextView) itemView.findViewById(R.id.text);
        imageView = (ImageView) itemView.findViewById(R.id.image);
    }

    public void bind(Departement departement, Activity activity){
        textViewView.setText(departement.getText());
        String uri = departement.getImageUrl();
        int imageResource = activity.getResources().getIdentifier(uri, null, activity.getPackageName());
        Drawable res = activity.getResources().getDrawable(imageResource);
        imageView.setImageDrawable(res);
    }
}
