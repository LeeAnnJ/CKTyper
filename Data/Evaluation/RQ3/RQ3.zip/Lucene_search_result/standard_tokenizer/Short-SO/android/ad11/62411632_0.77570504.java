StringBuilder buf = new StringBuilder();
list.forEach(buf::append);
String result = buf.toString();
