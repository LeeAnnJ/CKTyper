package imamalsajadsayings.android.com;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;


public class SecondActivity extends Activity {
private TextView mTextView;


@Override
protected void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
setContentView(R.layout.second);
Intent i=getIntent();
String text=i.getStringExtra("mytext");
mTextView=(TextView)findViewById(R.id.two);
mTextView.setText(text);

}
}
