public class Card_activity extends AppCompatActivity implements View.OnClickListener{

    TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.massive_places);

        mTextView = findViewById(R.id.head_name);
        String name = getIntent().getStringExtras("name")
        mTextView.setText(name);
    }
}
