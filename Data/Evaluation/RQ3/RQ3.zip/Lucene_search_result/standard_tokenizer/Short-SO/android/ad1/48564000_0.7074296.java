public class KeyboardCloseListener implements View.OnFocusChangeListener {

    private Activity activity;

    public KeyboardCloseListener(Activity context) {
        this.activity = context;
    }

    @Override
    public void onFocusChange(View view, boolean b) {
        if (!b)
            closeKeyboard(view);
    }

    public void closeKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}  
