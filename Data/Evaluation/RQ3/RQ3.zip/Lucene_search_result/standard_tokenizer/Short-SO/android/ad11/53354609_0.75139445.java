public static String removeCapitalFirstLetterWords(String str) {
    StringBuilder buf = new StringBuilder();

    for (String word : str.split("\\W+")) {
        if (Character.isUpperCase(word.charAt(0)))
            continue;
        if (buf.length() &gt; 0)
            buf.append(' ');
        buf.append(word);
    }

    return buf.toString();
}
