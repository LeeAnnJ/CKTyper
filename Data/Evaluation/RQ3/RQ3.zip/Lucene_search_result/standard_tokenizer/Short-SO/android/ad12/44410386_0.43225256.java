public class ImageTargetTracker {
    public static interface Listner {
        public void onButtonClicked(int index);
    }
    private Listner mListner;
    protected Activity mCurrentActivity;
    public void setActivity(Activity activity, Listner listner)
    {
        mCurrentActivity = activity;
        mListner = listner;

        mCurrentActivity.runOnUiThread(new Runnable() {
            public void run() {
                LayoutInflater inflater = mCurrentActivity.getLayoutInflater();
                Resources resources =  mCurrentActivity.getResources();
                String pkgName = mCurrentActivity.getPackageName();

                int id = resources.getIdentifier("camera_layout", "layout", pkgName);
                View view = inflater.inflate(id, null);

                mCurrentActivity.addContentView(view, param);
                //INITIALIZING UI ELEMENTS HERE (DISPLAYED ON TOP OF CAMERA)
    }


    public void OnMarkerFound(){

        mCurrentActivity.runOnUiThread(new Runnable() {
            public void run() {
                //Showing some UI elements
            }
        });
    }
}
