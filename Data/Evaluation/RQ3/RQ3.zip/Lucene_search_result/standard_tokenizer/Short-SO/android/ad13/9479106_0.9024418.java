public void onClick(View v) {

             EditText Edit_perceel_nr2 = (EditText)findViewById(R.id.Perceel_nr2);;
             ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(Edit_perceel_nr2, InputMethodManager.SHOW_IMPLICIT);
