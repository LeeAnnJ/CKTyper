private ImageView mImageView;
private TextView mTextView;
private Button mButton;



@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);



    btnShare = (Button)findViewById(R.id.btnShare);

    mImageView = (ImageView)findViewById(R.id.imageView);
    mTextView = (TextView)findViewById(R.id.facts);
    mButton = (Button)findViewById(R.id.button);

    showRandomFacts();

    mButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            showRandomFacts();

        }
    });
