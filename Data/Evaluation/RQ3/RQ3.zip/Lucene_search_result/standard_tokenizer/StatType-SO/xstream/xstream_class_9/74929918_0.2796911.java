package Utilities;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;


public class DatabaseConnectionUtils {
    public static Properties readPropertiesFile(String fileName) throws IOException {
        FileInputStream fis = null;
        Properties prop = null;
        try {
            fis = new FileInputStream(fileName);
            prop = new Properties();
            prop.load(fis);
        } catch(FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } finally {
            fis.close();
        }
        return prop;
    }

    public static void connect(String serverIP, Integer port, String keyspace, String username, String password) {
        Cluster cluster;
        Session session;
        Cluster.Builder b = Cluster.builder().addContactPoint(serverIP);
        if (port != null) {
            b.withPort(port).withCredentials(username,password);
        }
        cluster = b.build();
        session = cluster.connect(keyspace);

        String cqlStatement = &quot;select * from partner_configuration where partnerid='15918' allow filtering;&quot;;
        for (Row row : session.execute(cqlStatement)) {
            System.out.println(row.toString());
        }
        session.close();
    }

    public static void main(String[] args) throws IOException {

        Properties prop = readPropertiesFile(&quot;C:\\NMS-Framework\\untitled\\src\\test\\resources\\DB-Credentials.properties&quot;);
        String address=prop.getProperty(&quot;ServerIP&quot;);
        int port= Integer.parseInt(prop.getProperty(&quot;port&quot;));
        String keyspace=prop.getProperty(&quot;keyspace&quot;);
        String username=prop.getProperty(&quot;username&quot;);
        String password= prop.getProperty(&quot;password&quot;);

        connect(address,port,keyspace,username,password);



    }
    }
