public class Host {
    private String ip;
    private int port;
    private boolean isActive;

    public Host(String ip, int port) {
        this.ip = ip;
        this.port = port;
        this.isActive = true;
    }

    public synchronized boolean isActive() {
        return isActive;
    }

    public synchronized void setActive(boolean active) {
        isActive = active;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }
}
