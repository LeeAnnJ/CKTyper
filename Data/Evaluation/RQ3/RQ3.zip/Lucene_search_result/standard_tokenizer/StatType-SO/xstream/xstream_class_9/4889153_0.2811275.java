public class ParentData implements Serializable {
  // [...]
  private static ClassLoader classLoaderForImport = ParentData.class.getClassLoader();
  // [...]
  public static void setClassLoaderForImport(ClassLoader classLoaderForImport) {
    ParentData.classLoaderForImport = classLoaderForImport;
  }
  // [...]
  public static Lumicon importFromXMLFile(String path) {
    return importFromFile(new DomDriver(), path);
  }
  private static ParentData importFromFile(HierarchicalStreamDriver driver, String path) {
    try {
      XStream xstream = new XStream(driver);
      //set the classloader as the default one won't work in any case
      xstream.setClassLoader(ParentData.classLoaderForImport);
      xstream.alias("ParentData", classLoaderForImport.loadClass(ParentData.class.getName()));//ParentData.class);
      xstream.alias("ChildData", classLoaderForImport.loadClass(ChildData.class.getName()));//ChildData.class);
      Reader reader = new FileReader(path);
      Object object = xstream.fromXML(reader);
      return (ParentData) object;
    } catch (ClassNotFoundException ex) {
      System.out.println("This did not work.");
    } catch (FileNotFoundException e) {
      System.out.println("File " + path + " not found.");
    }
  }
// [...]
}
