public void loop(String serverIP, String GSID)  {

    while (true) {

        try {
            dataTransmission(serverIP, GSID);
            TimeUnit.SECONDS.sleep(10);

        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }
}

public void dataTransmission(String GSID,String serverIP ) {


    System.out.println(&quot;GS ID=&quot; + GSID);
    System.out.println(&quot;server IP=&quot; + serverIP);


    Socket s1 = null;
    BufferedReader br = null;
    BufferedReader is = null;
    PrintWriter pwr = null;
    String response = null;


    String ServerIP = &quot;localhost&quot;;


    try {
        s1 = new Socket(ServerIP, 4445);
        br = new BufferedReader(new InputStreamReader(System.in));
        is = new BufferedReader(new InputStreamReader(s1.getInputStream()));
        pwr = new PrintWriter(s1.getOutputStream());

    } catch (IOException e) {
        System.out.println(e);
    }



    // send GSID to Server
    pwr.println(GSID);
    pwr.flush();


    // get GS IP
    String GSIP = null;
    try {
        GetGasStationIP gsip = new GetGasStationIP();
        GSIP = gsip.getSourceIP();

    } catch (UnknownHostException e) {
        System.out.println(e);
    }


    // send GSIP to Server
    pwr.println(GSIP);
    pwr.flush();
    //response = is.readLine();
    //System.out.println(&quot;Server Response : &quot; + response);


    // send time
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(&quot;yyyy-MM-dd HH:mm:ss&quot;);
    LocalDateTime now = LocalDateTime.now();
    pwr.println(dtf.format(now));
    pwr.flush();
    //response = is.readLine();
    //System.out.println(&quot;Server Response : &quot; + response);


    try {
        is.close();
        pwr.close();
        br.close();
        s1.close();

    } catch (IOException e) {
        e.printStackTrace();
    }

    System.out.println(&quot;Connection Closed&quot;);
    System.out.println(&quot;&quot;);
}
