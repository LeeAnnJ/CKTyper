
public class PingServer implements Runnable {
    private String serverip;
    public PingServer(String ip) {
        this.serverip = ip;
    }
    public void run() {

        try {
            MinecraftPingReply data = new MinecraftPing().getPing(new MinecraftPingOptions().setHostname(serverip).setPort(25565));
            //sending
            String servercount = data.getPlayers().getOnline() + &quot;/&quot; + data.getPlayers().getMax();


          System.out.println(serverip + &quot; &quot; + servercount + &quot; pineapple&quot;);



        } catch (IOException |  IllegalStateException | IllegalArgumentException | JsonSyntaxException exception){
            System.out.println(&quot;offline&quot; + serverip + “ ” + exception);
        }


    }
}



java.net.SocketTimeoutException: Connect timed out
    at java.base/sun.nio.ch.NioSocketImpl.timedFinishConnect(NioSocketImpl.java:546)
    at java.base/sun.nio.ch.NioSocketImpl.connect(NioSocketImpl.java:597)
    at java.base/java.net.SocksSocketImpl.connect(SocksSocketImpl.java:333)
    at java.base/java.net.Socket.connect(Socket.java:645)
    at com.corporate.utils.mcping.MinecraftPing.getPing(MinecraftPing.java:66)
    at com.corporate.database.refresh.ReplaceDataDB.run(ReplaceDataDB.java:36)
    at java.base/java.lang.Thread.run(Thread.java:831)
Exception in thread &quot;Thread-16145&quot; java.lang.NullPointerException
