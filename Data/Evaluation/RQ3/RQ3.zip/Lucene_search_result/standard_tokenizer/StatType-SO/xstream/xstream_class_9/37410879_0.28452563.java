public class SessionData implements Serializable {
    private static final long serialVersionUID = 1L;
    private int counter;
    private String ip;

    public int getCounter() {
        return counter;
    }
    public void setCounter(int counter) {
        this.counter = counter;
    }

    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }

    public SessionData() {
    }
}
