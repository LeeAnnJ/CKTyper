public class Server implements Runnable {

    ServerSocket sersock;
    Socket sock;

    @Override
    public void run() {

        try {
            sersock = new ServerSocket(9000);
            while (true) {
                sock = sersock.accept();
                new Thread(new client_handler(sock)).start();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

 public class client_handler implements Runnable { //Inner class.

        Socket sock;
        DataInputStream dis;
        DataOutputStream dos;
        String ip;

        public client_handler(Socket sock) {
            this.sock = sock;
        }

        public client_handler(String ip) {
            this.ip = ip;
        }

        public String getIp() {
            return ip;
        }

        public void setIp(String ip) {
            this.ip = ip;
        }

        @Override
        public void run() {

            try {
                dis = new DataInputStream(sock.getInputStream());
                dos = new DataOutputStream(sock.getOutputStream());

                ip = sock.getInetAddress().getHostAddress();
                System.out.println(ip);

                al.add(this);

                data.add(this);
            } catch (Exception e) {

                data.remove(this);

            }
        }
    }
}
