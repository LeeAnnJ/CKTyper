package com.pfe.config;
import java.io.IOException;

public class FFPlayThread implements Runnable {

private  String ip;
private  int port;
private  FFmpeg fFmpeg;


public FFPlayThread(FFmpeg fFmpeg) {
    this.fFmpeg = fFmpeg;
}


public FFPlayThread(String ip, int port) {
    this.ip = ip;
    this.port = port;
    this.fFmpeg = new FFmpeg(ip, port);
}


@Override
public void run() {

    try {
        fFmpeg.executeFFplay();
    }
    catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

}


public String getIp() {
    return ip;
}


public void setIp(String ip) {
    this.ip = ip;
}


public int getPort() {
    return port;
}


public void setPort(int port) {
    this.port = port;
}


public FFmpeg getfFmpeg() {
    return fFmpeg;
}


public void setfFmpeg(FFmpeg fFmpeg) {
    this.fFmpeg = fFmpeg;
}}
