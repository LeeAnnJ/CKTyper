    private void setupConnection(String serverIP, String port){
    int portInt = Integer.parseInt(port);
    serverIp = serverIP;
    try{
        IP = InetAddress.getByName(serverIP);
        clientSocket = new Socket(IP,portInt);
        JOptionPane.showMessageDialog(new JFrame(), "Successfully connected to Server");
        in = new ObjectInputStream(clientSocket.getInputStream());
        out = new PrintWriter(clientSocket.getOutputStream(), true);
        scanIn = new Scanner(clientSocket.getInputStream());
        a = (String[]) in.readObject();
        if(scanIn.nextLine().equals("returnIP"))out.println(clientIp);
        getGamesList(a);
        Thread tss = new Thread(new ClientThread());
        tss.start();
        System.out.println("w");
    }
    catch(Exception e){
        System.out.println("ErrorC :" +e.getMessage());
    }
}
