public class WebService {
//Namespace of the Webservice - can be found in WSDL
private static String NAMESPACE = "http://service.marcusjacobsson.com/";
//Webservice URL - WSDL File location    
private static String URL = "http://[myRoutersIPAddress]:8080/WebServiceProject/HelloWebService?wsdl";
//SOAP Action URI again Namespace + Web method name
private static String SOAP_ACTION = "http://service.marcusjacobsson.com/";

public static String[] invokeHelloWorldWS(String webMethName) {
    String[] resultArray = null;
    // Create request
    SoapObject request = new SoapObject(NAMESPACE, webMethName);       
    // Create envelope
    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
            SoapEnvelope.VER11);
    // Set output SOAP object
    envelope.setOutputSoapObject(request);
    // Create HTTP call object
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

    try {
        // Invoke web service
        androidHttpTransport.call(SOAP_ACTION+webMethName, envelope);
        // Get the response
        SoapObject response = (SoapObject) envelope.bodyIn;

        if(response!=null){
            int count = response.getPropertyCount();
            resultArray = new String[count];
            for(int i=0;i&lt;count;i++){
                resultArray[i]=response.getProperty(i).toString();
            }
        }
        return resultArray;

    } catch (Exception e) {
        //Print error
        e.printStackTrace();
    } 
    //Return resTxt to calling object
    return resultArray;
}   

}
