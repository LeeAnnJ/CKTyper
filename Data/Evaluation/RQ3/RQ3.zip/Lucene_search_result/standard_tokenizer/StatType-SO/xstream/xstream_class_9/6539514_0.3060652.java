public static void upload_files(String un, String pw, String ip, String dir, String fn){
    FTPClient client = new FTPClient();
    FileInputStream fis = null;

    try {
        client.connect(ip);
        client.login(un, pw);

        String filename = dir+"/"+fn;
        fis = new FileInputStream(filename);

        client.storeFile(filename, fis);
        client.logout();
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        try {
            if (fis != null) {
                fis.close();
            }
            client.disconnect();
            System.out.println("uploaded");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
