private void unKnown(List&lt;XY&gt; entries) 
    {

         //Initialize soap request + add parameters
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME); 

        PropertyInfo entriesProp =new PropertyInfo();
        entriesProp.setName("entries");          
        entriesProp.setValue(entries);
        entriesProp.setType(ArrayList.class);


        //Use this to add parameters
        request.addProperty(entriesProp);
        //Declare the version of the SOAP request

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(request);
        envelope.addMapping(NAMESPACE, "XY", XY.XY_CLASS);

        envelope.dotNet = true;

        try {

              HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

              //this is the actual part that will call the webservice

              androidHttpTransport.call(SOAP_ADDCONTACTS, envelope);

              // Get the SoapResult from the envelope body.

              if (envelope.bodyIn instanceof SoapFault) 
              {
                  String str= ((SoapFault) envelope.bodyIn).faultstring;
                  Log.i("", str);
              } 
              else 
              {
                  SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
                  if(resultsRequestSOAP != null)
                  {
                      Log.i("AddContacts", "Adding Contacts succeeded");
                  }
              }
        }
        catch (Exception e)
        {
              e.printStackTrace();
        }
    }**
