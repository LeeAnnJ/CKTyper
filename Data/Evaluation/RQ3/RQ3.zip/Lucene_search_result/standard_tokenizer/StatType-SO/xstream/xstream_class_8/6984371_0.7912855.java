    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME); //Set up request
    request.addProperty("Account", "****");  //Variable name, value.  
    request.addProperty("Name", "****");
    request.addProperty("Password", "****");
    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
    envelope.setOutputSoapObject(request); //Prepare the request
    HttpTransportSE HttpTransport = new HttpTransportSE(URL); 
    HttpTransport.debug = true;

    HttpTransport.call(SOAP_ACTION, envelope); //Send Request
    SoapObject result = null;
    result = (SoapObject)envelope.getResponse();

    result.toString();
