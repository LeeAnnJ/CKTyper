  String METHOD_NAME = "getCityTime";
  String SOAP_ACTION = "http://www.Nanonull.com/TimeService/getCityTime";
  String NAMESPACE = "http://www.nanonull.com/TimeService/";
  String URL = "http://www.nanonull.com/TimeService/TimeService.asmx";

  SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

  request.addProperty("city", "Chicago");

  SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
    SoapEnvelope.VER11);

  envelope.setOutputSoapObject(request);

  HttpTransportSE httpTransport = new HttpTransportSE(URL);
  try {
   httpTransport.call(SOAP_ACTION, envelope);
  } catch (IOException e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  } catch (XmlPullParserException e) {
   // TODO Auto-generated catch block
   e.printStackTrace();
  } // This sends a soap

  System.out.println(envelope.bodyIn.toString());
