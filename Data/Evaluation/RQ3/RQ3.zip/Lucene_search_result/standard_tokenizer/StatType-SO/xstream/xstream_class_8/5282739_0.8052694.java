package projects.ksoap2sample;

import android.app.Activity;
import android.os.Bundle;
import org.ksoap2.SoapEnvelope;  
import org.ksoap2.serialization.SoapObject;  
import org.ksoap2.serialization.SoapSerializationEnvelope;  
import org.ksoap2.transport.HttpTransportSE;  
import android.widget.Button;
import android.view.View.OnClickListener;
//import com.example.android.R;

import android.app.*;  
import android.os.*;  
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;    
public class ksoap2sample extends Activity {      /** Called when the activity is first created. */      
    private static final String SOAP_ACTION = "http://tempuri.org/HelloWorld";      
    private static final String METHOD_NAME = "HelloWorld";      
    private static final String NAMESPACE = "http://tempuri.org/";      
    private static final String URL = "http://173.161.245.235/test/Service.asmx";      
    TextView tv; 
    String[] results;
    @Override      
    public void onCreate(Bundle savedInstanceState) {          
    super.onCreate(savedInstanceState);          
    setContentView(R.layout.main);

    tv=(TextView)findViewById(R.id.TextView01);
    call();
    }
    /* try 
    {                
    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);                
    //request.addProperty("prop1", "myprop");                
    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);              
    envelope.dotNet=true;              
    envelope.setOutputSoapObject(request);                
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);                
    androidHttpTransport.call(SOAP_ACTION, envelope);                
    Object result = (Object)envelope.getResponse();                 
    String[] results = (String[])  result;              
    tv.setText( ""+results[0]);           
    } 
    catch (Exception e) 
    {              
    tv.setText(e.getMessage());              
    }      
    }  */


    public void call()
    {
            try {

            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

           // request.addProperty("passonString", "Rajapandian");

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet=true;
            envelope.setOutputSoapObject(request);

            HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
            androidHttpTransport.call(SOAP_ACTION, envelope);

            Object result = (Object)envelope.getResponse();
            String str1=result.toString();

            System.out.println("length="+result.toString().length());


            for(int i=0;i&lt;str1.length();i++)
            {

                int j=str1.indexOf(";");
                String str=str1.substring(0, j);
                results[i]=str;
                System.out.println("Result="+results[i]);

                /*results[i]=result.toString();
                if(results[i]==";")
                {
                    results[i].i
                }*/
                //String[] results = (String[])  result;
                //result.toString().endsWith(";");

                //results[i]=result.toString().endsWith(";");


           // String[] results = (String[])  result;
            tv.setText( ""+results[i]); 
            }

            tv.setText(result.toString());
            /*SoapObject result=(SoapObject)envelope.getResponse();

          //to get the data
          String resultData=result.getAttribute(1).toString();
          // 0 is the first object of data 
          System.out.println("Result"+resultData);
          tv.setText(resultData.toString());*/
        } catch (Exception e) {
            tv.setText(e.getMessage());
            }
    }


}
