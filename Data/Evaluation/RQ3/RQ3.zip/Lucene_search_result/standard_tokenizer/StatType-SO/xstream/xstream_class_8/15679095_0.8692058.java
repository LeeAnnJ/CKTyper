    public class MainActivity extends Activity {

TextView tv;

SoapObject request;

SoapSerializationEnvelope envelope;

HttpTransportSE androidHttpTransport;

Object result;

public String METHOD_NAME = "sum";

public String NAMESPACE = "http://ws.calculatorJava.org";

// private String SOAP_ACTION = NAMESPACE + METHOD_NAME;

public String SOAP_ACTION = "http://ws.calculatorJava.org/sum";

public static final String URL = "http://172.168.1.2:8888/CalculatotJava/services

    /Calculate.wsdl";


/** Called when the activity is first created. */

@Override

public void onCreate(Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_main);

    tv = (TextView) findViewById(R.id.textView1);

    try {

        request = new SoapObject(NAMESPACE, METHOD_NAME);

        request.addProperty("i", 5);

        request.addProperty("j", 15);

        envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

        envelope.dotNet = true;

        envelope.setOutputSoapObject(request);

        androidHttpTransport = new HttpTransportSE(URL);

        Toast.makeText(getBaseContext(), "GET", Toast.LENGTH_LONG).show();

        androidHttpTransport.call(SOAP_ACTION, envelope);

        result = envelope.getResponse();

        Toast.makeText(getBaseContext(),

                "  Result " + "\n" + result.toString(), 

                        Toast.LENGTH_SHORT)

                .show();

        // System.out.println("Result : " + result.toString());

        tv.setText("Addition : " + result.toString());

    } catch (Exception E) {

        E.printStackTrace();

        tv.setText("ERROR  " + "\n" + E.getClass().getName() + ":"

                + E.getMessage());

    }

}

 }
