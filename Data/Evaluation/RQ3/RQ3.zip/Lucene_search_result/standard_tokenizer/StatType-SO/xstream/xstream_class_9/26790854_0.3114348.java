import java.io.IOException;
import java.net.*;

public class MainClass {

static String serverIp = "127.0.0.1"; // or what ever ip the server is on


public static void main(String[] args) {

    try {
        while (true) {
            for (int x = 1; x == 65535; x++) {                  
                Socket serverTest = new Socket(
                        InetAddress.getByName(serverIp), x);
                if(serverTest.isConnected()){
                    connect(serverTest.getPort());
                }

            }


    } catch (IOException e) {
        e.printStackTrace();
    }

}

private static void connect(int port) throws UnknownHostException, IOException {
    Socket serverTest = new Socket(InetAddress.getByName(serverIp), port);      
}
