class Session {

//two initialized player objects per session
Player1 player1 = new Player1();
Player2 player2 = new Player2();

class Player1 {
    
    private InetAddress ip;
    private int port;
    
    public InetAddress getIp() {
        return ip;
    }

    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }
    
}

class Player2 {
    
    private InetAddress ip;
    private int port;
    
    public InetAddress getIp() {
        return ip;
    }

    public void setIp(InetAddress ip) {
        this.ip = ip;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }
    
}
