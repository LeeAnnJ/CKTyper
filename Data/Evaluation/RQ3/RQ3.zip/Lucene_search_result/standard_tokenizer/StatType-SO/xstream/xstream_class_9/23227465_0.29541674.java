xstream = new XStream(new DomDriver());


        FileInputStream fis = new FileInputStream(new File("SLL.xml"));

        try {

            nouvel= xstream.fromXML(fis);

        System.out.println(nouvel.toString());
        clazz.cast(nouvel);

        } finally {

        fis.close();
        }
