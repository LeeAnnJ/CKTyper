public class GreenhouseBO extends Observable {
    private int temp_in;
    private String ip;
    private int port;

    public GreenhouseBO(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public int getPort() {
        return port;
    }

    public int getTemp_in() {
        return temp_in;
    }

    public void setTemp_in(int temp_in) {
        this.temp_in = temp_in;
        setChanged();
        notifyObservers();
    }

}
