  public class CallRefservices {

  private static final String NAMESPACE = "http://api.myapi.com/test/ws/test";
  private static final String URL = "http://api.myapi.com/test/ws/test?wsdl";
  private static final String SOAP_ACTION = "getBoard";
  private static final String METHOD_NAME = "getBoard";

  Boolean getConnection(String login, String pwd) {
      Boolean checkBoardType = false;
    try {
      SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
      request.addProperty("login", login);
      request.addProperty("pwd", pwd);
      request.addProperty("language", "FR");

      SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
      envelope.setOutputSoapObject(request);

      HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
      androidHttpTransport.call(SOAP_ACTION, envelope);
      SoapObject objetSOAP = (SoapObject)envelope.getResponse();
      checkBoardType = this.parserObjet(objetSOAP);

    } catch (Exception e) {
      Log.e("getConnection", "", e);
    } 
    return checkBoardType;
  }

  private boolean parserObjet(SoapObject objet) {
        SoapObject boardObjet = (SoapObject)objet.getProperty("board");
        String board = boardObjet.getProperty("NONE").toString();

        if (board == "WhatIWant")
            return true;
        else
            return false;
  }
}
