class class_ip{
    private String ip;
    private String title;
    public class_ip(String ip,String title) {
        this.ip = ip;        
        this.title = title;
    }
    public String getIP() {return ip;}
    public String getTitle() {return title;}

    public void setTitle(String title) { this.title = title;}
    public void setIP(String ip) { this.ip = ip;}

    public String getAll() {
        return ip+","+title;
    }
} 

     List&lt;class_ip&gt; array_ip = new ArrayList&lt;&gt;();

    // read data from file
    while ((strLine = br.readLine()) != null)   {
                array_ip.add(new class_ip(ip,title));
    }

   Map&lt;String,List&lt;class_ip&gt;&gt; groupByIP = new HashMap&lt;&gt;();
   groupByIP =array_ip.stream().collect(Collectors.groupingBy(class_ip::getIP)); 

   System.out.println(groupByIP);
