    SOAP_ACTION  = Constants.ACTION + "o1001";
    METHOD_NAME  = "o1001";
    SoapObject request = new SoapObject(Constants.NAMESPACE, METHOD_NAME);

    request.addProperty (


    "p1",email);
    request.addProperty (

    "p2",pass);

            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

    envelope.setOutputSoapObject (request);
    envelope.dotNet  = true;

    HttpTransportSE androidHttpTransport = new HttpTransportSE(Constants.URL);
    androidHttpTransport.debug  = true;
    String s = "";


        try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
        s = androidHttpTransport.responseDump;
        Log.v("Soap Webservice", s);
    }
    catch (Exception e


        ) {
                e.printStackTrace();
    }
    return s ;
