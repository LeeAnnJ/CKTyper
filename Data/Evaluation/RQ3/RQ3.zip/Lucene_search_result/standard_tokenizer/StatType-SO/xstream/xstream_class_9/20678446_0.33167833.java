package com.diedericksclan.main.network;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class ServerThread extends Thread {

    private ServerHandler server;
    private ServerSocket dataSocket;
    private Socket socket;
    private InetSocketAddress address;
    private int megabyte = 1024 * 1024;
    private int dedicated = 1024;
    public int RAM = megabyte * dedicated;

    private WriteData send;
    private ReadData read;

    public ServerThread(ServerHandler server, String serverIP, int ram, int backlog) throws Exception {
        this.server = server;
        this.dedicated = ram;
        //System.out.println(serverIP);
        String ip = "localhost";
        int port = 2048;
        if(serverIP.contains(":")) {
            ip = serverIP.split(":")[0];
            port = Integer.parseInt(serverIP.split(":")[1]);
        } else {
            ip = serverIP;
            port = 2048;
        }
        //System.out.println("Makin' the server");
        this.dataSocket = new ServerSocket(port, backlog, InetAddress.getByName(ip));
        this.address = new InetSocketAddress(dataSocket.getInetAddress(), port);
        this.send = new WriteData();
        this.read = new ReadData();
        //System.out.println("Makin' the data handlers");

        //System.out.println("Server has been made, details: " + address.getAddress() + ":" + address.getPort());
    }

    public ServerThread(ServerHandler server, String ip) throws Exception {
        this(server, ip, 1024, 0);
    }

    public void run() {
        //System.out.println("made");
        this.send.start();
        this.read.start();
        while(true) {
            try {
                socket = dataSocket.accept();
                socket.setReceiveBufferSize(megabyte);
                socket.setSendBufferSize(megabyte);
                socket.setTcpNoDelay(true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public void sendData(byte[] data, InetAddress IPaddress, int port) {
        this.send.sendData(data, IPaddress, port);
    }

    public void serverShutdown() {
        try {
            this.dataSocket.close();
            if(this.socket != null) this.socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public class WriteData extends Thread {
        public WriteData() {}
        public void sendData(byte[] data, InetAddress IPaddress, int port) {
            try {
                System.out.println("[" + System.currentTimeMillis() + "] Sending... " + new String(data));
                socket.getOutputStream().write(data);
                socket.getOutputStream().flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public class ReadData extends Thread {
        public ReadData() {}
        public void run() {
            try {
                this.sleep(1000);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }
            byte[] data;
            while(true) {
                try {
                    data = new byte[megabyte];
                    socket.getInputStream().read(data);

                    System.out.println("[" + System.currentTimeMillis() + "] Server has read, " + new String(data) + ", details: " + socket.getLocalAddress().getHostName() + ":" + socket.getLocalPort());

                    server.parsePacket(data, socket.getInetAddress(), socket.getPort());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
