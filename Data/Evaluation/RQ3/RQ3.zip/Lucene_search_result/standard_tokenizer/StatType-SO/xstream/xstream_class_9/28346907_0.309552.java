@Entity
@Index 
public class Server {

@Id Long idServer;
private String hostname;
private String ip;
private int status;
private String statusDate; 
private String lastTimeUp; 
@Parent Key&lt;Site&gt; site;

@SuppressWarnings("unused")
private Server(){}

public Server(String serverHostName,  String serverIp, int serverStatus, String serverStatusDate, String serverLastTimeUp, Key&lt;Site&gt; serverSite){
if(serverSite!=null){

List&lt;Server&gt; l=ofy().load().type(Server.class).filter("hostname",serverHostName).filter("ip",serverIp).ancestor(serverSite).list();     
System.out.println("list ok.");
if(l.size()==0){
this.hostname = serverHostName;
this.ip = serverIp;
this.status = serverStatus;
this.statusDate = serverStatusDate;
this.lastTimeUp = serverLastTimeUp;
this.site = serverSite;
System.out.println("Test start");
System.out.println(serverHostName+"="+this.hostname);
System.out.println(serverIp+"="+this.ip);
System.out.println(serverStatus+"="+this.status);
System.out.println(serverLastTimeUp+"="+this.lastTimeUp);
System.out.println(serverSite.toString()+"="+this.site.toString());
System.out.println("Test end");
try{
ofy().save().entity(this).now();
System.out.println("Object created.");
}
catch(Exception ex){
System.out.println("Saving interrupted.");
System.out.println(ex.getLocalizedMessage());   
}   
}
else
{
System.out.println("Object creation stopped, it already exists.");
}
}
}
//getters/setters/etc
}
