private String serverIp;
private int port;
private String multicastAddress;
private long WAITING_TIME = 5000;  // 5 seconden

private DatagramSocket socket;

public MulticastIpSender(String serverIp, int port, String multicastAddress) throws SocketException {
    super();
    this.serverIp = serverIp;
    this.port = port;
    this.multicastAddress = multicastAddress;
    socket = new DatagramSocket(port);
}

public void run() {
    while(true){
        try {
            byte[] buf = new byte[256];
            buf = serverIp.getBytes();
            InetAddress group = InetAddress.getByName(multicastAddress);
            DatagramPacket packet = new DatagramPacket(buf, buf.length, group, port);
            socket.send(packet);
            System.out.println("sent IP("+serverIp+") to group("+group+") on port "+port);
            sleep(WAITING_TIME);

        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
