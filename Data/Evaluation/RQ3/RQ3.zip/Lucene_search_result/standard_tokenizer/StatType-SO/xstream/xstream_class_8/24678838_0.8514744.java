public void getMessage() {
    private final String NAMESPACE = "http://tempuri.org/";
    private final String URL = "http://foobar/foo/Service1.asmx";
    private final String SOAP_ACTION = "http://tempuri.org/HelloWorld";
    private final String METHOD_NAME = "HelloWorld";

    private static String message;

    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(
            SoapEnvelope.VER11);
    envelope.dotNet = true;
    //Set output SOAP object
    envelope.setOutputSoapObject(request);
    //Create HTTP call object
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

    try {
        //Invoke web service
        androidHttpTransport.call(SOAP_ACTION, envelope);
        //Get the response
        SoapObject result = (SoapObject) envelope.bodyIn;
        message = result.toString();

    } catch (Exception e) {
        tv.setText(e.getMessage());
        e.printStackTrace();
    }
}
