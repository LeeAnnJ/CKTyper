public class AndroidWSDLKActivity extends Activity 
{
    private static final String NAMESPACE = "http://schemas.microsoft.com/sharepoint/soap/";
    private static final String URL = "http://192.168.0.193:30004/SPMobApp/_vti_bin/lists.asmx";
    private static final String SOAP_ACTION = "http://schemas.microsoft.com/sharepoint/soap/GetList";
    private static final String METHOD_NAME = "GetList";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        TextView lblResult = (TextView) findViewById(R.id.result);

        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

                  // Set all input params   

        request.addProperty("listName", "Tasks");   

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                 // Enable the below property if consuming .Net service
        envelope.dotNet = true;
        envelope.setOutputSoapObject(request);

             HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

             try 
             {
                 List&lt;HeaderProperty&gt; headerList = new ArrayList&lt;HeaderProperty&gt;();
                 String authentication = android.util.Base64.encodeToString("LOGIN:PASS".getBytes(), android.util.Base64.NO_WRAP);

                 headerList.add(new HeaderProperty("Authorization", "Basic " + authentication));

                 androidHttpTransport.call(SOAP_ACTION, envelope);


                 SoapObject response = (SoapObject)envelope.getResponse();


                 lblResult.setText(response.getProperty(0).toString());
             }
             catch(Exception e)
             {
                 lblResult.setText(e.getStackTrace().toString());
             }
    }
}
