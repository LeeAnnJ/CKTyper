    private void setupConnection(String serverIP, String port){
    int portInt = Integer.parseInt(port);
    try{
        InetAddress IP = InetAddress.getByName(serverIP);
        int intPort = Integer.parseInt(port);
        Socket clientSocket = new Socket(IP,intPort);
        JOptionPane.showMessageDialog(new JFrame(), "Successfully connected to Server");
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream());
        Scanner in = new Scanner(clientSocket.getInputStream());
        //in.
    }
    catch(Exception e){
        System.out.println("ErrorC :" +e.getMessage());
    }
}
