package com.site.custom;
public class Act2 extends Activity
{
    private ProgressDialog pd;
    private String serverIP="58.146.100.187";
    private BufferedReader in;
    private PrintWriter out;
    private String path;
    private Socket cliSock;

    public void onCreate(Bundle onCreateInstance)
    {
        super.onCreate(onCreateInstance);
        setContentView(R.layout.act2);
        this.setTitle("This has started");
        path=getIntent().getStringExtra("path");

        //Establish Connection
        try
        {
            cliSock=new Socket(serverIP,8070);
            in=new BufferedReader(new InputStreamReader(cliSock.getInputStream()));

            ((TextView)findViewById(R.id.tview)).setText(path);
        }
        catch(Exception e)
        {
            Log.v("MERA MSG",e.toString());
        }

        //Send file
        ProgressDialog pd=ProgressDialog.show(this, "Sending image", "Image chosen:"+path.substring(path.lastIndexOf("//")+1),false,true);

        try
        {
            File myFile = new File (path);
            System.out.println((int)myFile.length());
            byte[] mybytearray  = new byte[450560];
            FileInputStream fis = new FileInputStream(myFile);
            BufferedInputStream bis = new BufferedInputStream(fis);
            bis.read(mybytearray,0,mybytearray.length);
            OutputStream os = cliSock.getOutputStream();
            System.out.println("Sending...");
            os.write(mybytearray,0,mybytearray.length);
            os.flush();
            System.out.println("Completed");

            pd.dismiss();
            System.out.println("Done");
        }
        catch(Exception e)
        {
            Log.v("MERA MSG",e.toString());
        }

    }
}
