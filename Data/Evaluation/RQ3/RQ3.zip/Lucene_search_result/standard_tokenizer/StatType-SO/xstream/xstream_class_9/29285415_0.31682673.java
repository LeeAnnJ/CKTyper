class QTcpSocket implements Runnable {

    private String ip="";
    private int port;
    private Socket socket;
    private DataOutputStream dataOutputStream;
    private DataInputStream dataInputStream;

    public QTcpSocket(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }

      public void setIp(String ip) {
          this.ip = ip;
      }

      public String getIp() {
          return this.ip;
      }

    public void setPort(int port) {
        this.port = port;
    }

    public void run() {
        try {

            socket = new Socket(this.ip, this.port);

            dataOutputStream = new DataOutputStream( socket.getOutputStream() );
            dataInputStream = new DataInputStream(socket.getInputStream());
            String response = dataInputStream.readUTF();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void sendMessage(String message) {
        try {

            byte[] buffer= message.getBytes();
            dataOutputStream.write(buffer,0,buffer.length);

        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void disconnect() {
        try {

            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isClosed() {
        return socket.isClosed();
    }
}
