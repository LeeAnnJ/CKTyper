    SoapObject request = new SoapObject(NAMESPACE, COST_INFORMATION_NAME);
// Use this to add parameters
request.addProperty("user_id", login.getUser_id());
request.addProperty("company_id", login.getCompany_id());
request.addProperty("inventoryID", inventoryId);

// Declare the version of the SOAP request
SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER12);
envelope.setOutputSoapObject(request);
envelope.dotNet = true;

try {
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

    // this is the actual part that will call the webservice
    androidHttpTransport.call(COST_INFORMATION_ACTION, envelope);

    // Get the SoapResult from the envelope body.
    SoapObject result = (SoapObject) envelope.bodyIn;
    if (result != null) {
    String res = result.getPropertyAsString(0);
            //************************************************************
            //Everything else isn't relevant, the res variable contains the result I put above the code.
            //************************************************************
