   SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);          
   Log.d("WebService", "2");
   SoapSerializationEnvelope envelope = 
          new SoapSerializationEnvelope(SoapEnvelope.VER11);
   envelope.dotNet = true;
   envelope.setOutputSoapObject(request);
   HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
   androidHttpTransport.call(SOAP_ACTION, envelope);                    
   SoapPrimitive result = (SoapPrimitive)envelope.getResponse();
