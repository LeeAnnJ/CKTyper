public final static String SOAP_ACTION = "http://EntityPackage/verifyClient";
public final static String NAMESPACE = "http://EntityPackage/";
public final static String URL = "http://localhost:8080/WS/WS";

private boolean SendUserData(){
   SoapObject request = new SoapObject(NAMESPACE, "verifyClient");
   request.addProperty("user", Profile.username);
   request.addProperty("pwd1", Profile.password);
   SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
   envelope.setOutputSoapObject(request);
   envelope.dotNet = true;
   HttpTransportSE transport = new HttpTransportSE(URL);
   transport.call(SOAP_ACTION, envelope);
   SoapObject  result = (SoapObject)envelope.bodyIn;
}
