public class TCPClient {
/**
 * Variables
 */
private String serverIP;
private int serverPort;
private Socket clientSocket;
private boolean connected = false;
private ObjectOutputStream outToServer;
private ObjectInputStream inFromServer;

/**
 * Class constructor
 *
 * @param serverIP   String value that's representing the server ip
 * @param serverPort Integer value that represents server port
 */
public TCPClient(String serverIP, int serverPort) {
    try {
        this.serverIP = serverIP;
        this.serverPort = serverPort;
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}

/**
 * Establish connection with the specified TCP server
 */
public void connect() {
    try {
        if (!connected) {
            try {
                System.out.println(String.format("Trying to connect to: %s on port: %d", getServerIP(), getServerPort()));
                clientSocket = new Socket(getServerIP(), getServerPort());
                System.out.println("Connected !");
                connected = true;
                // Create ObjectStreams
                outToServer = new ObjectOutputStream(clientSocket.getOutputStream());
                inFromServer = new ObjectInputStream(clientSocket.getInputStream());
            } catch (Exception e) {
                connected = false;
                if (clientSocket != null) {
                    clientSocket.close();
                    System.out.println(String.format("Could not connect to: %s on port: %d", getServerIP(), getServerPort()));
                }
            }
        } else {
            return;
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}

/**
 * Disconnect client for the currently connected server
 */
public void disconnect() {
    try {
        if (connected) {
            clientSocket.close();
            connected = false;
        }
    } catch (Exception ex) {
        ex.printStackTrace();
    }
}

/**
 * Invoke server side functions
 *
 * @param serverSideFunction Object representing both function name and its parameters
 * @return String vale of a server side function return value
 */
public Object invokeFunction(Object[] serverSideFunction) {
    try {
        if (clientSocket != null &amp;&amp; connected) {
            outToServer.writeObject(serverSideFunction);
            Object modifiedSentence = inFromServer.readObject();
            if (modifiedSentence != null) {
                System.out.println("Received from server: " + modifiedSentence);
            }
            return modifiedSentence;
        }
        return null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return null;
    }
}

/**
 * Get server ip data
 *
 * @return String value of Server IP
 */
public String getServerIP() {
    return serverIP;
}

/**
 * Get server port data
 *
 * @return Integer value of Server Port
 */
public int getServerPort() {
    return serverPort;
 }
