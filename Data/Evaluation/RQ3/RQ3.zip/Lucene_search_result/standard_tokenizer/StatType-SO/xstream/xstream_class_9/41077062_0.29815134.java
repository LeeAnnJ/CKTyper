public class Server extends AppCompatActivity {

    private static final String TAG = "ServerActivity";
    private TextView tvServerStatus;
    private TextView recievemsg;
    InetAddress receiverAddress;
    public static String SERVERIP = "";
    DatagramSocket datagramSocket;
    public static final int SERVERPORT = 8080;

    private Handler handler = new Handler();
    Handler updateConversationHandler;
    private ServerSocket serverSocket;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);
        updateConversationHandler = new Handler();

        tvServerStatus = (TextView) findViewById(R.id.tvServerStatus);
        recievemsg=(TextView)findViewById(R.id.send_msg);
        SERVERIP = getLocalIpAddress();
        Thread fst = new Thread(new ServerThread());
        fst.start();


        try {
            datagramSocket = new DatagramSocket(8080);
            byte[] buffer = "0123456789".getBytes();
            byte[] address=SERVERIP.getBytes();
            receiverAddress = InetAddress.getByAddress(address);
            DatagramPacket packet = new DatagramPacket(
                    buffer, buffer.length, receiverAddress, 8080);
            datagramSocket.send(packet);
        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    private String getLocalIpAddress() {
        String ip = "";
        try {
            Enumeration&lt;NetworkInterface&gt; enumNetworkInterfaces = NetworkInterface
                    .getNetworkInterfaces();
            while (enumNetworkInterfaces.hasMoreElements()) {
                NetworkInterface networkInterface = enumNetworkInterfaces
                        .nextElement();
                Enumeration&lt;InetAddress&gt; enumInetAddress = networkInterface
                        .getInetAddresses();
                while (enumInetAddress.hasMoreElements()) {
                    InetAddress inetAddress = enumInetAddress.nextElement();

                    if (inetAddress.isSiteLocalAddress()) {
                        ip += "SiteLocalAddress: "
                                + inetAddress.getHostAddress() + "\n";
                    }
                }
            }
        } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            ip += "Something Wrong! " + e.toString() + "\n";
        }
        return ip;


    }

    public class ServerThread implements Runnable {

        @Override
        public void run() {
            try {
                Log.e(TAG, "Server IP: " + SERVERIP);
                if (SERVERIP != null) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            tvServerStatus.setText("Listening On Ip: " + SERVERIP);
                        }
                    });

                    serverSocket = new ServerSocket(SERVERPORT);
                     while (!Thread.currentThread().isInterrupted()) {
                        {
                            try {
                                // LISTEN FOR INCOMING CLIENTS
                                Socket client = serverSocket.accept();

                                CommunicationThread commThread = new    CommunicationThread(client);

                                new Thread(commThread).start();

       //                          Log.e(TAG, "Client Socket: " + client);
      //                        new Clients_Handle(client, ROOT_DIRECTORY).start();
                            }
                            catch (IOException e) {

                                e.printStackTrace();

                            }

                        }
                    }
                } else {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            tvServerStatus.setText("Couldn't detect internet connection.");
                        }
                    });
                }
            } catch (IOException e) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        tvServerStatus.setText("Error");
                    }
                });
                e.printStackTrace();
            }
        }
    }
    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        private BufferedReader input;

        public CommunicationThread(Socket clientSocket) {

            this.clientSocket = clientSocket;
            try {


                this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));


            } catch (IOException e) {

                e.printStackTrace();

            }

        }

        public void run() {

            while (!Thread.currentThread().isInterrupted()) {

                try {

                    String read = input.readLine();
                    updateConversationHandler.post(new updateUIThread(read));

                } catch (IOException e) {

                    e.printStackTrace();

                }

            }

        }
    }
    class updateUIThread implements Runnable {

        private String msg;

        public updateUIThread(String str) {

            this.msg = str;

        }

        @Override

        public void run() {


                   recievemsg.setText(recievemsg.getText().toString() + "Client       Says: " + msg + "\n");



        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            // MAKE SURE YOU CLOSE THE SOCKET UPON EXITING
            serverSocket.close();
            Log.e(TAG,"Socket Closed");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
