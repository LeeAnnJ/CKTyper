URL = "http://test.tpsynergy.com:8080/tpsynergy/services/login";
SOAP_ACTION = "http://test.tpsynergy.com:8080/tpsynergy/services/login";
METHOD = "Login";
NAMESPACE = "http://test.login/";
SoapObject request = new SoapObject(NAMESPACE, "Login");
request.addProperty("arg0", "best_buyer_editor");
request.addProperty("arg1", "welcome");
request.addProperty("arg2", "Mobile");

Log.i(TAG, "Request for getting airport list" + request.toString());

SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
envelope.setOutputSoapObject(request);
envelope.dotNet = true;
HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
try {
    androidHttpTransport.call(SOAP_ACTION, envelope);

    if (envelope.bodyIn instanceof SoapFault) {
                String str= ((SoapFault) envelope.bodyIn).faultstring;
                Log.i("", str);


     } else {
                SoapObject resultsRequestSOAP = (SoapObject) envelope.bodyIn;
                response = resultsRequestSOAP.getProperty(0).toString();

                 Log.i(" Login Webservice Response", "Responce ----&gt;"
                         + (resultsRequestSOAP.getProperty(0).toString()));
            }

    } catch (Exception e) {

            Log.i(TAG, "Exception e" + e.toString());
        }
