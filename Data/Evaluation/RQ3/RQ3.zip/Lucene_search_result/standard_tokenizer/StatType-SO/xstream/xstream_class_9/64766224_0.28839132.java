public class A {
    
    private String type;
    private String ip;
    private String originSubId;
    
    
    public A(String type, String ip, String originSubId) {
        this.type = type;
        this.ip = ip;
        this.originSubId = originSubId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public String getOriginSubId() {
        return originSubId;
    }
    public void setOriginSubId(String originSubId) {
        this.originSubId = originSubId;
    }
}
