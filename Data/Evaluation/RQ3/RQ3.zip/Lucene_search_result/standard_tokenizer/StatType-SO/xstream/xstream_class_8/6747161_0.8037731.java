public Object soap(String METHOD_NAME, String SOAP_ACTION, String NAMESPACE, String URL)
            throws IOException, XmlPullParserException {

        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
        request.addProperty("username", "Maxxd"); 
        request.addProperty("password", "xxxx");
        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.setOutputSoapObject(request);
        HttpTransportSE httpTransport = new HttpTransportSE(URL);
        httpTransport.call(SOAP_ACTION, envelope);
        Object result = envelope.getResponse();
        return result;
    }
