String serverIP=null;
    try {
        File file = new File("serverIP.txt");
        if(file.exists()){
            serverIP = new Scanner(new File("serverIP.txt")).useDelimiter("\\Z").next();
            rmi = (ServerInterface) Naming.lookup("//"+ serverIP +":" +"2323" + "/server");
        }else{
            PrintWriter out = new PrintWriter("serverIP.txt");
            serverIP = JOptionPane.showInputDialog ("Please enter Server IP Address: "); 
            out.println(serverIP);
            out.close();
            rmi = (ServerInterface) Naming.lookup("//"+ serverIP +":" +"2323" + "/server");
        }
    }
