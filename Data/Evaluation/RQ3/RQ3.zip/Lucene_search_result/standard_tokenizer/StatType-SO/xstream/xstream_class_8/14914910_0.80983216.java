public class MainActivity extends Activity {
    private final String URL = "http://mobilews.terra.net.lb/MobileService.asmx";
    private final String METHOD_NAME = "authenticateLogin";
    private final String NAMESPACE = "http://tempuri.org/";
    private final String SOAP_ACTION = NAMESPACE + METHOD_NAME;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        authenticateLogin("mabyad", "dori", "your_public_key");
    }

    private void authenticateLogin(String userName, String passWord, String publicKey) {
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

        request.addProperty("userName", userName);
        request.addProperty("password", passWord);
        request.addProperty("publicKey", passWord);

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet = true;

        envelope.setOutputSoapObject(request);

        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
        androidHttpTransport.debug = true;
        try {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            SoapObject response = (SoapObject) envelope.bodyIn;

            boolean authenticateLoginResult = Boolean.parseBoolean(response.getPropertyAsString("authenticateLoginResult"));
            int customerId = Integer.parseInt(response.getPropertyAsString("customerId"));
            String errorMsg = response.getPropertyAsString("errorMsg");

            System.out.println("authenticateLoginResult :: " + authenticateLoginResult);
            System.out.println("customerId :: " + customerId);
            System.out.println("errorMsg :: " + errorMsg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
