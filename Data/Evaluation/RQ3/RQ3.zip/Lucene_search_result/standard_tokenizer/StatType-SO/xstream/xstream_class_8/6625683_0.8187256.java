// declarations

private static final String NAMESPACE = "http://tempuri.org/" ;
private static final String METHOD_NAME = "CelsiusToFahrenheit";
private static final String SOAP_ACTION = "http://tempuri.org/CelsiusToFahrenheit";
private static final String URL = "http://216.128.29.26/webservices/tempconvert.asmx";

// code

try
{
   SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
   SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
   HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

   request.addProperty("Celsius", "32");
   envelope.setOutputSoapObject(request);
   androidHttpTransport.call(SOAP_ACTION, envelope);

   Object result = envelope.getResponse();
}
catch(Exception e)
{
   e.printStackTrace();
}
