List&lt;Event&gt; events = new ArrayList&lt;Event&gt;();
XStream xstream = new XStream();
xstream.alias("Event", Event.class);
FileInputStream fis = null;

try {
    fis = new FileInputStream(path);
    events.add((Event) xstream.fromXML(fis));
} catch(FileNotFoundException e) {
    e.printStackTrace();
} catch(IOException e) {
    e.printStackTrace();
} finally {
     try {
         fis.close();
     } catch(IOException e) {
         e.printStackTrace();
     }  
}
