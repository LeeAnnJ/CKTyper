  public SoapObject soap(String METHOD_NAME, String SOAP_ACTION, String NAMESPACE, String URL,String IP,String SERVICEPATH) throws IOException, XmlPullParserException 
  {

SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME); //set up request

    PropertyInfo pi = new PropertyInfo();

    pi.setName("Parameter1");
    pi.setValue(Value1);

    request.addProperty(pi);
     pi.setName("Parameter2");
     pi.setValue(Value2);
    request.addProperty(pi);



SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11); // put all required data into a soap
envelope.dotNet = true;
envelope.setOutputSoapObject(request); // prepare request
envelope.bodyOut = request;
  Log.d("ENVELOPE",""+"Coming3");
HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//androidHttpTransport.
androidHttpTransport.call(SOAP_ACTION, envelope);

Log.d("ENVELOPE",""+envelope.bodyIn);
SoapObject result = (SoapObject) envelope.bodyIn; // get response
Log.d("ENVELOPE",""+envelope.bodyIn);
SoapObject responseBodyRaw,responseBody,tableRow;
return result;
}
