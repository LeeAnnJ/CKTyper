public class Server {

    private static ServerSocket serverSocket;
    private static Socket clientSocket;
    private static InputStreamReader inputStreamReader;
    private static BufferedReader bufferedReader;
    private static String message;
    private static String serverIp = "10.0.2.15";

    public static void main(String[] args) {
        try {

            serverIp = getServerIp();

            if(serverIp != null){

                System.out.println("Listenning on IP:" + serverIp);

            }

            serverSocket = new ServerSocket(4444); // Server socket

        } catch (IOException e) {
            System.out.println("Could not listen on port: 4444  " + e.toString());
        }

        System.out.println("Server started. Listening to the port 4444");

        while (true) {
            try {


                clientSocket = serverSocket.accept(); // accept the client connection


                if(clientSocket.getInputStream().read() != -1){

                    System.out.println("Socket connection");

                } else {

                    System.out.println("Client disconected");

                }

                inputStreamReader = new InputStreamReader(clientSocket.getInputStream());
                bufferedReader = new BufferedReader(inputStreamReader); // get the client message
                message = bufferedReader.readLine();

                System.out.println(message);
                inputStreamReader.close();
                clientSocket.close();

            } catch (IOException ex) {
                System.out.println("Problem in message reading  " + ex.toString());
            }
        }

    }

    public static String getServerIp(){

        try{

            for (Enumeration&lt;NetworkInterface&gt; en = NetworkInterface.getNetworkInterfaces();
                    en.hasMoreElements();){
                NetworkInterface intf = en.nextElement();
                for (Enumeration&lt;InetAddress&gt; enumIpAdress = intf.getInetAddresses();
                        enumIpAdress.hasMoreElements();){

                        InetAddress inetAddress = enumIpAdress.nextElement();
                        if(!inetAddress.isLoopbackAddress()){

                            return inetAddress.getHostAddress().toString();

                        }

                    }

            }

        } catch (SocketException e){

            System.out.println(e.toString());

        }

        return null;
    }
}
