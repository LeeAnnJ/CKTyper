    public Array listall(String session){
    final String SOAP_ACTION = "http://www.nubio.net/soap/vps#listAll";
    final String METHOD_NAME = "listAll";
    final String NAMESPACE = "http://www.nubio.net/soap/vps";
    final String URL = "http://www.nubio.net/soap/vps";
    Array myArray = null;
    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
    //SoapObject 
    request.addProperty("session",session);
    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
    envelope.setOutputSoapObject(request);
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
    try 
        {
            androidHttpTransport.call(SOAP_ACTION, envelope);
            resultRequestSOAP =  envelope.getResponse();
            //retour = resultRequestSOAP.toString();
            if(resultRequestSOAP != null){
               myArray = (Array)resultRequestSOAP; 
            }
        }
    catch (Exception aE)
        {
    aE.printStackTrace ();;
        }
    return myArray;

}
