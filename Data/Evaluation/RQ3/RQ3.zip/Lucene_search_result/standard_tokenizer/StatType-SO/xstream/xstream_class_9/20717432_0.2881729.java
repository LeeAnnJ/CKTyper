package com.diedericksclan.main.network;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

import com.diedericksclan.main.network.handling.PlayerMP;

public class ServerThread extends Thread {

    private ServerHandler server;
    private ServerSocket dataSocket;
    private Socket socket;
    private InetSocketAddress address;
    private int megabyte = 1024 * 1024;
    private int dedicated = 1024;
    public int RAM = megabyte * dedicated;
    private ArrayList&lt;Client&gt; clients = new ArrayList&lt;Client&gt;();

    public ServerThread(ServerHandler server, String serverIP, int ram, int backlog) throws Exception {
        super(serverIP);
        this.server = server;
        this.dedicated = ram;
        String ip = "localhost";
        int port = 2048;
        if(serverIP.contains(":")) {
            ip = serverIP.split(":")[0];
            port = Integer.parseInt(serverIP.split(":")[1]);
        } else {
            ip = serverIP;
            port = 2048;
        }
        this.dataSocket = new ServerSocket();
        this.dataSocket.setReuseAddress(true);
        this.address = new InetSocketAddress(InetAddress.getByName(ip), port);
        this.dataSocket.bind(address, 0);
    }

    public ServerThread(ServerHandler server, String ip) throws Exception {
        this(server, ip, 1024, 0);
    }

    public void run() {
        while(true) {
            try {
                socket = dataSocket.accept();
                socket.setKeepAlive(true);
                socket.setSendBufferSize(megabyte);
                socket.setSendBufferSize(megabyte);
                socket.setTcpNoDelay(true);
                socket.setReuseAddress(true);
                InetSocketAddress clientAddress = new InetSocketAddress(socket.getInetAddress(), socket.getPort());
                System.out.println("Starting");
                if(getClients().size() &gt; 0) {
                    for(Client c : getClients()) {
                        if(clientAddress != c.socket.getLocalSocketAddress()) {
                            Client client = new Client(socket, clientAddress);
                            getClients().add(client);
                            client.start();
                            System.out.println("Added new client!");
                            break;
                        }
                    }
                } else {
                    Client client = new Client(socket, clientAddress);
                    getClients().add(client);
                    client.start();
                    System.out.println("Added new client!");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public synchronized void sendData(byte[] data, InetAddress IPaddress, int port) {
        if(this.getClient(new InetSocketAddress(IPaddress, port)) != null) {
            this.getClient(new InetSocketAddress(IPaddress, port)).sendData(data);
        }
    }

    public void serverShutdown() {
        try {
            this.dataSocket.close();
            if(this.socket != null) this.socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getClientIndex(InetSocketAddress address) {
        int index = 0;
        for(Client c : getClients()) {
            if(c.socket.getRemoteSocketAddress().equals(address)) {
                break;
            }
            index++;
        }
        System.out.println("Getting client index...");
        return index;
    }

    public synchronized ArrayList&lt;Client&gt; getClients() {
        return this.clients;
    }

    private Client getClient(InetSocketAddress address) {
        for(Client c : getClients()) {
            if(c.socket.getRemoteSocketAddress().equals(address)) {
                return c;
            }
        }
        return null;
    }

    public class Client extends Thread {
        DataInputStream in;
        DataOutputStream out;
        Socket socket;
        public Client(Socket sock, InetSocketAddress IPaddress) {
            try {
                socket = sock;
                in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
                out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            while(true) {
                try {
                    byte[] data = new byte[in.readInt() - 4];
                    in.read(data);
                    server.parsePacket(data, socket.getInetAddress(), socket.getPort());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public void sendData(byte[] data) {
            try {
                out.writeInt(data.length + 4);
                out.write(data);
                out.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
