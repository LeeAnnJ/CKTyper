private static final String METHOD_NAME = "Get";
private static final String NAMESPACE = "http://tempuri.org/";
private static final String URL = "http://10.0.0.2:2807/webservices/webService.asmx";
private static String SOAP_ACTION = NAMESPACE+METHOD_NAME;

@Override
public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    try {
        SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

        request.addProperty("pageIndex", "0");
        request.addProperty("pageSize", "10");

        SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
        envelope.dotNet=true;
        envelope.setOutputSoapObject(request);

        AndroidHttpTransport androidHttpTransport = new AndroidHttpTransport(URL);
        androidHttpTransport.call(SOAP_ACTION, envelope);
        SoapObject result=(SoapObject)envelope.getResponse();

        String resultData=result.getProperty(0).toString();
    }
    catch (Exception e) {
        e.printStackTrace();
    }
}
