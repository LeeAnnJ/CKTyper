  package com.stru;

  import java.io.*;
   import java.sql.*;
 import java.util.Map;

   import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ServletRequestAware;

import com.opensymphony.xwork2.ActionContext;
 import com.opensymphony.xwork2.ActionSupport;

public class imgupload extends ActionSupport implements ServletRequestAware{       



/**
 * 
 */
private static final long serialVersionUID = 1L;
private HttpServletRequest request;
private File img;
private byte[] ip;
public String getFilename() {
    return filename;
}




public void setFilename(String filename) {
    this.filename = filename;
}




public byte[] getIp() {
    return ip;
}




public void setIp(byte[] ip) {
    this.ip = ip;
}
private String imagecontenttype;
private String filename;




public File getImg() {
    return img;
}




public void setImg(File img) {
    this.img = img;
}




public String getImagecontenttype() {
    return imagecontenttype;
}




public void setImagecontenttype(String imagecontenttype) {
    this.imagecontenttype = imagecontenttype;
}









@Override
public void setServletRequest(HttpServletRequest request) {
    this.request=request;

}
public String execute()
{
    try
    {
    String filepath=request.getSession().getServletContext().getRealPath("/");
    System.out.print("path"+filepath);
    File filetocreate = new File(filepath, filename);
    System.out.print("tocreate"+filetocreate.getName());
    FileUtils.copyFile(img, filetocreate);
    ip = getBytes(filetocreate);

    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/mdb","root","tiger");
    PreparedStatement stmt = con.prepareStatement("insert into strpic(pics) values(?)");
    stmt.setBytes(1, ip);
    int i = stmt.executeUpdate();

    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    return SUCCESS;
}
