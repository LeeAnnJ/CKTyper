NAMESPACE = "http://" + "10.99.60.52" + ":" + "8080" +"/ws/EmployeeServices?wsdl";
URL = "http://" + "10.99.60.52" + ":" + "8080" +"/ws/EmployeeServices"; 
SOAP_ACTION = "EmployeeServicesPortBinding";
METHOD_NAME = "authorize";

SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

request.addProperty("employeeId", userID);
request.addProperty("localeId", localeID);
request.addProperty("organizationId", organisationID);
request.addProperty("retailLocationId", retailLoationID);
request.addProperty("workstationId", workstationID);
request.addProperty("LoginInput", userID);
request.addProperty("Password", password);
request.addProperty("LoginInputType", loginInputType);
request.addProperty("Privilege", privilege);

SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11); 
envelope.setOutputSoapObject(request);

HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

try {
    androidHttpTransport.call(SOAP_ACTION, envelope);

    Object obj = envelope.bodyIn;
    SoapObject response = null;
    if (obj instanceof SoapObject)
        response = (SoapObject) (envelope.bodyIn);

    responseCode = (response != null) ? response.getProperty("UserAuthorizeResponse").toString() : "Failed";

    Toast.makeText(getApplicationContext(), responseCode, Toast.LENGTH_SHORT).show();   //Testing

} catch (Exception e) {
    Toast.makeText(getApplicationContext(), "Exception", Toast.LENGTH_SHORT).show();    //Testing
    System.out.println("");
}
