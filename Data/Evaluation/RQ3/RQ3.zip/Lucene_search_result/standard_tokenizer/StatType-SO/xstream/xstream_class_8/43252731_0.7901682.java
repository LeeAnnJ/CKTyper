 private static String NAMESPACE = "http://tempuri.org/";
private static String URL = "http://192.168.0.102/MyWebService/WebService1.asmx?WSDL";
 protected String doInBackground(String... params) {
    String s="";
    String whichmethodcall = params[0];
    switch(whichmethodcall){
        case "SignUp":
            s = signup(params);
            break;
        case "SignIn":
            s = signin(params);
            break;
    }
    return s;
}
 public String signup(String[] arr){
    String s = "";
    SoapObject request = new SoapObject(NAMESPACE, arr[1]);
    //Use this to add parameters
    request.addProperty("cname",arr[2]);
    request.addProperty("cemail",arr[3]);
    request.addProperty("cpwd",arr[4]);
    request.addProperty("caddress",arr[5]);
    request.addProperty("cdob",arr[6]);
    request.addProperty("caccount",arr[7]);
    request.addProperty("cCnic",arr[8]);
    request.addProperty("cpobox",arr[9]);
    request.addProperty("cCity",arr[10]);
    request.addProperty("cstatus",arr[11]);

    //Declare the version of the SOAP request
    SoapSerializationEnvelope envelope = new 
    SoapSerializationEnvelope(SoapEnvelope.VER11);
    envelope.setOutputSoapObject(request);
    envelope.dotNet = true;

    try {
        HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
        //this is the actual part that will call the webservice
        androidHttpTransport.call(arr[0], envelope);

        // Get the SoapResult from the envelope body.
       // SoapObject result = (SoapObject)envelope.bodyIn;
       // SoapObject result = (SoapObject) envelope.getResponse();
        if (envelope.bodyIn instanceof SoapFault) {
            final SoapFault result = (SoapFault) envelope.bodyIn;
            if (result != null) {
                //Get the first property and change the label text
                   s = result.toString();
            } else
                s = "No response";              
        }
    } catch (Exception e) {
        e.printStackTrace();
        s=e.getMessage().toString();
    }
    return s;
}
