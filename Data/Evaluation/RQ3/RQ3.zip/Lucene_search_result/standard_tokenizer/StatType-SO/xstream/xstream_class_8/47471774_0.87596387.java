private static String SOAP_ACTION = "http://tempuri.org/METHOD_NAME";
private static String NAMESPACE = "http://tempuri.org/";
private static String METHOD_NAME = "METHOD_NAME";
private static String URL = "myurl.com";

Button button1;
TextView textView1;
String jsonStr;


@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

    StrictMode.setThreadPolicy(policy);

    button1 =(Button) findViewById(R.id.idbutton1);
    textView1 = (TextView) findViewById(R.id.idtxtView1);

    button1.setOnClickListener(new View.OnClickListener() {

        @Override
        public void onClick(View v) {
            //Initialize soap request + add parameters
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
            //Use this to add parameters
            request.addProperty("id_no", 123
            request.addProperty("serial_no", 2);
            request.addProperty("Year", 2017);
            request.addProperty("Username", "username");
            request.addProperty("Password", "password");

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

            envelope.setOutputSoapObject(request);
            envelope.dotNet = true;

            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                //this is the actual part that will call the webservice
                androidHttpTransport.call(SOAP_ACTION, envelope);

                // Get the SoapResult from the envelope body.
                SoapPrimitive resultsRequestSOAP = (SoapPrimitive) envelope.getResponse();
                jsonStr = resultsRequestSOAP.toString();
                textView1.setText(jsonStr);


            } catch(Exception E) {

               xy = ("ERROR:" + E.getClass().getName() + ": " + E.getMessage());

            }
            textView1.setText(jsonStr);

        }
    });

}
