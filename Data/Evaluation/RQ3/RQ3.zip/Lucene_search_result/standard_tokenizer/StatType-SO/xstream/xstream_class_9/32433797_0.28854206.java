import com.thoughtworks.xstream.XStream;

import java.io.FileReader;
import java.io.IOException;



public class Configuration
{
    private static final Configuration ourInstance = new Configuration();
    private ConfigData ourData;
    //original private XStream xStream = new XStream(new DomDriver()); // does not require XPP3 library
    private XStream xStream = new XStream();
    private String configFileDirectory = "C:\\";   
    private String mainConfigurationFile = "MainConfiguration.xml";


    private Configuration()
    {
        // Private to ensure singleton status
    }

    /**
     * Load configuration information.  This method must be called before calling any other
     * methods.
     */
    public static void load()
    {
        ourInstance.loadConfiguration();
    }

    private void loadConfiguration()
    {
        ourData = (ConfigData)loadObject(mainConfigurationFile);
    }

    private Object loadObject(String fileName)
    {
        Object obj = null;
      try
        {
            obj = fromFile(fileName);
        }
        catch (IOException e)
        {
            e.printStackTrace();
            System.exit(1);  // Can't continue without a configuration object

        }
        return obj;
    }

    private Object fromFile(String fileName) throws IOException
    {
        FileReader reader = new FileReader(configFileDirectory + fileName);
        return (Object) xStream.fromXML(reader);
    }

    private static class ConfigData
    {

    }
}
