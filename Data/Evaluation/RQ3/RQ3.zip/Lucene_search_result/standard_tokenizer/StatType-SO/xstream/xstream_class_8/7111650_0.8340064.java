private static final String SOAP_ACTION = "myMethod";
private static final String METHOD_NAME = "myMethod";
private static final String NAMESPACE = "http://mynamespace.com/";
private static final String URL = "http://myserver.com/bean";

void test() {
try {
    SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);
    request.addProperty("prop1", "myprop");

    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
    envelope.setOutputSoapObject(request);
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
    androidHttpTransport.call(SOAP_ACTION, envelope);

    Object result = envelope.getResponse();

    //handle result here

    myExampleHandler.getResults();
} catch (Exception e) {
    e.printStackTrace();
}
}
