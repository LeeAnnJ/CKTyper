private class FerhToCel extends AsyncTask&lt;Data, Void, SoapObject&gt; {
         SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);

         protected SoapObject doInBackground(Data... data) {
              SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);       

              //Use this to add parameters
              request.addProperty("Fahrenheit",txtFar.getText().toString());

              //Declare the version of the SOAP request


              envelope.setOutputSoapObject(request);
              envelope.dotNet = true;

              try {
                    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

                    //this is the actual part that will call the webservice
                    androidHttpTransport.call(SOAP_ACTION1, envelope);

                    // Get the SoapResult from the envelope body.

              }catch (Exception e) {
                  e.printStackTrace();
              }

            return null;
            //make your network call and return SoapObject
         }


        protected void onPostExecute(SoapObject obj) {
            SoapObject result = (SoapObject)envelope.bodyIn;
             txtCel.setText(result.getProperty(0).toString());

            //process the Soap Object returned
        }
        }
