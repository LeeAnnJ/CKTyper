package test;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.io.xml.DomDriver;

@XStreamAlias("Message")
public class GenericClass {

@XStreamAlias("calledProgram")
@XStreamAsAttribute
private String calledProgram;

@XStreamAlias("programName")
@XStreamAsAttribute
private String programName;

@XStreamAlias("Fields")
private Fields flds = new Fields(
    new Field("nameValue1", "valueValue1"),
    new Field("nameValue2", "valueValue2"),
    new Field("nameValue3", "valueValue2"));

private static XStream xstream;

public GenericClass() {
    new GenericClass("calledProgram", "programName");
}

public GenericClass(String calledProgram, String programName) {
    xstream = new XStream(new DomDriver());
    xstream.processAnnotations(GenericClass.class);
    this.calledProgram = calledProgram;
    this.programName = programName;
}

public static void main(String[] args) {

    GenericClass msg = new GenericClass();

    // Unmarshall
    FileInputStream file = null;
    try {
        file = new FileInputStream(
                "E:\\JavaDev\\JRecordFiles\\Samples\\LevisTest.xml");
    } catch (FileNotFoundException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }
     msg = (GenericClass) xstream.fromXML(file);
     System.out.println("&lt;?xml version=\"1.0\" encoding=\"utf-8\"?&gt;\n" + xstream.toXML(msg));
}
}
