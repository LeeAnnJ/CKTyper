SoapObject request = new SoapObject(NAMESPACE,METHOD_NAME);
    request.addProperty("MobileNbr","9959077764");
    SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
    envelope.dotNet=true;
    envelope.setOutputSoapObject(request);
    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
    try {
        androidHttpTransport.call(SOAP_ACTION, envelope);
        androidHttpTransport.debug = true;
        SoapObject response = (SoapObject)envelope.bodyIn;
        System.out.println(response);
        String result = response.getProperty(0);
        System.out.println(result);
    }catch (XmlPullParserException | IOException e) {
        e.printStackTrace();
    }   
