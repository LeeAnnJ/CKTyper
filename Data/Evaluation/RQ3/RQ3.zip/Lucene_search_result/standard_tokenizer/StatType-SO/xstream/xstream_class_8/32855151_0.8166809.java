public class MyTask extends AsyncTask&lt;String, Integer, String&gt;{

private static final String SOAP_ACTION = "http://www.w3schools.com/webservices/CelsiusToFahrenheit";
private static final String OPERATION_NAME = "CelsiusToFahrenheit";
private static final String NAMESPACE = "http://www.w3schools.com/webservices/";
private static final String URL = "http://www.w3schools.com/webservices/tempconvert.asmx?WSDL";

@Override
protected String doInBackground(String... params) {
    String response = null;
    SoapObject Request = new SoapObject(NAMESPACE, OPERATION_NAME);
    Request.addProperty("Celsius", "1");
    //Request.addProperty("strCommandParameters", params[1]);



    SoapSerializationEnvelope soapEnvelope = new SoapSerializationEnvelope(
        SoapEnvelope.VER11);
    soapEnvelope.dotNet = true;
    soapEnvelope.setOutputSoapObject(Request);
    // Needed to make the internet call

    // Allow for debugging - needed to output the request

    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
    androidHttpTransport.debug = true;
    // this is the actual part that will call the webservice
    try {
        androidHttpTransport.call(SOAP_ACTION, soapEnvelope);
    } catch (HttpResponseException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (IOException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } catch (XmlPullParserException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    }

    // Get the SoapResult from the envelope body.
    SoapObject result = (SoapObject) soapEnvelope.bodyIn;   
    response = result.getProperty(0).toString();    
    return response;
}
