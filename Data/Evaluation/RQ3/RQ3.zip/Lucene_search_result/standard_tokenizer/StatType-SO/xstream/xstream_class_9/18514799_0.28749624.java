public static String getLocalIPAddress(String serverIP, int port) throws UnknownHostException
{
    System.out.println("Executing getLocalIPAddress on "+serverIP + ":" + port);
    InetAddress inetAddress = InetAddress.getLocalHost();
    String ipAddress = inetAddress.getHostAddress();
    try {
     Socket s = new Socket(serverIP, port);
     ipAddress = s.getLocalAddress().getHostAddress();
     System.out.println("Local IP : "+s.getLocalAddress().getHostAddress());
     s.close();
    } catch (Exception ex) {}
return ipAddress;
}   
