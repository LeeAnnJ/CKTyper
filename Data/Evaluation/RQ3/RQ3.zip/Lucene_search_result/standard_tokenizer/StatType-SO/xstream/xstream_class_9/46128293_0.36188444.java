 import java.net.InetAddress;
 import java.net.Socket;
 import java.util.Scanner;


 public class test1{

    String serverIp;
    Boolean connected;
    InetAddress IP;
    Socket clientSocket;
    Integer clientID;
    int ssPortNo;

    public test1(){
        System.out.println("Enter IP : ");
        Scanner sc = new Scanner(System.in);
        String ip = sc.next();
        System.out.println("Enter port : ");
        String port = sc.next();
        setupConnection(ip, port);
    }




    private void setupConnection(String serverIP, String port) {
        int portInt = Integer.parseInt(port);
        serverIp = serverIP;
        try {
            connected = true;
            IP = InetAddress.getByName(serverIP);
            clientSocket = new Socket(serverIP, portInt);
            System.out.println("Connecting");
        }
        catch(Exception e){
            System.out.println("1 " + e.getMessage());  
        }
    }
}
