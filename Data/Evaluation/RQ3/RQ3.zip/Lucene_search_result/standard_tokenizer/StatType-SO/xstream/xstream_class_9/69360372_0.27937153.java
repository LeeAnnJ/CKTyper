public class Host {

    private final static Logger LOGGER = LogManager.getLogger(Host.class);

    private String ip;

    public Host(String ip) {
        this.ip = ip;
    }

    public String getIp() {
        return ip;
    }

}
