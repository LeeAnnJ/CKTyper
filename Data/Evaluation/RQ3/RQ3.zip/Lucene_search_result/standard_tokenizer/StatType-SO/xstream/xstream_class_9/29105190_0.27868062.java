public class ConnectionManagement implements Runnable  {
private static ConnectionManagement instance =  new ConnectionManagement();
private String ip;
private int port;
private Socket connection;
private PrintWriter printWriter;

private ConnectionManagement(){
    this.ip = "127.0.0.1";
    this.port = 700;
}

public static ConnectionManagement getInstance(){
    return instance;
}

public void setIp(String ip){
    this.ip=ip;
}

public void setPort(int port){
    this.port=port;
}

public void run(){
        try {
            connection = new Socket(InetAddress.getByName(this.ip), this.port);
            PrintWriter printWriter = new PrintWriter(connection.getOutputStream(), true);
        } catch (IOException e) {
            e.printStackTrace();
        }

}
public void sendMessage(String message){
    printWriter.write(message);
}

public void disconnect(){
    try {

        printWriter.flush();
        printWriter.close();
        connection.close();

    }catch (IOException e){
        e.printStackTrace();
    }
}

public boolean isClosed(){
        return connection.isClosed();
}
