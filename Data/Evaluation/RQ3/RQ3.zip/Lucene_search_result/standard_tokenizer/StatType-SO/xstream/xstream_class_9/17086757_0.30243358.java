public Storage parseConfiguration(String xmlFile)
        throws FileNotFoundException
{
    FileInputStream fis = new FileInputStream(xmlFile);

    XStream xstream = new XStream();
    xstream.autodetectAnnotations(true);
    xstream.alias("storage", Storage.class);

    return (Storage) xstream.fromXML(fis);
}
