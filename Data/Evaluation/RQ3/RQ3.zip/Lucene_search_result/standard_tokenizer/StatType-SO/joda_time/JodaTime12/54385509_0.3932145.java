  String dtStart = "2019-01-27T09:27:37Z";
    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    try {
        Date date = format.parse(dtStart);
        System.out.println(date);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm");

        String date1 = sdf.format(date);
        String time= sdf1.format(date);
        Log.e("check_date_time",""+date1+"=="+time);
    } catch (ParseException e) {
        e.printStackTrace();
    }
